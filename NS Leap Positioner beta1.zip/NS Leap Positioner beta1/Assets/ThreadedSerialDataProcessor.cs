using System;
using System.IO.Ports;
using UnityEngine;
using Leap.Unity;

public class ThreadedSerialDataProcessor : MonoBehaviour {
    // public RawIMUPosing imuTarget;
    public NSArucoIMU sensorFusion;

    //public SensorFusion sensorFusion;
    SerialPort _serialPort;
  public string portName = "COM3";
  int curIndex = 0;
  byte[] IMUFrame = new byte[3000];
  ProduceConsumeBuffer<imu_data_tx> IMUData = new ProduceConsumeBuffer<imu_data_tx>(128);

  byte[] buffer = new byte[4096];
  Action kickoffRead = null;

	//SensorMishmash mishmash;

  void Start() {
	//mishmash = GetComponent<SensorMishmash> ();

    // Defaults to last port in list (most chance to be our controller receiver's port)
    string[] portNames = SerialPort.GetPortNames();
    if (portNames.Length > 0)
      portName = portNames[portNames.Length - 1];

    _serialPort = new SerialPort(@"\\.\" + portName, 115200);
    _serialPort.ReadTimeout = 1;
    _serialPort.DataBits = 8;
    _serialPort.Parity = Parity.None;
    _serialPort.StopBits = StopBits.One;
    _serialPort.WriteTimeout = 1;
    //_serialPort.DtrEnable = true;
    //_serialPort.RtsEnable = true;
    _serialPort.Open();
    if (_serialPort.IsOpen) {
      Debug.Log("Opened " + portName);
      _serialPort.DiscardInBuffer();

      kickoffRead = delegate {
        while (_serialPort.IsOpen) {
          _serialPort.BaseStream.BeginRead(buffer, 0, buffer.Length,
          delegate (IAsyncResult ar) {
            try {
              int actualLength = _serialPort.BaseStream.EndRead(ar);
              byte[] received = new byte[actualLength];
              Buffer.BlockCopy(buffer, 0, received, 0, actualLength);
								//string test = System.Text.Encoding.ASCII.GetString(received);
								//Debug.Log(test);
              receivedData(received);
            } catch (TimeoutException) {
            } catch (InvalidOperationException) {
            } catch (Exception exc) {
              Debug.Log(exc);
            }
          }, null);
        }
      };
      kickoffRead.BeginInvoke(null, null);
    }
  }

  void receivedData(byte[] received) {
		//Debug.Log (received.Length);
    for (int i = 0; i < received.Length; i++) {
			//Debug.Log (curIndex);
      if (curIndex!=0 && (char)received[i] == '\n' && IMUFrame[curIndex-1] == 13) {

				//Debug.Log ("READ FRAME END BYTE: "+received[i]);
        imu_data_tx data = IMUFrame;
        if (curIndex == 33) {
          IMUData.TryEnqueue(ref data);
        }
        for (int j = 0; j < IMUFrame.Length; j++) {
          IMUFrame[j] = 0;
        }
        curIndex = 0;
		break;
      } else {
        if (curIndex < IMUFrame.Length) {
          IMUFrame[curIndex] = received[i];
					curIndex++;
        }
      }
    }
  }

  void Update() {
    imu_data_tx data;

        while (IMUData.TryDequeue(out data)) {
            //FLO: Removed following line for custom arduino implementation
            //sensorFusion.IntegrateSensorData(data);
            //if (data.buttons == 0) {
            //Debug.Log("button 1 DOWN"+data.buttons);
            //mishmash.ApplyButtonsTo(data.buttons);
            //}
            //mishmash.ApplyIMUTo (data.imu [0], data.imu [1], data.imu [2], data.imu [3]);
            //mishmash.ApplyIMUTo( -data.imu[0], data.imu[1], data.imu[3], data.imu[2]);
            //Debug.Log(-data.imu[0]+","+ data.imu[1]+","+ data.imu[3]+","+ data.imu[2]);


            Quaternion newQuat = new Quaternion(-data.imu[0], data.imu[2], -data.imu[3], -data.imu[1]); //orientation
            //imuTarget.UpdateRot(newQuat);

            Vector3 newVect = new Vector3(data.imu[4], -data.imu[6], -data.imu[5]); //accelerometer data
            //imuTarget.UpdateAccel(newVect);

            sensorFusion.UpdateIMU(newQuat, newVect);
        }
    }


  void OnApplicationQuit() {
    try {
      kickoffRead.EndInvoke(null);
    } catch (System.Runtime.Remoting.RemotingException exc) {
      Debug.Log("Serial Polling Thread Shutting down\n"+exc.ToString());
    } catch (Exception exc) {
      Debug.Log(exc.ToString());
    }
    _serialPort.Close();
    if (!_serialPort.IsOpen) {
      Debug.Log("Closed " + portName);
    } else {
      Debug.Log("Couldn't close " + portName);
    }
  }

  public struct imu_data_tx {
    public float[] imu; //6 * 4 bytes
    public uint time_stamp; //4 bytes
    public byte buttons; //1 byte
    //public byte cr; //1 byte
    //public byte lf; //1 byte

    public static implicit operator imu_data_tx(byte[] bytes) {
      imu_data_tx newValue = new imu_data_tx();
      newValue.imu = new float[7];
      newValue.imu[0] = BitConverterNoAlloc.ToSingle(bytes, 0); //quaternion w
      newValue.imu[1] = BitConverterNoAlloc.ToSingle(bytes, 4); //quat x
      newValue.imu[2] = BitConverterNoAlloc.ToSingle(bytes, 8); //quat y
      newValue.imu[3] = BitConverterNoAlloc.ToSingle(bytes, 12); //quat z
      newValue.imu[4] = BitConverterNoAlloc.ToSingle(bytes, 16); //yaw
      newValue.imu[5] = BitConverterNoAlloc.ToSingle(bytes, 20); //pitch
      newValue.imu[6] = BitConverterNoAlloc.ToSingle(bytes, 24); //roll
      //newValue.time_stamp = BitConverterNoAlloc.ToUInt32(bytes, 24);
      newValue.buttons = bytes[28];
      return newValue;
    }

    public override string ToString() {
      //return "AccX: " + imu[0] + " AccY: " + imu[1] + " AccZ: " + imu[2] + " GyrX: " + imu[3] + " GyrY: " + imu[4] + " GyrZ: " + imu[5] + " Time: " + time_stamp + " ButtonMask: " + Convert.ToString(buttons, 2).PadLeft(8, '0');
		//FLO: coundln't figure out button mask:
		return "Quat w: " + imu[0] + " Quat x: " + imu[1] + " Quat y: " + imu[2] + " Quat z: " + imu[3] + " Yaw: " + imu[4] + " Pitch: " + imu[5] + " Roll: " + imu[6] + " ButtonMask: " + buttons;
    }
  }
}