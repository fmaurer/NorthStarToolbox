﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class NSArucoIMU : MonoBehaviour {

    private bool newPosData = false;
    private bool newIMUData = false;
    public float lastIMUTime;
    public float lastPosTime;
    private Vector3 lastPos;
    private Vector3 last2Pos; //2 in the past
    public Vector3 lastAccel;
    public Quaternion lastRot;

    private Vector3 targetPos;

    private bool updatedAbsPosThisFrame = false;
    private float deltaPosUpdate = 1000f; //start big so start velocity is low

    private Queue velSamples;
    public int queueLength = 10;
    Vector3 imuVel;

    public float slerpFactor = 1;
    // Use this for initialization
    void Start () {

        lastRot = Quaternion.identity;
        lastAccel = lastPos = last2Pos = imuVel = Vector3.zero;

        lastIMUTime = lastPosTime = - 1;

        velSamples = new Queue();

    }
	
	// Update is called once per frame
	void Update () {

        if (newPosData)
        {
            transform.position = lastPos;
            newPosData = false;
            updatedAbsPosThisFrame = true;
        }

        if (newIMUData)
        {
            transform.rotation = lastRot;
            newIMUData = false;

            imuVel = transform.TransformDirection(lastAccel * (Time.time - lastIMUTime));
            AddVelValue(imuVel);

        }

        if (!updatedAbsPosThisFrame) //if haven't received position update, then extrapolate position from IMU data :
        {
            //Vector3 instantVel = (lastPos - last2Pos) / (deltaPosUpdate);   //VELOCITY calculated from aruco updates
            //Vector3 extrapolatedVel = (instantVel) + imuVel;

            Vector3 extrapolatedVel = Vector3.zero;
            if (velSamples.Count >= queueLength)
            {
                extrapolatedVel = (Vector3)velSamples.Peek();

                if (extrapolatedVel.magnitude < 1)
                {
                    targetPos = transform.position + (extrapolatedVel * Time.deltaTime);
                    transform.position = Vector3.Slerp(lastPos, targetPos, Time.deltaTime*slerpFactor);
                    //transform.position = targetPos;
                }

            }

            

        }

        updatedAbsPosThisFrame = false;

        if(velSamples.Count > 0)
        {
            Debug.DrawLine(transform.position, transform.position + (Vector3)velSamples.Peek(), Color.green);

        }

    }

    public void UpdateIMU(Quaternion imuRot, Vector3 imuAccel)
    {
        lastIMUTime = Time.time;
        lastRot = imuRot;
        lastAccel = imuAccel;
        newIMUData = true;
    }

    public void UpdatePos(Vector3 newPos)
    {
        deltaPosUpdate = Time.time - lastPosTime;
        lastPosTime = Time.time;
        if(last2Pos == Vector3.zero) //check if first update
        {
            last2Pos = lastPos = newPos;
        } else
        {
            last2Pos = lastPos;
            lastPos = newPos;
        }
        newPosData = true;
    }

    void AddVelValue(Vector3 newVel)
    {
        if(velSamples.Count >= queueLength)
        {
            velSamples.Dequeue();
        }
            velSamples.Enqueue(newVel);
    }

}
