﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Leap.Unity.Examples;
public class WorkstationToggle : MonoBehaviour {

    bool isOpen;
    public WorkstationBehaviourExample workstation;
	// Use this for initialization
	void Start () {
	}
	
	// Update is called once per frame
	void Update () {
		
	}

    public void ToggleWorkstation()
    {
        if (workstation.workstationState == WorkstationBehaviourExample.WorkstationState.Open)
        {
            workstation.DeactivateWorkstation();
        } else
        {
            workstation.ActivateWorkstation();
        }
    }
}
