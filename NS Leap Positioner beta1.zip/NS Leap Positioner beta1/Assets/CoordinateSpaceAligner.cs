﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
//using Leap.Unity.Internal;

namespace Leap.Unity
{
        public class CoordinateSpaceAligner : MonoBehaviour
    {

        public bool useThumbtip = false;
        public bool useIndex = false;
        public bool useMiddle = false;
        public bool useRing = false;
        public bool usePinky = false;
        public bool usePalm = true;

        [Serializable]
        public struct MultideviceCalibrationInfo
        {
            public LeapProvider deviceProvider;
            [NonSerialized]
            public List<Vector3> handPoints;
            [NonSerialized]
            public Hand currentHand;
        }
        public MultideviceCalibrationInfo[] devices;
        
        
        public KeyCode takeCalibrationSampleKey;
        public KeyCode solveForRelativeTransformKey;

        public Transform leapProviderContainer; // for when the leap is inside HMD, and you want to align entire HMD to reference Tracker space
        public Transform[] referenceTracker; //e.g. positions to store and compare aginst leap data each sample. MUST MATCH ORDER AND QTY OF HAND REFERNECE POINTS
        public Transform referenceFrame; //the coordinate space the referenceTracker should be in. 
                                         //For example, I want to know the relative offset of the Leap to the headtracker on the same HMD so I input HMD tracker here. When solving Kabsch, the transform will be relative as opposed to using the Antilatency system's coordinate space

        public Transform ignoreChild;

        List<Vector3> referenceTrackerPoints;

        // Use this for initialization
        void Start() {
            referenceTrackerPoints = new List<Vector3>();

            if(referenceFrame == null)
            {
                referenceFrame = transform;
            }

            if (leapProviderContainer == null)
            {
                leapProviderContainer = devices[0].deviceProvider.transform;
            }
        }

        void AddAllEnabledHandReferencePoints(List<Vector3> referencePoints)
        {

            if (useThumbtip)
            {
                //Fingers[0].bones[3].Center.ToVector3());

                referencePoints.Add(referenceTracker[0].position);
            }
            if (useIndex)
            {
                //Fingers[1].bones[3].Center.ToVector3());
                referencePoints.Add(referenceTracker[1].position);
            }
            if (useMiddle)
            {
                //Fingers[2].bones[3].Center.ToVector3());
                referencePoints.Add(referenceTracker[2].position);
            }
            if (useRing)
            {
                //Fingers[3].bones[3].Center.ToVector3());
                referencePoints.Add(referenceTracker[3].position);
            }
            if (usePinky)
            {
                //Fingers[4].bones[3].Center.ToVector3());
                referencePoints.Add(referenceTracker[4].position);
            }
            if (usePalm)
            {
                //leapDevice.handPoints.Add(leapDevice.currentHand.PalmPosition.ToVector3());
                referencePoints.Add(referenceTracker[5].position);
            }
        }

            void AddAllEnabledHandPoints(MultideviceCalibrationInfo leapDevice)
        {
           
            if (useThumbtip)
            {
                leapDevice.handPoints.Add(leapDevice.currentHand.Fingers[0].bones[3].NextJoint.ToVector3());
            }
            if (useIndex)
            {
                leapDevice.handPoints.Add(leapDevice.currentHand.Fingers[1].bones[3].NextJoint.ToVector3());
            }
            if (useMiddle)
            {
                leapDevice.handPoints.Add(leapDevice.currentHand.Fingers[2].bones[3].NextJoint.ToVector3());
            }
            if (useRing)
            {
                leapDevice.handPoints.Add(leapDevice.currentHand.Fingers[3].bones[3].NextJoint.ToVector3());
            }
            if (usePinky)
            {
                leapDevice.handPoints.Add(leapDevice.currentHand.Fingers[4].bones[3].NextJoint.ToVector3());
            }
            if (usePalm)
            {
                leapDevice.handPoints.Add(leapDevice.currentHand.PalmPosition.ToVector3());
            }
             
            
            /* ====== Get points from all finger joints:
                             
                            for (int j = 0; j < 5; j++)
                            {
                                for (int k = 0; k < 4; k++)
                                {
                                    devices[i].handPoints.Add(devices[i].currentHand.Fingers[j].bones[k].Center.ToVector3());
                                }
                            }
                            */

            /* ====== Get point from palm: */
        }

        // Update is called once per frame
        void Update()
        {
            if (devices.Length > 0)
            {

                // Add the set of joints to device-specific lists
                if (Input.GetKeyUp(takeCalibrationSampleKey))
                {
                    bool handInAllFrames = true;
                    for (int i = 0; i < devices.Length; i++)
                    {
                        Hand rightHand = devices[i].deviceProvider.CurrentFrame.Get(Chirality.Right);
                        if (rightHand != null)
                        {
                            devices[i].currentHand = rightHand;
                        }
                        else
                        {
                            handInAllFrames = false;
                        }
                    }

                    if (handInAllFrames)
                    {
                        for (int i = 0; i < devices.Length; i++)
                        {
                            if (devices[i].handPoints == null) devices[i].handPoints = new List<Vector3>();

                            /* ====== Get points from all finger joints:
                             
                            for (int j = 0; j < 5; j++)
                            {
                                for (int k = 0; k < 4; k++)
                                {
                                    devices[i].handPoints.Add(devices[i].currentHand.Fingers[j].bones[k].Center.ToVector3());
                                }
                            }
                            */

                            /* ====== Get point from palm: */
                            //devices[i].handPoints.Add(referenceFrame.InverseTransformPoint(devices[i].currentHand.PalmPosition.ToVector3()));

                            //======= Fectch all hand points selected:
                            AddAllEnabledHandPoints(devices[i]);

                        }

                        /*for(int j = 0; j < referenceTracker.Length; j++)
                        {
                            referenceTrackerPoints.Add(referenceFrame.InverseTransformPoint(referenceTracker[j].position));
                        }*/

                            AddAllEnabledHandReferencePoints(referenceTrackerPoints);

                        SendMessage("StoredSample", referenceTrackerPoints.Count,SendMessageOptions.DontRequireReceiver);

                        Debug.Log("saved new relative points, total sets:"+ referenceTrackerPoints.Count);
                    }
                }

                // Moves subsidiary devices to be in alignment with the device at the 0 index
                if (Input.GetKeyUp(solveForRelativeTransformKey))
                {
                    SolveKabschAndAlign();

                }
            }

        }

        public void SolveKabschAndAlign()
        {
            Debug.Log("Trying solve...");
            if (devices[0].handPoints.Count > 3)
            {
                for (int i = 0; i < devices.Length; i++)
                {
                    KabschSolver solver = new KabschSolver();

                    Matrix4x4 deviceToOriginDeviceMatrix =
                      solver.SolveKabsch(devices[i].handPoints, referenceTrackerPoints, 200);

                    //If child set, remove from hierarchy first
                    if (ignoreChild != null)
                    {
                        Transform childParent = ignoreChild.parent;
                        ignoreChild.parent = null;
                        //leapProviderContainer.position = deviceToOriginDeviceMatrix.GetVector3();
                        //leapProviderContainer.rotation = deviceToOriginDeviceMatrix.GetQuaternion();
                        leapProviderContainer.transform.Transform(deviceToOriginDeviceMatrix);
                        //leapProviderContainer.rotation = Quaternion.RotateTowards(leapProviderContainer.rotation,deviceToOriginDeviceMatrix.GetRotation(),90);
                        ignoreChild.parent = childParent;
                    }
                    else
                    {
                        leapProviderContainer.transform.Transform(deviceToOriginDeviceMatrix);
                        //leapProviderContainer.position = deviceToOriginDeviceMatrix.GetPosition();
                        //leapProviderContainer.rotation = deviceToOriginDeviceMatrix.GetRotation();
                    }

                    //leapProviderContainer = tempParent;
                    //devices[i].deviceProvider.transform.Transform(deviceToOriginDeviceMatrix);

                    devices[i].handPoints.Clear();

                }
                devices[0].handPoints.Clear();
                referenceTrackerPoints.Clear();
                SendMessage("StoredSample", 0, SendMessageOptions.DontRequireReceiver);

            }
            else { Debug.Log("FAIL: Not enough samples, need more than 3"); }
        }

        private void OnDrawGizmos()
        {
            for (int i = 0; i < devices.Length; i++)
            {
                if (devices[0].handPoints != null)
                {
                    
                    for (int j = 0; j < devices[0].handPoints.Count; j++)
                    {

                        Vector3 tempHandPoint = referenceFrame.TransformPoint(devices[i].handPoints[j]);
                        Vector3 tempRefPoint = referenceFrame.TransformPoint(referenceTrackerPoints[j]);

                        Gizmos.DrawSphere(tempHandPoint, 0.01f);
                        Gizmos.DrawSphere(tempRefPoint, 0.01f);
                        Gizmos.DrawLine(tempRefPoint, tempHandPoint);
                        /*
                        Gizmos.DrawSphere(devices[i].handPoints[j], 0.01f);
                        if (i > 0)
                        {
                            Gizmos.DrawLine(devices[i].handPoints[j], devices[0].handPoints[j]);
                        }
                        */
                    }


                }
            }
        }

    }

    public class KabschSolver
    {
        Vector3[] QuatBasis = new Vector3[3];
        Vector3[] DataCovariance = new Vector3[3];
        Quaternion OptimalRotation = Quaternion.identity;
        public Matrix4x4 SolveKabsch(List<Vector3> inPoints, List<Vector3> refPoints, int iters = 9)
        {
            if (inPoints.Count != refPoints.Count) { return Matrix4x4.identity; }

            //Calculate the centroid offset and construct the centroid-shifted point matrices
            Vector3 inCentroid = Vector3.zero; Vector3 refCentroid = Vector3.zero;
            for (int i = 0; i < inPoints.Count; i++)
            {
                inCentroid += inPoints[i];
                refCentroid += refPoints[i];
            }
            inCentroid /= inPoints.Count;
            refCentroid /= refPoints.Count;
            for (int i = 0; i < inPoints.Count; i++)
            {
                inPoints[i] -= inCentroid;
                refPoints[i] -= refCentroid;
            }

            //Calculate the covariance matrix, is a 3x3 Matrix and Calculate the optimal rotation
            extractRotation(TransposeMult(inPoints, refPoints, DataCovariance), ref OptimalRotation, iters);

            return
            Matrix4x4.TRS(refCentroid, Quaternion.identity, Vector3.one) *
            Matrix4x4.TRS(Vector3.zero, OptimalRotation, Vector3.one) *
            Matrix4x4.TRS(-inCentroid, Quaternion.identity, Vector3.one);
        }
        //https://animation.rwth-aachen.de/media/papers/2016-MIG-StableRotation.pdf
        void extractRotation(Vector3[] A, ref Quaternion q, int iters = 9)
        {
            for (int iter = 0; iter < iters; iter++)
            {
                Vector3[] R = MatrixFromQuaternion(q, QuatBasis);
                Vector3 omega = (Vector3.Cross(R[0], A[0]) +
                                 Vector3.Cross(R[1], A[1]) +
                                 Vector3.Cross(R[2], A[2])) *
                 (1f / Mathf.Abs(Vector3.Dot(R[0], A[0]) +
                                 Vector3.Dot(R[1], A[1]) +
                                 Vector3.Dot(R[2], A[2]) + 0.000000001f));

                float w = Mathf.Clamp(omega.magnitude * 50f, -10f, 10f); //How aggressive each iteration should be
                if (w < 0.000000001f)
                    break;
                q = Quaternion.AngleAxis(w, (1f / w) * omega) * q;
                q = Quaternion.Lerp(q, q, 0f);//Normalizes the Quaternion; critical for error suppression
            }
        }
        //Calculate Covariance Matrices --------------------------------------------------
        Vector3[] TransposeMult(List<Vector3> vec1, List<Vector3> vec2, Vector3[] covariance)
        {
            for (int i = 0; i < 3; i++)
            { //i is the row in this matrix
                covariance[i] = Vector3.zero;
                for (int j = 0; j < 3; j++)
                {//j is the column in the other matrix
                    for (int k = 0; k < vec1.Count; k++)
                    {//k is the column in this matrix
                        covariance[i][j] += vec1[k][i] * vec2[k][j];
                    }
                }
            }
            return covariance;
        }

        public static Vector3[] MatrixFromQuaternion(Quaternion q, Vector3[] covariance)
        {
            covariance[0] = q * Vector3.right;
            covariance[1] = q * Vector3.up;
            covariance[2] = q * Vector3.forward;
            return covariance;
        }
    }

}
