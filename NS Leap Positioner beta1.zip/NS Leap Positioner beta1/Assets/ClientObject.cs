﻿using System.Collections.Concurrent;
using System.Threading;
using UnityEngine;
using NetMQ;
using NetMQ.Sockets;

public class NetMqListener
{
    private readonly Thread _listenerWorker;

    private bool _listenerCancelled;

    public delegate void MessageDelegate(string message);

    private readonly MessageDelegate _messageDelegate;

    private readonly ConcurrentQueue<string> _messageQueue = new ConcurrentQueue<string>();

    //private SubscriberSocket subSocket;
    private void ListenerWork()
    {
        AsyncIO.ForceDotNet.Force();


        using (var subSocket = new SubscriberSocket())
        {
            subSocket.Options.ReceiveHighWatermark = 1000;
            //subSocket.Connect("tcp://localhost:12345");
            subSocket.Connect("tcp://192.168.1.72:12345");
            subSocket.Subscribe("");
            while (!_listenerCancelled)
            {
                string frameString;
                if (!subSocket.TryReceiveFrameString(out frameString)) continue;
                //Debug.Log(frameString);
                _messageQueue.Enqueue(frameString);
            }
            subSocket.Close();
        }
        NetMQConfig.Cleanup();
    }

    public void Update()
    {
        //subSocket.Poll();
        while (!_messageQueue.IsEmpty)
        {
            string message;
            if (_messageQueue.TryDequeue(out message))
            {
                _messageDelegate(message);
            }
            else
            {
                break;
            }
        }
    }

    public NetMqListener(MessageDelegate messageDelegate)
    {
        _messageDelegate = messageDelegate;
        _listenerWorker = new Thread(ListenerWork);
    }

    public void Start()
    {
        _listenerCancelled = false;
        _listenerWorker.Start();
    }

    public void Stop()
    {
        _listenerCancelled = true;
        _listenerWorker.Join();
    }
}

public class ClientObject : MonoBehaviour
{
    public float confusionRotAngles;
    public Vector3 newPos;
    public Vector3 lastPos = Vector3.zero;

    public Quaternion newRot;
    private NetMqListener _netMqListener;
    private Vector3 newRotValues;
    private Vector3 oldRotValues;

    private float lastPacketTS = 0;
    private float currentPacketTS = 0;
    public float lastUpdateTS = 0; //important to distinguish time of local machine vs remote. This time represents the local time the packet arrived
    public float lastUpdateDeltaTSSecs = 0;
    bool calibrated = false;

    public NSArucoIMU sensorFusion;

    private void HandleMessage(string message)
    {
        //-------------------------- POSITION:

 //Debug.Log(message);
        var splittedStrings = message.Split(' ');
        if (splittedStrings.Length != 7) return;
        var x = float.Parse(splittedStrings[0]);
        var y = float.Parse(splittedStrings[1]);
        var z = float.Parse(splittedStrings[2]);

        newPos = new Vector3(x, -y, z);

        //-------------------------- ROTATION:


        var r_x = float.Parse(splittedStrings[3]);
        var r_y = float.Parse(splittedStrings[4]);
        var r_z = float.Parse(splittedStrings[5]);

        newRotValues = new Vector3(-r_x - 90, r_y, r_z + 180);
        newRot = Quaternion.Euler(-r_x - 90, r_y, r_z + 180);

        //-------------------------- TIMESTAMP:

        currentPacketTS = float.Parse(splittedStrings[6]);

        if (lastPacketTS == 0) //first packet received
        {
            lastPacketTS = currentPacketTS - 10; //extrapolate in the past 10 ms to avoid big spikes on startup
            lastPos = newPos - (Vector3.forward * 0.01f);

        } else
        {
            lastUpdateTS = Time.time; //seconds of local packet
            lastUpdateDeltaTSSecs = (currentPacketTS - lastPacketTS) / 1000; //seconds
            //Debug.Log(lastUpdateDeltaTSSecs);
            lastPacketTS = currentPacketTS;
        }

        sensorFusion.UpdatePos(transform.parent.TransformPoint(newPos));

        //Debug.Log(lastUpdateDeltaTSSecs);


        //transform.rotation = Quaternion.Euler(r_x, r_y , r_z );

        /*if (x == 0 && y == 0 && z == 0)
        {
            if (x2 == 0 && y2 == 0 && z2 == 0)
            {
                newPos = new Vector3(-x, y, -z);
            } else
            {
                newPos = new Vector3((-x-x2)/2, (y+y2)/2, (-z-z2)/2);
            }
        } else if (x2 != 0 && y2 != 0 && z2 != 0)
        {
            newPos = new Vector3(-x2, y2, -z2);
        }
        */
        float factor = 1;
        //r_x = Mathf.Round(r_x / factor) * factor;
        // r_y = Mathf.Round(r_x / factor) * factor;
        //r_z = Mathf.Round(r_z / factor) * factor;
        if (!calibrated)
        {

        }




    }

    void OnDrawGizmos()
    {
        if (Application.isPlaying)
        {
            //Gizmos.color = Color.cyan;
            //Gizmos.DrawCube(Vector3.zero, Vector3.one*0.005f);
            //Gizmos.DrawSphere(Vector3.ProjectOnPlane(newPos,Vector3.up), 0.02f);
            //Gizmos.DrawRay(new Ray(Vector3.zero, transform.TransformPoint(newPos)));

            //Gizmos.DrawRay(new Ray(Vector3.zero, -Vector3.forward));

        }
    }



    private void Start()
    {
        _netMqListener = new NetMqListener(HandleMessage);
        _netMqListener.Start();

        oldRotValues = Vector3.zero;
    }

    private void Update()
    {
        _netMqListener.Update();


        /*Quaternion lookTo = Quaternion.LookRotation((Vector3.zero - newPos), Vector3.up);
        transform.parent.transform.rotation = Quaternion.Inverse(lookTo);
        */
        if (lastUpdateDeltaTSSecs >= 0f && (newPos - lastPos).magnitude < 0.200f)
        {
            transform.localPosition = newPos;
            transform.localRotation = newRot;
            lastPos = newPos;
        }


        //Instead, drag sphere equivalent for rotation:
        //oldRotValues = DragSphereEulerAngles(newRotValues, oldRotValues, confusionRotAngles);
        //transform.localRotation = Quaternion.Euler(oldRotValues);



        if (Input.GetKeyDown(KeyCode.R))
        {
            calibrated = true;

            Debug.Log("recentered");
            transform.rotation =  sensorFusion.lastRot; //use IMU rotation

            Transform cameraParentSpace = transform.parent ;
            transform.parent = null;
            cameraParentSpace.parent = transform;
            transform.position = Vector3.zero;
            transform.rotation = Quaternion.identity; // rotate camera about center
            cameraParentSpace.parent = null;
            transform.parent = cameraParentSpace;
            //transform.parent.transform.position = -transform.position;

        }

    }

    /*public Vector3 RotatePointAroundPivot(Vector3 point, Vector3 pivot, Vector3 angles)
    {
        return Quaternion.Euler(angles) * (point - pivot) + pivot;
    }*/

    /*
    private Vector3 DragSphereEulerAngles(Vector3 newAngles, Vector3 oldAngles, float confusionValue)
    {
    float dragged_x = OneDimensionalDragFilter(newAngles[0], oldAngles[0], confusionValue);
    float dragged_y = OneDimensionalDragFilter(newAngles[1], oldAngles[1], confusionValue);
    float dragged_z = OneDimensionalDragFilter(newAngles[2], oldAngles[2], confusionValue);

    return new Vector3(dragged_x, dragged_y, dragged_z);
    }

    private float OneDimensionalDragFilter(float newValue, float oldValue, float confusionValue)
    {
    //calc distance to new point
    //check if distance greater than confusion diameter
    //if true, update position by distance - confusionDiameter/2
    float distance = newValue - oldValue;
    //float distance = Mathf.MoveTowardsAngle(oldValue, newValue, 180);
    if (Mathf.Abs(distance) > confusionValue/2)
    {
      if(distance > 0)
      {
          return oldValue + (distance - confusionValue / 2);
      }
      else
      {
             return oldValue + (distance + confusionValue / 2);

      }

    }

    return oldValue;
    }
    */
    

private void OnDestroy()
{
_netMqListener.Stop();
}

}
