﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ArucoIMU : MonoBehaviour {

    public Transform positionData;
    public Transform rotationData;

    public float yawOffset = 0;

    public Transform debugObj;

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {

        transform.position = positionData.position;
        transform.rotation = rotationData.rotation * Quaternion.AngleAxis(yawOffset, transform.up);

        if (Input.GetKeyDown(KeyCode.M))
        {
            Debug.Log(debugObj.localRotation.ToString());
        }

	}
}
