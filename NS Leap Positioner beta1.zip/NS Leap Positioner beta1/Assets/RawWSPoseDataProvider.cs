﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RawWSPoseDataProvider : ZeroMQBehaviour {

    public float confusionRotAngles;
    public Vector3 newPos;
    public Quaternion newRot;
    private NetMqListener _netMqListener;
    private Vector3 newRotValues;
    private Vector3 oldRotValues;

    private float lastPacketTS = 0;
    private float currentPacketTS = 0;
    public float lastUpdateTS = 0; //important to distinguish time of local machine vs remote. This time represents the local time the packet arrived
    public float lastUpdateDeltaTSSecs = 0;
    bool calibrated = false;

    // Use this for initialization
    protected override void Start () {
        base.Start();
        oldRotValues = Vector3.zero;
    }

    // Update is called once per frame
    protected override void Update () {
        base.Update();
    }

    protected override void HandleMessage(string message)
    {
        Debug.Log(message);
        /*
        //-------------------------- POSITION:

        //Debug.Log(message);
        var splittedStrings = message.Split(' ');
        if (splittedStrings.Length != 7) return;
        var x = float.Parse(splittedStrings[0]);
        var y = float.Parse(splittedStrings[1]);
        var z = float.Parse(splittedStrings[2]);

        newPos = new Vector3(x, -y, z);

        //-------------------------- ROTATION:


        var r_x = float.Parse(splittedStrings[3]);
        var r_y = float.Parse(splittedStrings[4]);
        var r_z = float.Parse(splittedStrings[5]);

        newRotValues = new Vector3(-r_x - 90, r_y, r_z + 180);
        newRot = Quaternion.Euler(-r_x - 90, r_y, r_z + 180);

        //-------------------------- TIMESTAMP:

        currentPacketTS = float.Parse(splittedStrings[6]);

        if (lastPacketTS == 0) //first packet received
        {
            lastPacketTS = currentPacketTS - 10; //extrapolate in the past 10 ms to avoid big spikes on startup

        }
        else
        {
            lastUpdateTS = Time.time; //seconds of local packet
            lastUpdateDeltaTSSecs = (currentPacketTS - lastPacketTS) / 1000; //seconds
            lastPacketTS = currentPacketTS;
        }
        */
    }

}

