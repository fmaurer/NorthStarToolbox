﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MovingAverage : MonoBehaviour {

    public Transform rawData;
    public int windowSize = 30;
    CircularBuffer<Vector3> pastPositions;
    CircularBuffer<Quaternion> pastRotations;

    private Vector3 lastPos = Vector3.zero;
    private Vector3 lastAvgPos = Vector3.zero;
    private Quaternion lastAvgRot = Quaternion.identity;
    private bool justUpdated = false;
	// Use this for initialization
	void Start () {
        pastPositions = new CircularBuffer<Vector3>(windowSize);
        pastRotations = new CircularBuffer<Quaternion>(windowSize);

    }

    // Update is called once per frame
    void Update () {
		//if new packet, add to circular buffer
        if(lastPos != rawData.position)
        {
            pastPositions.Add(rawData.position);
            pastRotations.Add(rawData.rotation);

            lastPos = rawData.position;

             //if buffer is full and just updated, calc new average
            if (pastPositions.isValid())
            {
                lastAvgPos = CalcAvgPos();
                transform.position = lastAvgPos;
            }

            if (pastRotations.isValid())
            {
                lastAvgRot = CalcAvgRot();
                transform.rotation = lastAvgRot;
            }

        }

        //transform.rotation = rawData.rotation;

        

        //update pos
    }
    private Quaternion CalcAvgRot()
    {

        // Try a fractionally-slerped accumulation for "averaging" the rotations.

        CircularBuffer<Quaternion> pastRotations_bak = new CircularBuffer<Quaternion>(windowSize);

        var rot = pastRotations.Read();
        var div = 1 / (windowSize-1);
        for (int i = 0; i < windowSize-1; i++)
        {
            Quaternion deq = pastRotations.Read();
            pastRotations_bak.Add(deq);
            rot = Quaternion.Slerp(rot, deq, div);
        }
        pastRotations = pastRotations_bak;
        return rot;
        
    }

    private Vector3 CalcAvgPos()
    {
        CircularBuffer<Vector3>  pastPositions_bak = new CircularBuffer<Vector3>(windowSize);

        Vector3 sum = Vector3.zero;

        for(int i = 0; i < windowSize; i++) { 

            Vector3 deq = pastPositions.Read();
            pastPositions_bak.Add(deq);
            sum += deq;
        }
        pastPositions = pastPositions_bak;
        return sum / windowSize;

    }
}


public class CircularBuffer<T>
{
    Queue<T> _queue;
    int _size;

    public CircularBuffer(int size)
    {
        _queue = new Queue<T>(size);
        _size = size;
    }

    public bool isValid()
    {
        if (_queue.Count == _size) return true;
        else return false;
    }

    public void Add(T obj)
    {
        if (_queue.Count == _size)
        {
            _queue.Dequeue();
            _queue.Enqueue(obj);
        }
        else
            _queue.Enqueue(obj);
    }
    public T Read()
    {
        return _queue.Dequeue();
    }

    public T Peek()
    {
        return _queue.Peek();
    }
}