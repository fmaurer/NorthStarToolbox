﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class SliderValueToText : MonoBehaviour
{
    public Slider sliderUI;
    //private Text textSliderValue;
    private InputField inputfield;

    void Start()
    {
        inputfield = GetComponent<InputField>();
        ShowSliderValue();
    }

    public void ShowSliderValue()
    {
        string sliderMessage;
            
        float number;
        bool success = float.TryParse(sliderUI.value.ToString(), out number);

        //Debug.Log(number);

        if (success)
        {
            inputfield.text =  number.ToString();
        } else
        {
            inputfield.text = "0";
        }

    }
}