﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class KinematicExtrapolation : MonoBehaviour {


    public ClientObject rawData;
    public bool enableExtrapolation = true;
    private bool isValid = false;
    private int numSamples = 2;
    
    private Vector3 lastVel = Vector3.zero;
    private Vector3 lastPos = Vector3.zero;

    private Vector3 lastRotVel = Vector3.zero;
    private Quaternion lastRot = Quaternion.identity;

    public float extrapolateVelFactor = 3.8f;
    public float extrapolateAngVelFactor = 1f;

    public float angularDampenFactor = 1f;
    // Use this for initialization
    void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
        Vector3 extrapolatedPos = Vector3.zero;
        Quaternion extrapolatedRot = Quaternion.identity;
        Vector3 currentPos = rawData.transform.position;
        Quaternion currentRot = rawData.transform.rotation;

        if (currentPos != lastPos) // check if data has been updated
        {
            if(lastVel != Vector3.zero) //this is updated from initial value after the first loop, so using it to determine if have enough data to extrapolate yet
            {
                //calculate velocity from last frame and extrapolate forward in time
                Vector3 currentVel = (currentPos - lastPos) / rawData.lastUpdateDeltaTSSecs;
                extrapolatedPos = (transform.position) + (currentVel*Time.deltaTime*extrapolateVelFactor);

                //calculate angularVelocity from last frame and extrapolate forward: https://answers.unity.com/questions/49082/rotation-quaternion-to-angular-velocity.html
                Quaternion deltaRot = currentRot * Quaternion.Inverse(lastRot);
                float angleInDegrees;
                Vector3 rotationAxis;
                deltaRot.ToAngleAxis(out angleInDegrees, out rotationAxis);

                Vector3 angularDisplacement = rotationAxis * angleInDegrees * Mathf.Deg2Rad;
                Vector3 angularSpeed = angularDisplacement / Time.deltaTime;

                extrapolatedRot = transform.rotation * Quaternion.Euler(angularSpeed * Time.deltaTime * extrapolateAngVelFactor);

                isValid = true;
                lastVel = currentVel;
                lastRotVel = angularSpeed;

                if (!enableExtrapolation && !isValid)
                {
                    extrapolatedPos = currentPos;
                    extrapolatedRot = currentRot;
                }
                else
                {
                    lastPos = currentPos;
                }


            } else //not enough samples
            {
                lastVel = (currentPos - lastPos) / rawData.lastUpdateDeltaTSSecs; //initial velocity that can be ignored(?)
                extrapolatedPos = currentPos;
                extrapolatedRot = currentRot;
                lastPos = currentPos;
                lastRot = currentRot;
            }

            //Ease the value back to absolute raw data:
            //transform.position = extrapolatedPos;
            transform.position = extrapolatedPos - (extrapolatedPos - rawData.transform.position) / 5;

            //transform.rotation = rawData.transform.rotation;
            transform.rotation = Quaternion.Slerp(rawData.transform.rotation, extrapolatedRot, angularDampenFactor);

        }
        else
        { //no update yet, so slow down for now:
            lastVel *= 0.90f;
            transform.position += (lastVel * Time.deltaTime* extrapolateVelFactor);
        }

        float timeSinceLastRawDataUpdate = Time.time - rawData.lastUpdateTS;
        if (Input.GetKeyDown(KeyCode.R) /*|| timeSinceLastRawDataUpdate > 0.1f*/) // there's been no packets in 100ms
        {
            transform.position = currentPos;
            lastVel = Vector3.zero;
            lastPos = currentPos;
            isValid = false;
        }

    }
}
