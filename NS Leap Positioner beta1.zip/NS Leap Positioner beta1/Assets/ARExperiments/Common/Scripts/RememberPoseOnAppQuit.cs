﻿using System.Collections;
using System.Collections.Generic;
using Leap.Unity.Attributes;
using UnityEngine;

namespace Leap.Unity.AR.Experiments {

  public class RememberPoseOnAppQuit : MonoBehaviour {
    
    [Header("Remembered by name and suffix in Config")]
    public Transform target; 
    public string configFieldSuffix = " (remembered pose)";

    
    private string configFieldName {
      get {
        return target.name + configFieldSuffix;
      }
    }

    private void Reset() {
      if (target == null) target = this.transform;
    }

    #if UNITY_EDITOR
    // Display full config field name as a read-only field in the inspector.
    #pragma warning disable 0414
    [SerializeField, Disable]
    private string _configFieldName;
    #pragma warning restore 0414
    private void OnValidate() {
      _configFieldName = configFieldName;
    }
    #endif

    private void Awake() {
      if (target == null) {
        throw new System.Exception("No Transform attached for pose memory.");
      }
      
      Pose savedPose = Pose.identity;
      if (Config.TryRead<Pose>(configFieldName, ref savedPose)) {
        target.SetPose(savedPose);
      }
    }

    private void OnApplicationQuit() {
      Config.Write<Pose>(configFieldName, target.ToPose());
    }

  }

}
