﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Leap.Unity.AR.Experiments {

  [ExecuteInEditMode]
  public class PoseLineRenderer : MonoBehaviour, IStreamReceiver<Pose> {

    public Color color = Color.white;

    public bool loop = false;

    private Vector3[] _positions = new Vector3[256];
    private int _numPositions = 0;
    private Vector3 _firstPosition; // special memory for looping case.

    private bool _isOpen = false;

    public void Open() {
      _numPositions = 0;

      _isOpen = true;
    }

    public void Receive(Pose data) {
      if (!_isOpen) Open();

      if (_numPositions == 0) {
        _firstPosition = data.position;
      }

      addPosition(data.position);
    }

    private void addPosition(Vector3 position) {
      if (_numPositions >= _positions.Length) {
        var oldPositions = _positions;
        _positions = new Vector3[_positions.Length * 2];
        for (int i = 0; i < oldPositions.Length; i++) {
          _positions[i] = oldPositions[i];
        }
        Debug.Log("Now have positions of size " + _positions.Length);
      }

      _positions[_numPositions++] = position;
    }

    public void Close() {
      if (loop) {
        addPosition(_firstPosition);
      }

      if (gameObject.activeInHierarchy) {
        HyperMegaStuff.HyperMegaLines.drawer.color = color;
        HyperMegaStuff.HyperMegaLines.drawer.DrawLines(_positions, _numPositions);
      }
      
      _isOpen = false;
    }

  }

}