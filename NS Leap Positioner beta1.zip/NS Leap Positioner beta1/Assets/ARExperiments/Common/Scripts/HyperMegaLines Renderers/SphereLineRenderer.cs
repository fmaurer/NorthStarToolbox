﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Leap.Unity.Geometry;

namespace Leap.Unity.AR.Experiments {

  [ExecuteInEditMode]
  public class SphereLineRenderer : MonoBehaviour {
  
    [SerializeField]
    private LocalSphere _localSphere;
    public Sphere sphere {
      get { return _localSphere.With(this.transform); }
    }

    public Color color = Color.white;

    private void Reset() {
      _localSphere = new LocalSphere() { center = Vector3.zero, radius = 1f };
    }

    private void Update() {
      HyperMegaStuff.HyperMegaLines.drawer.color = this.color;
      sphere.DrawLines(HyperMegaStuff.HyperMegaLines.drawer.DrawLine,
        latitudinalDivisions: 10, longitudinalDivisions: 10,
        numCircleSegments: 64);
    }

  }

}