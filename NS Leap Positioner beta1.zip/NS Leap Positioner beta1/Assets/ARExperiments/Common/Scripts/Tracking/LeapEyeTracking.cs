﻿using System;
using System.IO;
using Leap.Unity.Attributes;
using Leap.Unity.Geometry;
using Leap.Unity.HyperMegaStuff;
using Leap.Unity.Infix;
using UnityEngine;

namespace Leap.Unity.AR.Experiments {

  using LeapEyeEvent = LeapInternal.LEAP_EYE_EVENT;
  using LeapVector = LeapInternal.LEAP_VECTOR;

  public class LeapEyeTracking : MonoBehaviour {

    private const float EYE_RADIUS = 0.004f;

    public LeapServiceProvider leapProvider;
    public Transform headTransform;
    public Transform trackerOrigin;
    public bool logValuesOnly = false;
    [DisableIf("logValuesOnly", isEqualTo: true)]
    public bool logValues = false;
    [DisableIf("logValuesOnly", isEqualTo: true)]
    public OpticalCalibrationManager opticalCalibrationManager;

    [Header("Logging")]
    public StreamingFolder logFolder;
    public string logFileName = "LeapEyeTracking.txt";

    private LeapEyeEvent _curEyeEvent = new LeapEyeEvent();

    public Vector3? leftPupilPosition = null;
    public Vector3? rightPupilPosition = null;
    private RingBuffer<Vector3> _leftPupilPositions;
    private RingBuffer<Vector3> _rightPupilPositions;
    public Vector3? averageLeftPupil = null;
    public Vector3? averageRightPupil = null;
    public Vector3? preIPDAverageLeftPupil = null;
    public Vector3? preIPDAverageRightPupil = null;
    public Vector3? lastTrackedLeftPupil = null;
    public Vector3? lastTrackedRightPupil = null;

    [Header("Tracking Settings")]
    [MinValue(0f)]
    public float maxAllowedError = 1f;
    public int positionBufferSize = 20;
    public Transform eyeTrackerHeadsetBasis;

    [Header("Tracking Bias Adjustments")]
    public Vector3 positionBiasMM = Vector3.zero;
    public Vector3 leftPositionBiasMM = Vector3.zero;
    public Vector3 rightPositionBiasMM = Vector3.zero;
    public float ipdBiasMM = 0f;
    private Vector3 _originalPositionBiasMM = Vector3.zero;
    private float _originalIpdBiasMM = 0f;
    public string eyeBiasAdjustConfig = "eyeTrackingAdjustment";
    public bool writeAdjustStateOnQuit = false;

    [Header("Key Adjustments")]
    public string allowKeyAdjustConfig = "allowEyeTrackingKeyAdjustment";
    public bool keyAdjustEnabled = false;
    public KeyCode positionBiasShiftUpKey = KeyCode.I;
    public KeyCode positionBiasShiftDownKey = KeyCode.K;
    public KeyCode ipdShiftUpkey = KeyCode.L;
    public KeyCode ipdShiftDownKey = KeyCode.J;
    public KeyCode positionBiasShiftForwardKey = KeyCode.O;
    public KeyCode positionBiasShiftBackKey = KeyCode.M;
    public KeyCode resetBiasesKey = KeyCode.U;
    public float keyShiftRate = 15f;

    [Header("Calibration Integration")]
    public bool updateEyeTransforms = false;
    public Transform leftEyeTransform = null;
    public Transform rightEyeTransform = null;
    [Tooltip("When this option is enabled, the eye tracker doesn't update eye "
      + "positions since the last time this bool was checked.")]

    [Header("Debug Rendering")]
    public bool renderPupilPositions = false;
    public Color leftColor = LeapColor.lavender;
    public Color rightColor = LeapColor.red;
    public Transform enableWhileLeftTracked;
    public Transform enableWhileRightTracked;
    public Transform enableWhileBothTracked;
    public Transform enableWhileHaveAverage;
    public bool renderOriginalPositions = false;

    [Header("Functionality Debugging")]
    public KeyCode eyeTrackingKeyCode = KeyCode.E;
    public KeyCode lastPositionsOnlyModifier = KeyCode.LeftShift;
    public enum TrackingMode {
      /// <summary>
      /// Normal eye tracking and eye updates.
      /// </summary>
      Normal,

      /// <summary>
      /// A disabled-tracking mode, eyes are set to the positions they were in
      /// when the LeapEyeTracking script was initialized.
      /// </summary>
      OriginalOnly,

      /// <summary>
      /// A disabled-tracking mode, eyes are kept in the last position in which
      /// they were tracked.
      /// </summary>
      LastTrackedOnly
    }
    public TrackingMode trackingMode = TrackingMode.Normal;
    private bool _trackingLocked = false;
    public bool trackingLocked {
      get {
        return _trackingLocked;
      }
      set {
        _trackingLocked = value;
        if (trackingMode == TrackingMode.Normal) {
          trackingMode = TrackingMode.LastTrackedOnly;
        }
        else if (trackingMode == TrackingMode.LastTrackedOnly) {
          trackingMode = TrackingMode.Normal;
        }
      }
    }

    private bool _firstRun = true;
    private Vector3? _originalLeftPupil = null;
    private Vector3? _originalRightPupil = null;

    private void setTrackingMode_Normal() {
      trackingMode = TrackingMode.Normal;
    }

    private void setTrackingMode_OriginalOnly() {
      trackingMode = TrackingMode.OriginalOnly;
    }

    private void setTrackingMode_LastTrackedOnly() {
      trackingMode = TrackingMode.LastTrackedOnly;
    }

    private void Start() {
      // Clear the log file on Start, if it exists.
      var logFilePath = Path.Combine(logFolder.Path,
        Path.ChangeExtension(logFileName, ".txt"));
      if (File.Exists(logFilePath)) {
        File.WriteAllText(logFilePath, "");
      }

      _originalIpdBiasMM = ipdBiasMM;
      _originalPositionBiasMM = positionBiasMM;

      // Check key adjust state in config.json.
      if (Config.TryRead<bool>(allowKeyAdjustConfig, ref keyAdjustEnabled)) {
        Debug.Log("Eye tracking key adjust set to " + keyAdjustEnabled +
          " from Config.");
      }

      tryLoadEyeAdjustmentsConfig();
    }

    private void OnApplicationQuit() {
      if (writeAdjustStateOnQuit) {
        writeEyeAdjustmentsConfig();
      }
    }

    private void tryLoadEyeAdjustmentsConfig() {
      // positionBiasMM
      if (Config.TryRead(eyeBiasAdjustConfig + "_positionBiasMM",
            ref positionBiasMM)) {
        Debug.Log("[Eye Tracking] Loaded positionBiasMM from Config: " + 
          positionBiasMM.ToString("R"));
      }

      // ipdBiasMM
      if (Config.TryRead(eyeBiasAdjustConfig + "_ipdBiasMM", ref ipdBiasMM)) {
        Debug.Log("[Eye Tracking] Loaded ipdBiasMM from Config: " +
          ipdBiasMM.ToString("R"));
      } 
    }

    private void writeEyeAdjustmentsConfig() {
      Config.Write(eyeBiasAdjustConfig + "_positionBiasMM", positionBiasMM);
      Config.Write(eyeBiasAdjustConfig + "_ipdBiasMM", ipdBiasMM);
    }

    private void Update() {
      // State changes.
      if (Input.GetKeyDown(eyeTrackingKeyCode)) {
        if (Input.GetKey(lastPositionsOnlyModifier)) {
          trackingLocked = !trackingLocked;
        }
        else {
          if (trackingMode == TrackingMode.OriginalOnly) {
            if (trackingLocked) {
              setTrackingMode_LastTrackedOnly();
            }
            else {
              setTrackingMode_Normal();
            }
          }
          else { // (trackingMode == TrackingMode.Normal)
            setTrackingMode_OriginalOnly();
          }
        }
      }

      // Eye bias controls.
      if (keyAdjustEnabled) {
        if (Input.GetKey(ipdShiftUpkey)) {
          ipdBiasMM += Time.deltaTime * keyShiftRate;
        }
        if (Input.GetKey(ipdShiftDownKey)) {
          ipdBiasMM -= Time.deltaTime * keyShiftRate;
        }
        if (Input.GetKey(positionBiasShiftUpKey)) {
          positionBiasMM += Vector3.up * Time.deltaTime * keyShiftRate;
        }
        if (Input.GetKey(positionBiasShiftDownKey)) {
          positionBiasMM += Vector3.down * Time.deltaTime * keyShiftRate;
        }
        if (Input.GetKey(positionBiasShiftForwardKey)) {
          positionBiasMM += Vector3.forward * Time.deltaTime * keyShiftRate;
        }
        if (Input.GetKey(positionBiasShiftBackKey)) {
          positionBiasMM += Vector3.back * Time.deltaTime * keyShiftRate;
        }
        if (Input.GetKeyDown(resetBiasesKey)) {
          ipdBiasMM = _originalIpdBiasMM;
          positionBiasMM = _originalPositionBiasMM;
        }
      }
    }

    private void LateUpdate() {
      if (leapProvider == null) return;

      using (new ProfilerSample("Get Eye Event Data")) {
        var controller = leapProvider.GetLeapController();

        var now = controller.Now();
        _curEyeEvent.left_eye_estimated_error = float.PositiveInfinity;
        _curEyeEvent.right_eye_estimated_error = float.PositiveInfinity;
        leapProvider.GetLeapController().GetInterpolatedEyePositions(
          toFill: ref _curEyeEvent,
          time: now
        );
      }

      var estimatedError = float.PositiveInfinity;
      using (new ProfilerSample("Convert Coords and Get Max Error")) {
        // Get Unity-coordinate eye positions relative to the Leap device.
        leftPupilPosition =
          unityPointFromDevicePoint(_curEyeEvent.left_eye_position);
        rightPupilPosition =
          unityPointFromDevicePoint(_curEyeEvent.right_eye_position);

        // Get error estimate. Merge both errors; we always want both eyes or none.
        estimatedError =
          Mathf.Max(_curEyeEvent.left_eye_estimated_error,
                    _curEyeEvent.right_eye_estimated_error);

        // If the error estimate is too high, kill the retrieved positions.
        if (estimatedError > maxAllowedError) {
          leftPupilPosition = null;
          rightPupilPosition = null;
        }
        updateTrackingReferenceObjects();
      }

      using (new ProfilerSample("Update Buffers and Render Debug")) {
        using (new ProfilerSample("Update Buffers")) {
          // Update the positions buffers for each eye.
          if (trackingMode != TrackingMode.LastTrackedOnly) {
            updatePositionsBuffer(ref _leftPupilPositions, leftPupilPosition,
              ref averageLeftPupil, leftPositionBiasMM + positionBiasMM);
            updatePositionsBuffer(ref _rightPupilPositions, rightPupilPosition,
              ref averageRightPupil, rightPositionBiasMM + positionBiasMM);
          }
          renderEyeSolveDebug();
        }

        // Remember last-tracked-only eye positions so IPD shifts
        // don't re-apply indefinitely in last-tracked-only mode.
        preIPDAverageLeftPupil = averageLeftPupil;
        preIPDAverageRightPupil = averageRightPupil;

        using (new ProfilerSample("Apply IPD shift")) {
          // Apply IPD shift, if any.
          if (averageLeftPupil.HasValue && averageRightPupil.HasValue) {
            var left = averageLeftPupil.Value;
            var right = averageRightPupil.Value;
            var ipdDir = (right - left).normalized;
            averageLeftPupil = left - ipdDir * ipdBiasMM * 0.001f;
            averageRightPupil = right + ipdDir * ipdBiasMM * 0.001f;
          }
        }
      }

      using (new ProfilerSample("Set Eye Transforms")) {
        if (_firstRun) {
          // Record the original positions pre-eye tracking.
          _originalLeftPupil = 
            trackerOrigin.worldToLocalMatrix.MultiplyPoint3x4(
              leftEyeTransform.position
            );
          _originalRightPupil = 
            trackerOrigin.worldToLocalMatrix.MultiplyPoint3x4(
              rightEyeTransform.position
            );
          _firstRun = false;
        }

        if (trackingMode == TrackingMode.OriginalOnly) {
          if (_originalLeftPupil.HasValue) {
            setEye(_originalLeftPupil.Value, leftEyeTransform,
              ref opticalCalibrationManager.currentCalibration.leftEye);
          }
          if (_originalRightPupil.HasValue) {
            setEye(_originalRightPupil.Value, rightEyeTransform,
              ref opticalCalibrationManager.currentCalibration.rightEye);
          }
        }
        else { // TrackingMode.Normal or TrackingMode.LastTrackedOnly
          if (averageLeftPupil.HasValue && averageRightPupil.HasValue
              && !logValuesOnly) {
            if (updateEyeTransforms) {

              var leftPupil = averageLeftPupil.Value;
              var rightPupil = averageRightPupil.Value;

              using (new ProfilerSample("Render Debug Spheres")) {
                if (renderPupilPositions) {
                  renderLocalSphere(leftPupil, EYE_RADIUS, leftColor);
                  renderLocalSphere(rightPupil, EYE_RADIUS, rightColor);
                }
              }

              setEye(leftPupil, leftEyeTransform,
                ref opticalCalibrationManager.currentCalibration.leftEye);
              lastTrackedLeftPupil = averageLeftPupil.Value;
              setEye(rightPupil, rightEyeTransform,
                ref opticalCalibrationManager.currentCalibration.rightEye);
              lastTrackedRightPupil = averageRightPupil.Value;
            }
          }
        }

      }

      if (renderOriginalPositions && _originalLeftPupil.HasValue
          && _originalRightPupil.HasValue
          && trackerOrigin != null) {
        renderLocalSphere(_originalLeftPupil.Value, EYE_RADIUS,
          Color.Lerp(leftColor, Color.black, 0.7f));
        renderLocalSphere(_originalRightPupil.Value, EYE_RADIUS,
          Color.Lerp(rightColor, Color.black, 0.7f));
      }

      if (logValuesOnly || logValues) {
        if (leftPupilPosition.HasValue && rightPupilPosition.HasValue) {
          var leftPupil_head = headFromTracker(leftPupilPosition.Value);
          var rightPupil_head = headFromTracker(rightPupilPosition.Value);

          File.AppendAllText(
            Path.Combine(logFolder.Path, Path.ChangeExtension(logFileName, ".txt")),
            System.DateTime.Now.ToString("O") + " -- " +
            "Left Eye: " + leftPupil_head.ToString("R") +
            Environment.NewLine +
            System.DateTime.Now.ToString("O") + " -- " +
            "Right Eye: " + rightPupil_head.ToString("R") +
            Environment.NewLine
          );

          if (_originalLeftPupil.HasValue && _originalRightPupil.HasValue) {
            var origLeftPupil_head = headFromTracker(_originalLeftPupil.Value);
            var origRightPupil_head = headFromTracker(_originalRightPupil.Value);
            File.AppendAllText(
              Path.Combine(logFolder.Path, Path.ChangeExtension(logFileName, ".txt")),
              System.DateTime.Now.ToString("O") + " -- " +
              "Left Eye DELTA: " + (leftPupil_head - origLeftPupil_head)
                .ToString("R") +
              Environment.NewLine +
              System.DateTime.Now.ToString("O") + " -- " +
              "Right Eye DELTA: " + (rightPupil_head - origRightPupil_head)
                .ToString("R") +
              Environment.NewLine
            );
          }
        }
      }

      // Finally, restore the pre-IPD-shift left and right eye average positions.
      averageLeftPupil = preIPDAverageLeftPupil;
      averageRightPupil = preIPDAverageRightPupil;
    }

    private Vector3 headFromTracker(Vector3 p) {
      return headTransform.worldToLocalMatrix.MultiplyPoint3x4(
        trackerOrigin.localToWorldMatrix.MultiplyPoint3x4(
          p
        )
      );
    }

    private void updateTrackingReferenceObjects() {
      if (leftPupilPosition.HasValue && rightPupilPosition.HasValue) {
        if (enableWhileBothTracked != null) {
          enableWhileBothTracked.gameObject.SetActive(false);
        }
      }
      else {
        if (enableWhileBothTracked != null) {
          enableWhileBothTracked.gameObject.SetActive(true);
        }
      }
      if (enableWhileLeftTracked != null) {
        enableWhileLeftTracked.gameObject.SetActive(
          _curEyeEvent.left_eye_estimated_error <= maxAllowedError);
      }
      if (enableWhileRightTracked != null) {
        enableWhileRightTracked.gameObject.SetActive(
          _curEyeEvent.right_eye_estimated_error <= maxAllowedError);
      }
      if (enableWhileHaveAverage != null) {
        enableWhileHaveAverage.gameObject.SetActive(
          averageLeftPupil.HasValue && averageRightPupil.HasValue
        );
      }
    }

    private void setEye(Vector3 position_tracker, Transform setEyeTransform,
                        ref OpticalCalibrationManager.ReflectorOptics eyeOptics,
                        Vector3 positionBiasMM = default(Vector3)) {
      setEyeTransform.position =
        trackerOrigin.transform.localToWorldMatrix.MultiplyPoint3x4(
          position_tracker
        );
      if (this.eyeTrackerHeadsetBasis != null) {
        setEyeTransform.position +=
          this.eyeTrackerHeadsetBasis.localToWorldMatrix.MultiplyVector(
            positionBiasMM * 0.001f
          );
      }
      var headTransform = opticalCalibrationManager.headTransform;
      eyeOptics.eyePosition = 
        headTransform != null ?
          headTransform.worldToLocalMatrix.MultiplyPoint3x4(
            setEyeTransform.position
          )
        : setEyeTransform.localPosition;
    }

    private Vector3 unityPointFromDevicePoint(LeapVector leapSpacePoint) {
      var scaledPoint = leapSpacePoint.ToVector3() * 0.001f;
      return new Vector3(-scaledPoint.x, -scaledPoint.z, scaledPoint.y);
    }

    private void renderLocalSphere(Vector3 localPosition, float radius,
                                   Color color) {
      var debugEyeSphere = new Sphere() {
        center = localPosition,
        radius = radius
      };

      if (trackerOrigin != null) {
        var debugDrawer = HyperMegaLines.drawer;
        debugDrawer.color = color;
        debugEyeSphere.DrawLines(
          debugDrawer.DrawLine,
          latitudinalDivisions: 6,
          longitudinalDivisions: 6,
          numCircleSegments: 22,
          matrixOverride: trackerOrigin.transform.localToWorldMatrix
        );
      }
    }

    private void renderLocalLine(Vector3 localA, Vector3 localB, Color color) {
      var debugDrawer = HyperMegaLines.drawer;
      debugDrawer.color = color;
      debugDrawer.DrawLine(
        trackerOrigin.transform.localToWorldMatrix.MultiplyPoint3x4(localA),
        trackerOrigin.transform.localToWorldMatrix.MultiplyPoint3x4(localB)
      );
    }

    private void updatePositionsBuffer(ref RingBuffer<Vector3> pupilPositions,
                                       Vector3? positionUpdate,
                                       ref Vector3? outFilteredPosition,
                                       Vector3? positionBiasMM = null) {
      if (pupilPositions == null
          || pupilPositions.Capacity != positionBufferSize) {
        pupilPositions = new RingBuffer<Vector3>(positionBufferSize);
      }

      if (positionUpdate.HasValue) {
        pupilPositions.Add(positionUpdate.Value);
      }
      else {
        pupilPositions.Clear();
      }

      if (pupilPositions.IsFull) {
        Vector3 sum = Vector3.zero;
        Vector3 bias = positionBiasMM.GetValueOrDefault() * 0.001f; // mm to m
        for (int i = 0; i < pupilPositions.Count; i++) {
          sum += pupilPositions[i] + bias;
        }
        outFilteredPosition = sum / pupilPositions.Count;
      }
      else {
        outFilteredPosition = null;
      }
    }

    private void renderEyeSolveDebug() {
      if (renderPupilPositions) {
        renderPositionsBuffer(_leftPupilPositions, leftColor, Color.gray);
        renderPositionsBuffer(_rightPupilPositions, rightColor, Color.gray);
      }
    }

    private void renderPositionsBuffer(RingBuffer<Vector3> positionsBuffer,
                                      Color startColor,
                                      Color endColor) {
      var startRadius = 0.002f;
      var endRadius = 0.0001f;
      var lastDraw = (Vector3?)null;
      for (int i = 0; i < positionsBuffer.Count; i++) {
        var blend = (1 - (i / (positionsBuffer.Count - 1f))).Clamped01();
        var pupilPos = positionsBuffer[i];
        var radius = Mathf.Lerp(startRadius, endRadius, blend);
        var color = Color.Lerp(startColor, endColor, blend);

        renderLocalSphere(pupilPos, radius, color);
        if (lastDraw.HasValue) {
          renderLocalLine(lastDraw.Value, pupilPos, color);
        }
        lastDraw = pupilPos;
      }
    }

  }

}
