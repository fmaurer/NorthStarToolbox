﻿using System.Collections;
using System.Collections.Generic;
using Leap.Unity.Geometry;
using UnityEngine;

namespace Leap.Unity.AR.Experiments {

  using Plane = Leap.Unity.Geometry.Plane;

  public class RigidbodyRespawner : MonoBehaviour {
    
    [Header("Rigidbodies")]

    public Transform findRigidbodiesInParent;

    [SerializeField]
    /// <summary> Serialized rigidbodies. Might be null. </summary>
    private List<Rigidbody> _rigidbodies;
    /// <summary> Lazily initialized rigidbodies. Never null. </summary>
    public List<Rigidbody> rigidbodies {
      get {
        if (_rigidbodies == null) {
          _rigidbodies = new List<Rigidbody>();
        }
        return _rigidbodies;
      }
      set { _rigidbodies = value; }
    }

    [Header("Respawn Rules")]

    /// <summary> Serialized respawn planes. Might be null. </summary>
    [SerializeField]
    private List<LocalPlane> _respawnPlanes;
    /// <summary> Lazily initialized respawn planes. Never null. </summary>
    public List<LocalPlane> respawnPlanes {
      get {
        if (_respawnPlanes == null) {
          _respawnPlanes = new List<LocalPlane>();
        } 
        return _respawnPlanes;
      }
      set { _respawnPlanes = value; }
    }

    [Header("Spawn Points (Random)")]

    public Transform findSpawnPointsInParent;

    [SerializeField]
    private List<Transform> _spawnPoints;
    public List<Transform> spawnPoints {
      get {
        if (_spawnPoints == null) {
          _spawnPoints = new List<Transform>();
        }
        return _spawnPoints; 
      }
      set { _spawnPoints = value; }
    }

    private void OnValidate() {
      refreshLists();
    }
    private void Reset() {
      refreshLists();
    }
    private void Start() {
      refreshLists();
    }

    private void refreshLists() {
      if (findRigidbodiesInParent != null) {
        rigidbodies.Clear();
        findRigidbodiesInParent.GetComponentsInChildren<Rigidbody>(rigidbodies);
      }
      if (findSpawnPointsInParent != null) {
        spawnPoints.Clear();
        findSpawnPointsInParent.GetAllChildren(spawnPoints);
      }
    }

    private int _checkBodyIdx = -1;
    private void advanceCheckBodyIndex() {
      if (rigidbodies.Count == 0) {
        _checkBodyIdx = -1;
      }
      _checkBodyIdx += 1;
      _checkBodyIdx %= rigidbodies.Count;
    }
    private Rigidbody getRigidbodyToCheck() {
      if (_checkBodyIdx == -1) {
        return null;
      }
      else {
        return rigidbodies[_checkBodyIdx];
      }
    }

    private void Update() {
      var bodyToCheck = getRigidbodyToCheck();
      advanceCheckBodyIndex();

      if (bodyToCheck != null) {
        // Check the current rigidbody against all respawn planes.
        bool shouldRespawn = false;
        foreach (var plane in _respawnPlanes) {
          if (plane.With(this.transform)
                .CollidesWith(bodyToCheck, includeBehindPlane: true)) {
            shouldRespawn = true;
            break;
          }
        }
        if (shouldRespawn) {
          respawnRigidbody(bodyToCheck);
        }
      }
    }

    private void respawnRigidbody(Rigidbody body) {
      if (spawnPoints.Count == 0) {
        Debug.LogWarning("RigidbodyRespawner has no spawn points attached. " +
          "Respawning cube to own transform...");
        spawnPoints.Add(this.transform);
      }

      var randomIdx = Random.Range(0, spawnPoints.Count);
      var spawnPose = spawnPoints[randomIdx].ToPose();
      body.transform.SetPose(spawnPose);
      body.SetPose(spawnPose);
      body.velocity = Vector3.zero;
      body.angularVelocity = Vector3.zero;
    }

    private void OnDrawGizmosSelected() {
      // Actual respawn plane surface.
      Gizmos.color = Color.Lerp(LeapColor.red, Color.black, 0.25f);
      foreach (var localPlane in respawnPlanes) {
        var plane = localPlane.With(this.transform);
        DrawLineQuad(plane, 0.10f);
        DrawLineQuad(plane, 1f);
        DrawLineQuad(plane, 10f);
        DrawLineQuad(plane, 100f);
      }

      // Back of plane.
      Gizmos.color = Color.Lerp(Color.gray, Color.black, 1f);
      foreach (var localPlane in respawnPlanes) {
        var plane = localPlane.With(this.transform);
        DrawLineQuad(plane, 0.1f, -0.001f);
        DrawLineQuad(plane, 1f,   -0.01f);
        DrawLineQuad(plane, 10f,  -0.05f);
        DrawLineQuad(plane, 100f, -0.1f);
      }

      // Draw spawn points.
      Gizmos.color = Color.Lerp(LeapColor.electricBlue, Color.black, 0.25f);
      foreach (var spawnPoint in spawnPoints) {
        Gizmos.matrix = spawnPoint.localToWorldMatrix;
        Gizmos.DrawWireSphere(Vector3.zero, 0.01f);
      }
    }

    private void DrawLineQuad(Plane plane, float scale, float zOffset = 0f) {
      var center = plane.pose.position;
      var rot = plane.pose.rotation;
      var up = scale * (rot * Vector3.up);
      var right = scale * (rot * Vector3.right);
      Vector3 a = up - right, b = up + right, c = -up + right, d = -up - right;

      a += center; b += center; c += center; d += center;

      var zShift = (rot * Vector3.forward * zOffset);
      a += zShift; b += zShift; c += zShift; d += zShift;

      Gizmos.DrawLine(a, b);
      Gizmos.DrawLine(b, c);
      Gizmos.DrawLine(c, d);
      Gizmos.DrawLine(d, a);
    }

  }

}
