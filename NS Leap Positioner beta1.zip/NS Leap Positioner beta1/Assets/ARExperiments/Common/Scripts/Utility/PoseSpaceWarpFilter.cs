﻿using System;
using System.Collections;
using System.Collections.Generic;
using Leap.Unity.Space;
using UnityEngine;

namespace Leap.Unity.AR.Experiments {

  public class PoseSpaceWarpFilter : MonoBehaviour,
                                     IStream<Pose>,
                                     IStreamReceiver<Pose> {

    public LeapSpace leapSpace;

    public event Action OnOpen = () => { };
    public event Action<Pose> OnSend = (x) => { };
    public event Action OnClose = () => { };

    private void Reset() {
      if (leapSpace == null) {
        leapSpace = FindObjectOfType<LeapSpace>();
      }
    }

    public void Open() {
      OnOpen();
    }

    public void Receive(Pose pose) {
      var warpedPose = warp(pose);
      OnSend(warpedPose);
    }

    public void Close() {
      OnClose();
    }

    private Pose warp(Pose pose) {
      var pose_leapSpace = leapSpace.transform.worldToLocalMatrix.GetPose()
        * pose;

      var position =
        leapSpace.transform.TransformPoint(
          leapSpace.transformer.TransformPoint(
            pose_leapSpace.position));

      var rotation =
        leapSpace.transform.TransformRotation(
          leapSpace.transformer.TransformRotation(
            pose_leapSpace.position,
            pose_leapSpace.rotation));

      return new Pose(position, rotation);
    }

  }

}