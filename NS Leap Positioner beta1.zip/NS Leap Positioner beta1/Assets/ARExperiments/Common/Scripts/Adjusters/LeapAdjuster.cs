﻿using Leap.Unity;
using Leap.Unity.Infix;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LeapAdjuster : MonoBehaviour {

  public Transform leapSensorTransform;

  [Header("Hotkeys")]
  [Tooltip("Nudges the Leap sensor angle up by 3 degrees per second.")]
  public KeyCode adjustUpKey = KeyCode.W;
  [Tooltip("Nudges the Leap sensor angle down by 3 degrees per second.")]
  public KeyCode adjustDownKey = KeyCode.S;
  [Tooltip("Nudges the Leap sensor angle left by 3 degrees per second.")]
  public KeyCode adjustLeftKey = KeyCode.A;
  [Tooltip("Nudges the Leap sensor angle right by 3 degrees per second.")]
  public KeyCode adjustRightKey = KeyCode.D;
  public KeyCode adjustForwardKey = KeyCode.Z;
  public KeyCode adjustBackwardKey = KeyCode.X;

  private void Reset() {
    if (leapSensorTransform == null) {
      var leapSensor = GetComponent<LeapXRServiceProvider>();
      if (leapSensor != null) {
        leapSensorTransform = leapSensor.transform;
      }
    }
  }

  private Quaternion _baseLeapSensorRotation;
  private Vector3 _baseLeapSensorPosition;
  public float localAngleAdjustUp = 0f;
  public float localAngleAdjustRight = 0f;
  public float localPositionAdjustForward = 0f;

  private void Start() {
    _baseLeapSensorRotation = leapSensorTransform.localRotation;
    _baseLeapSensorPosition = leapSensorTransform.localPosition;
  }

  private const float SPEED = 3f;

  private void Update() {
    if (Input.GetKey(adjustUpKey)) {
      localAngleAdjustUp += SPEED * Time.deltaTime;
    }
    if (Input.GetKey(adjustDownKey)) {
      localAngleAdjustUp -= SPEED * Time.deltaTime;
    }
    if (Input.GetKey(adjustRightKey)) {
      localAngleAdjustRight += SPEED * Time.deltaTime;
    }
    if (Input.GetKey(adjustLeftKey)) {
      localAngleAdjustRight -= SPEED * Time.deltaTime;
    }
    if (Input.GetKey(adjustForwardKey)) {
      localPositionAdjustForward += SPEED * Time.deltaTime;
    }
    if (Input.GetKey(adjustBackwardKey)) {
      localPositionAdjustForward -= SPEED * Time.deltaTime;
    }

    leapSensorTransform.localRotation = _baseLeapSensorRotation
                                        * Quaternion.AngleAxis(-localAngleAdjustUp, _baseLeapSensorRotation.GetRight())
                                        * Quaternion.AngleAxis(-localAngleAdjustRight, _baseLeapSensorRotation.GetUp());

    leapSensorTransform.localPosition = _baseLeapSensorPosition
      + Vector3.forward * localPositionAdjustForward;
  }

}
