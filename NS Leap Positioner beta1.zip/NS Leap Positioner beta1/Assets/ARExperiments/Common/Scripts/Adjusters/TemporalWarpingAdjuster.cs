﻿using System.Collections;
using System.Collections.Generic;
using Leap.Unity.Attributes;
using TMPro;
using UnityEngine;

namespace Leap.Unity.AR.Experiments {

  public class TemporalWarpingAdjuster : MonoBehaviour {

    public LeapXRServiceProvider xrServiceProvider;

    [Header("Text Output (Optional)")]
    public TextMeshPro temporalWarpingTextMesh;
    public string temporalWarpingPrefix = "[Y][H] Temporal Warping: ";
    
    private void Reset() {
      if (xrServiceProvider == null) {
        xrServiceProvider = FindObjectOfType<LeapXRServiceProvider>();
      } 
    } 

    private void Update() {
      if (xrServiceProvider != null) {
        if (Input.GetKeyDown(KeyCode.Y)) {
          xrServiceProvider.warpingAdjustment += 1;
        }
        if (Input.GetKeyDown(KeyCode.H)) {
          xrServiceProvider.warpingAdjustment -= 1;
        }
        if (temporalWarpingTextMesh != null) {
          temporalWarpingTextMesh.text = temporalWarpingPrefix +
            xrServiceProvider.warpingAdjustment;
        }
      }
      else {
        temporalWarpingTextMesh.text = temporalWarpingPrefix +
          " N/A (no provider reference)";
      }
    }

  }

}
