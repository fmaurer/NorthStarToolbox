﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Leap.Unity.AR.Experiments {

  public class VerticalHeightAdjuster : MonoBehaviour {
    
    public Transform adjustTransform;
    public float adjustSpeed = 0.25f; // meters / sec
    public KeyCode adjustUpKey = KeyCode.UpArrow;
    public KeyCode adjustDownkey = KeyCode.DownArrow;

    private void Reset() {
      if (adjustTransform == null) adjustTransform = this.transform;
    }

    private void Update() {
      var adjustAmount = Vector3.zero;
      if (Input.GetKey(adjustUpKey)) {
        adjustAmount += Vector3.up * adjustSpeed * Time.deltaTime;
      }
      if (Input.GetKey(adjustDownkey)) {
        adjustAmount += Vector3.down * adjustSpeed * Time.deltaTime;
      }

      if (adjustTransform != null) {
        adjustTransform.position += adjustAmount;
      }
    }

  }

}
