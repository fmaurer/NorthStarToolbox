﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Leap.Unity.AR.Experiments {

  public class ScreenTweaker : MonoBehaviour {
    
    public Transform leftScreen;
    public Transform rightScreen;

    public float shiftRate = 0.002f;
    public float twistRate = 5f;

    public KeyCode shiftUpKey = KeyCode.Keypad8;
    public KeyCode shiftDownKey = KeyCode.Keypad5;
    public KeyCode shiftInKey = KeyCode.Keypad4;
    public KeyCode shiftOutKey = KeyCode.Keypad6;
    [Tooltip("Local twist counter-clockwise.")]
    public KeyCode twistInKey = KeyCode.Keypad7;
    [Tooltip("Local twist clockwise.")]
    public KeyCode twistOutKey = KeyCode.Keypad9;

    private void Update() {
      ifKeyMoveLinear(shiftUpKey, Vector3.up, shiftRate);
      ifKeyMoveLinear(shiftDownKey, Vector3.down, shiftRate);
      ifKeyMoveLinear(shiftInKey, Vector3.left, shiftRate);
      ifKeyMoveLinear(shiftOutKey, Vector3.right, shiftRate);

      ifKeyRotate(twistInKey, Vector3.back, twistRate);
      ifKeyRotate(twistOutKey, Vector3.forward, twistRate);
    }

    private void ifKeyMoveLinear(KeyCode key, Vector3 localDir, float rate) {
      if (Input.GetKey(key)) {
        leftScreen.localPosition += rate * Time.deltaTime * mirrorX(localDir);
        rightScreen.localPosition += rate * Time.deltaTime * localDir;
      }
    }

    private void ifKeyRotate(KeyCode key, Vector3 localAxis, float rate) {
      if (Input.GetKey(key)) {
        leftScreen.localRotation *= Quaternion.AngleAxis(rate * Time.deltaTime,
          -localAxis);
        rightScreen.localRotation *= Quaternion.AngleAxis(rate * Time.deltaTime,
          localAxis);
      }
    }

    private Vector3 mirrorX(Vector3 v) {
      return new Vector3(-v.x, v.y, v.z);
    }

  }

}
