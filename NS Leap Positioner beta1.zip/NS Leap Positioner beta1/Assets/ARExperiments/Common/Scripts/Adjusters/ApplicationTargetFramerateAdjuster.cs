﻿using System.Collections;
using System.Collections.Generic;
using Leap.Unity.Attributes;
using TMPro;
using UnityEngine;

namespace Leap.Unity.AR.Experiments {

  public class ApplicationTargetFramerateAdjuster : MonoBehaviour {

    public bool setOnStart = false;
    [DisableIf("setOnStart", isEqualTo: false)]
    public int setTargetFrameRateTo = 120;

    [Header("Text Output (Optional)")]
    public TextMeshPro frameRateTextMesh;
    public string frameRatePrefix = "[X][V] Target Frame Rate: ";
    public TextMeshPro vsyncTextMesh;
    public string vsyncPrefix = "[B] Vsync Count: ";

    private void Start() {
      if (setOnStart) {
        Application.targetFrameRate = setTargetFrameRateTo;
      }
    }
    
    private bool _firstUpdate = true;
    private void Update() {
      if (_firstUpdate) {
        Debug.Log("Application.targetFrameRate: " + Application.targetFrameRate);

        _firstUpdate = false;
      }

      if (frameRateTextMesh != null) {
        frameRateTextMesh.text = frameRatePrefix + Application.targetFrameRate;
      }

      if (Input.GetKeyDown(KeyCode.X)) {
        Application.targetFrameRate = 119;
      }

      if (vsyncTextMesh != null) {
        vsyncTextMesh.text = vsyncPrefix + QualitySettings.vSyncCount;
      }
      if (Input.GetKeyDown(KeyCode.B)) {
        if (QualitySettings.vSyncCount == 0) {
          QualitySettings.vSyncCount = 1;
        }
        else if (QualitySettings.vSyncCount == 1) {
          QualitySettings.vSyncCount = 0; 
        }
      }
    }

  }

}
