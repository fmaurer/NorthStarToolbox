﻿using Leap.Unity.AR;
using Leap.Unity.Attributes;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LeapDeviceTrackingAdjusterText : MonoBehaviour {

  public LeapDeviceTrackingAdjuster deviceTrackingAdjuster;
  public TextMesh text;

  private void Update() {
    if (deviceTrackingAdjuster != null && text != null) {
      if (!deviceTrackingAdjuster.setOptiTrackScaleInstead) {
        text.text = "Scale factor: " + deviceTrackingAdjuster.leapDeviceTracking.positionScaleFactor.ToString("F4");
      } else {
        text.text = "Scale factor: " + deviceTrackingAdjuster.driftCorrector.truthPositionMultiplier.ToString("F4");
      }
    }
  }

}
