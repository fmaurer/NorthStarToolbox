﻿using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

namespace Leap.Unity.AR.Experiments {

  public class OdometryExtrapolationAdjuster : MonoBehaviour {
    
    [Header("Extrapolation Adjustment")]
    public LeapDeviceTracking leapDeviceTracking;
    public KeyCode posExtrapUpKey = KeyCode.P;
    public KeyCode posExtrapDownKey = KeyCode.Semicolon;
    public KeyCode rotExtrapUpKey = KeyCode.O;
    public KeyCode rotExtrapDownKey = KeyCode.L;
    public float speed = 2000;

    [Header("TextMeshPro Readout (Optional)")]
    public TextMeshPro posExtrapTextMesh;
    public string posExtrapPrefix = "Pos Extrap: ";
    public TextMeshPro rotExtrapTextMesh;
    public string rotExtrapPrefix = "Rot Extrap: ";

    private void Reset() {
      if (leapDeviceTracking == null) {
        leapDeviceTracking = FindObjectOfType<LeapDeviceTracking>();
      }
    }

    private void Update() {
      if (leapDeviceTracking != null) {
        if (Input.GetKey(posExtrapUpKey)) {
          leapDeviceTracking.extrapolationAmount +=
            (long)(speed * Time.deltaTime);
        }
        if (Input.GetKey(posExtrapDownKey)) {
          leapDeviceTracking.extrapolationAmount -=
            (long)(speed * Time.deltaTime);
        }
        if (Input.GetKey(rotExtrapUpKey)) {
          if (!leapDeviceTracking.useDifferentRotationExtrapolation) {
            leapDeviceTracking.rotationExtrapolationAmount = 
              leapDeviceTracking.extrapolationAmount;
            leapDeviceTracking.useDifferentRotationExtrapolation = true;
          }
          leapDeviceTracking.rotationExtrapolationAmount +=
            (long)(speed * Time.deltaTime);
        }
        if (Input.GetKey(rotExtrapDownKey)) {
          if (!leapDeviceTracking.useDifferentRotationExtrapolation) {
            leapDeviceTracking.rotationExtrapolationAmount = 
              leapDeviceTracking.extrapolationAmount;
            leapDeviceTracking.useDifferentRotationExtrapolation = true;
          }
          leapDeviceTracking.rotationExtrapolationAmount -=
            (long)(speed * Time.deltaTime);
        }

        if (posExtrapTextMesh != null) {
          posExtrapTextMesh.text = posExtrapPrefix +
            leapDeviceTracking.extrapolationAmount;
        }
        if (rotExtrapTextMesh != null) {
          rotExtrapTextMesh.text = rotExtrapPrefix +
            leapDeviceTracking.rotationExtrapolationAmount;
        }
      }
    }

  }

}
