﻿using Leap.Unity.AR;
using Leap.Unity.Attributes;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LeapDeviceTrackingAdjuster : MonoBehaviour {

  public LeapDeviceTracking leapDeviceTracking;

  public KeyCode increasePositionScaleFactorKey = KeyCode.I;
  public KeyCode decreasePositionScaleFactorKey = KeyCode.K;

  public bool setOptiTrackScaleInstead;
  [DisableIf("setOptiTrackScaleInstead", isEqualTo: false)]
  public DriftCorrector driftCorrector;

  private void Reset() {
    if (leapDeviceTracking == null) leapDeviceTracking = GetComponent<LeapDeviceTracking>();
  }

  private const float SPEED = 0.4f;

  private void Update() {
    if (leapDeviceTracking != null) {
      if (Input.GetKey(increasePositionScaleFactorKey)) {
        if (setOptiTrackScaleInstead) {
          driftCorrector.truthPositionMultiplier += SPEED * Time.deltaTime;
        }
        else {
          leapDeviceTracking.positionScaleFactor += SPEED * Time.deltaTime;
        }
      }
      if (Input.GetKey(decreasePositionScaleFactorKey)) {
        if (setOptiTrackScaleInstead) {
          driftCorrector.truthPositionMultiplier -= SPEED * Time.deltaTime;
        }
        else {
          leapDeviceTracking.positionScaleFactor -= SPEED * Time.deltaTime;
        }
      }
    }
  }

}
