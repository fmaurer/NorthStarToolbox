﻿using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

namespace Leap.Unity.AR.Experiments {

  public class OnPreRenderUpdateAdjuster : MonoBehaviour {

    public TextMeshPro textMesh;
    public LeapDeviceTracking deviceTracking;
    
    private void Update () {
      if (Input.GetKeyDown(KeyCode.BackQuote)) {
        deviceTracking.useLateUpdate = !deviceTracking.useLateUpdate;
      }

      if (deviceTracking != null && textMesh != null) {
        textMesh.text = "[`] Use OnPreRender Update: " +
          !deviceTracking.useLateUpdate;
      }
    }

  }

}