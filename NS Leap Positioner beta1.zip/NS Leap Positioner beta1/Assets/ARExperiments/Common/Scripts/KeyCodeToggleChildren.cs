using System.Collections.Generic;
using UnityEngine;

namespace Leap.Unity.AR.Experiments {

  public class KeyCodeToggleChildren : MonoBehaviour {

    public bool startEnabled = true;
    public KeyCode toggleKey = KeyCode.Space;
    public List<Transform> children = new List<Transform>();

    private void OnValidate() {
      refreshChildren();
    }

    private void Start() {
      refreshChildren();

      if (startEnabled) {
        EnableChildren();
      }
      else {
        DisableChildren();
      }
    }

    private void refreshChildren() {
      children.Clear();

      for (int i = 0; i < this.transform.childCount; i++) {
        children.Add(this.transform.GetChild(i));
      }
    }

    private void Update() {
      refreshChildren();      

      if (Input.GetKeyDown(toggleKey)) {
        ToggleChildren();
      }
    }

    private bool _childrenEnabled = false;
    public bool childrenEnabled {
      get { return _childrenEnabled; }
    }

    public void ToggleChildren() {
      if (!_childrenEnabled) {
        EnableChildren();
      }
      else {
        DisableChildren();
      }
    }

    public void EnableChildren() {
      _childrenEnabled = true;
      foreach (var child in children) {
        child.gameObject.SetActive(true);
      }
    }

    public void DisableChildren() {
      _childrenEnabled = false;
      foreach (var child in children) {
        child.gameObject.SetActive(false);
      }
    }

  }

}