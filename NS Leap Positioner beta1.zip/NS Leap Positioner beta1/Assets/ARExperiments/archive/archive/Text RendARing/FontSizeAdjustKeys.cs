﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FontSizeAdjustKeys : MonoBehaviour {

  public TextRendererController textRendererController;

  public KeyCode sizeIncreaseKey = KeyCode.Y;
  public KeyCode sizeDecreaseKey = KeyCode.H;

  void Reset() {
    if (textRendererController == null) {
      textRendererController = GetComponent<TextRendererController>();
    }
  }

  private const float SPEED = 0.5f;
  
  void Update() {
    if (textRendererController != null) {
      if (Input.GetKey(sizeIncreaseKey)) {
        textRendererController.fontSizeMultiplier += SPEED * Time.deltaTime;
      }
      if (Input.GetKey(sizeDecreaseKey)) {
        textRendererController.fontSizeMultiplier -= SPEED * Time.deltaTime;
      }
    }
  }
}
