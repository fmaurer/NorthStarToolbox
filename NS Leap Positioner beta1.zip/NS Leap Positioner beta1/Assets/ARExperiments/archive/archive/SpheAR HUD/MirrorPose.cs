﻿using Leap.Unity.Geometry;
using UnityEngine;

namespace Leap.Unity.AR.Experiments {

  using Pose = Leap.Unity.Pose;

  [ExecuteInEditMode]
  public class MirrorPose : MonoBehaviour {

    public Transform matchMirroredPose;
    public Transform relativeToTransform;

    public enum Axis { X }
    public Axis mirrorAxis = Axis.X;

    private void Reset() {
      if (relativeToTransform == null) {
        relativeToTransform = this.transform.parent;
      }
    }

    private void Update() {
      if (relativeToTransform != null && matchMirroredPose != null) {
        var pose_relative = relativeToTransform.worldToLocalMatrix.GetPose() *
          matchMirroredPose.transform.ToPose();

        var mirroredPose_relative = pose_relative.MirroredX();

        this.transform.SetPose(relativeToTransform.localToWorldMatrix.GetPose() *
          mirroredPose_relative);
      }
    }

  }

}