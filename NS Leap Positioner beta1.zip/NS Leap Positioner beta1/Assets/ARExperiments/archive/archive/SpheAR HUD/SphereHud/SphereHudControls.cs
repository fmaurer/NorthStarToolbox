﻿using UnityEngine;
using Leap.Unity;
using Leap.Unity.DevGui;
using Leap.Unity.Interaction;

[ExecuteInEditMode]
public class SphereHudControls : MonoBehaviour {

  public Transform headTransform;

  [Range(0.01f, 0.5f)]
  public float radius;

  [Range(-0.5f, 0.5f)]
  public float xOffset;

  [Range(-0.5f, 0.5f)]
  public float yOffset;

  [Range(0f, 0.5f)]
  public float zOffset;

  public bool autoFollowHead;

  [Range(0, 0.2f)]
  public float minDist = 0.01f;

  [Range(0, 0.2f)]
  public float maxDist = 0.06f;

  public InteractionBehaviour intObj;

  public KeyCode radiusUpKey = KeyCode.Keypad8;
  public KeyCode radiusDownKey = KeyCode.Keypad2;

  public float speed = 0.3f;

  private void Start() {
    if (intObj == null) intObj = GetComponent<InteractionBehaviour>();
    if (intObj != null) {
      intObj.OnGraspEnd += loadPosition;
    }
  }

  private bool _alwaysDisplaySphere = false;

  private void Update() {
    if (Input.GetKey(radiusUpKey)) {
      radius += speed * Time.deltaTime;
    }
    if (Input.GetKey(radiusDownKey)) {
      radius -= speed * Time.deltaTime;
    }

    transform.localScale = Vector3.one * radius * 2;

    Material material;
    if (!Application.isPlaying) {
      material = GetComponent<Renderer>().sharedMaterial;
    }
    else  {
      material = GetComponent<Renderer>().material;
    }

    if (Input.GetKeyDown(KeyCode.Keypad5)) {
      _alwaysDisplaySphere = !_alwaysDisplaySphere;
    }

    if (_alwaysDisplaySphere) {
      material.SetVector("_ProximityMapping", new Vector4(minDist, maxDist, 1, 1));
    }
    else {
      material.SetVector("_ProximityMapping", new Vector4(minDist, maxDist, 1, 0));
    }
  }

  private void LateUpdate() {
    if (intObj == null || !intObj.isGrasped) {
      if (autoFollowHead) {
        updateSphereLocation();
      }
    }
  }

  [DevButton("Recenter")]
  private void updateSphereLocation() {
    Transform target = headTransform;
    if (target == null) return;

    transform.position = target.position + target.right * xOffset +
                                           target.up * yOffset +
                                           target.forward * zOffset;
  }

  private void loadPosition() {
    var pose_head = headTransform.ToPose().inverse * this.transform.ToPose();

    this.xOffset = pose_head.position.x;
    this.yOffset = pose_head.position.y;
    this.zOffset = pose_head.position.z;
  }

}
