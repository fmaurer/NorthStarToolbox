﻿using Leap.Unity.Space;
using UnityEngine;

namespace Leap.Unity.AR.Experiments {

  public class LocalPositionAdjuster : MonoBehaviour {

    public Transform target;

    public KeyCode adjustZMore = KeyCode.KeypadPlus;
    public KeyCode adjustZLess = KeyCode.KeypadMinus;

    public float speed = 0.2f;

    private void Update() {
      if (Input.GetKey(adjustZMore)) {
        adjustLocalZ(target, speed * Time.deltaTime);
      }
      if (Input.GetKey(adjustZLess)) {
        adjustLocalZ(target, -speed * Time.deltaTime);
      }
    }

    private void adjustLocalZ(Transform t, float adjustAmount) {
      var p = t.localPosition;
      t.localPosition = new Vector3(p.x, p.y, p.z + adjustAmount);
    }

  }

}