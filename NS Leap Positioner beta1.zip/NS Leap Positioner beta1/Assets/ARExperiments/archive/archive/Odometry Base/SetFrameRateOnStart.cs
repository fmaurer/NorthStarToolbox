﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Leap.Unity.AR.Experiments {

  public class SetFrameRateOnStart : MonoBehaviour {

    public int setTargetFrameRateTo = 120;

    void Start() {
      Application.targetFrameRate = setTargetFrameRateTo;
    }
    
  }

}
