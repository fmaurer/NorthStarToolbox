﻿using System.Collections;
using System.Collections.Generic;
using Leap.Unity.Geometry;
using Leap.Unity.HyperMegaStuff;
using Leap.Unity.RuntimeGizmos;
using UnityEngine;

namespace Leap.Unity.AR.Experiments {

  [ExecuteInEditMode]
  public class WireRenderer : MonoBehaviour {

    public Color color = Color.white;
    [SerializeField]
    private LocalCircle _circle;
    public Circle circle {
      get { return _circle.With(this.transform); }
    }

    private void Update() {
      HyperMegaLines.drawer.color = this.color;
      circle.DrawLines(lineDrawingFunc: HyperMegaLines.drawer.DrawLine);
    }

  }

}
