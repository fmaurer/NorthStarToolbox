﻿using UnityEngine;
using Leap.Unity.Graphing;

public class OdometryPositionDelta : MonoBehaviour {

  Vector3 lastPosition = Vector3.zero;

	private void Update() {
    if (RealtimeGraph.Instance == null ||
        !RealtimeGraph.Instance.enabled ||
        !RealtimeGraph.Instance.gameObject.activeInHierarchy) {
      return;
    }

    RealtimeGraph.Instance.AddSample("Odometry Position Delta", 
      RealtimeGraph.GraphUnits.Miliseconds, 
      (transform.position - lastPosition).magnitude);
    lastPosition = transform.position;
  }
  
}
