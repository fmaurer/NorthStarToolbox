﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Leap.Unity.AR.Experiments {

  public class FollowLeapDeviceHeadPose : MonoBehaviour {
    
    public LeapDeviceTracking leapDeviceTracking;
    public Transform headToMove;
    public Transform leapToMove;

    private void Start() {
      if (leapDeviceTracking != null) {
        leapDeviceTracking.debugCallPerHeadPose = this.onReceiveHeadPose;
        leapDeviceTracking.debugCallPerLeapPose = this.onReceiveLeapPose;
      }
    }

    private void onReceiveHeadPose(Pose pose) {
      if (headToMove != null) {
        headToMove.SetLocalPose(pose);
      }
    }

    private void onReceiveLeapPose(Pose pose) {
      if (leapToMove != null) {
        leapToMove.SetLocalPose(pose);
      }
    }

  }

}
