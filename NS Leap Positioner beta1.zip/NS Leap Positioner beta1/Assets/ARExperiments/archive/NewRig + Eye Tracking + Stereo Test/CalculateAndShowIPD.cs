﻿using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

namespace Leap.Unity.AR.Experiments {

  public class CalculateAndShowIPD : MonoBehaviour {
    
    public Transform leftEye;
    public Transform rightEye;

    public TextMeshPro textMesh;

    private void Update() {
      var distance = (leftEye.position - rightEye.position).magnitude;
      textMesh.text = "IPD: " + (distance * 1000f).ToString("F4");
    }

  }

}
