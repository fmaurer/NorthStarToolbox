using Leap.Unity.Attributes;
using UnityEngine;

namespace Leap.Unity.AR.Experiments {

  public class NoARTestAppGlobals : AppGlobals<NoARTestAppGlobals> {
    
    [Header("Spawned Blocks")]
    public NoARTestBlock blockToSpawn;
    public RandomColorList playerColors;
    public Color nonLocalPlayerColor = Color.gray;
    public KeyCode haltSyncEventsKey = KeyCode.Space;

    [Header("Local Testing Mode")]
    [Tooltip("Place remote objects on a separate layer to allow two clients to " +
      "connect in a single Unity instance, e.g., the editor.")]
    public bool useLocalTestingMode = false;
    public SingleLayer localLayer;
    public SingleLayer remoteLayer;

  }

}
