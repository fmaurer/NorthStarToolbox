﻿using System.Collections;
using System.Collections.Generic;
using Leap.Unity.Networking;
using UnityEngine;

namespace Leap.Unity.AR.Experiments {

  public class NoARTestSceneControl : MonoBehaviour {
    
    public Camera raycastCamera;
    public LeapNetManager network;
    public float clickStrength = 1f;
    public float spawnHeight = 0.1f;
    public KeyCode haltSyncEventsKey = KeyCode.Space;

    private RaycastHit[] _hitsBuffer = new RaycastHit[32];

    private void Update() {
      if (Input.GetMouseButtonDown(0)) {
        onMouseClick();
      }
    }

    private void OnGUI() {
      if (Input.GetKey(haltSyncEventsKey)) {
        GUI.Box(new Rect(0, 0, 300, 50), "Sync events halted.....");
      }
    }

    private void onMouseClick() {
      var mouseRay = raycastCamera.ScreenPointToRay(Input.mousePosition);
      int numHits = Physics.RaycastNonAlloc(mouseRay, _hitsBuffer, 100f, ~0);
      var rayOrigin = mouseRay.origin;
      var closestDist = float.PositiveInfinity;
      var shouldSpawnBlock = false;
      var closestHitWasApplyForce = false;
      var closestHitPoint = Vector3.zero;
      var closestHitNormal = Vector3.up;
      var closestHitRigidbody = (Rigidbody)null;
      var closestHitBlock = (NoARTestBlock)null;
      for (int i = 0; i < numHits; i++) {
        var hit = _hitsBuffer[i];
        if (hit.collider != null) {
          var careAboutHit = false;
          if (hit.collider.GetComponentInParent<NoARTestSceneSpawnableSurface>() !=
              null) {
            closestHitWasApplyForce = false;
            closestHitRigidbody = null;
            careAboutHit = true;
            shouldSpawnBlock = true;
          }
          else if (hit.collider.GetComponentInParent<NoARTestBlock>() != null) {
            closestHitBlock = hit.collider.GetComponentInParent<NoARTestBlock>();
            closestHitWasApplyForce = true;
            closestHitRigidbody = hit.collider.attachedRigidbody;
            careAboutHit = true;
          }

          if (careAboutHit) {
            var testDist = Vector3.Distance(hit.point, rayOrigin);
            if (testDist < closestDist) {
              closestHitPoint = hit.point;
              closestHitNormal = hit.normal;
              closestDist = testDist;
            }
          }
        }
      }
      if (closestHitBlock != null || shouldSpawnBlock) {
        if (!closestHitWasApplyForce) {
          if (network.hasLocalPlayerId) {
            network.RequestSpawn(
              new NoARTestBlock.NoARTestBlockSyncEvent() {
                pose = new Pose(closestHitPoint + closestHitNormal * spawnHeight,
                  Quaternion.LookRotation(Random.onUnitSphere)),
                localScale = Vector3.one
              }
            );
          }
        }
        else {
          if (closestHitRigidbody != null && closestHitBlock != null) {
            if (closestHitBlock.netState == LeapNetState.LocalAuthority) {
              var position = closestHitPoint;
              var direction = (closestHitRigidbody.position - closestHitPoint)
                .normalized;
              closestHitRigidbody.AddForceAtPosition(direction * clickStrength,
                position, ForceMode.Impulse);
            }
            else {
              // Request authority.
              //Debug.Log("Requesting authority...");
              var position = closestHitPoint;
              var direction = (closestHitRigidbody.position - closestHitPoint)
                .normalized;
              {
                // Adjust the direction a bit
                direction = new Vector3(direction.x, Mathf.Abs(direction.y),
                  direction.z);
                direction = new Vector3(direction.x, direction.y / 2f,
                  direction.z);
                direction = direction.normalized;
              }
              var force = direction * clickStrength;
              closestHitBlock.RequestAuthority<NoARTestBlock>(
                onSuccess: (block) => {
                  //Debug.Log("Got authority!");
                  block.GetComponent<Rigidbody>().AddForceAtPosition(force,
                    position, ForceMode.Impulse);
                },
                onFailure: (block, err) => {
                  Debug.LogError("Failed to get authority: " + err);
                }
              );
            }
          }
        }
      }
    }

  }

}
