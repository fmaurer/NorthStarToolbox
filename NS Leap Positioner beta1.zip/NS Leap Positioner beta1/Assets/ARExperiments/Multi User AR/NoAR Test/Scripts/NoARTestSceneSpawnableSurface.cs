﻿using UnityEngine;

public class NoARTestSceneSpawnableSurface : MonoBehaviour { }
