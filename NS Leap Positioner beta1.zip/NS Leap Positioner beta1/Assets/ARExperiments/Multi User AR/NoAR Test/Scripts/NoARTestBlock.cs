﻿using System.Collections;
using System.Collections.Generic;
using Leap.Unity.Networking;
using Leap.Unity.Networking.Events;
using UnityEngine;
using Leap.Unity.Encoding;
using Leap.Unity.Splines;

namespace Leap.Unity.AR.Experiments {

  public class NoARTestBlock : LeapNetObject {

    /// <summary>
    /// A simple public control to test turning sync events on and off for this
    /// object.
    /// </summary>
    public bool allowSyncEvents = true;

    public ColorControl colorControl;

    [Tooltip("The interval (in seconds) in which transform updates are sent out " +
      "or checked.")]
    public float updateInterval = 0.03f;

    public new Rigidbody rigidbody;
    private LeapNetInterpolator<NoARTestBlockSyncEvent> interpolator =
      new LeapNetInterpolator<NoARTestBlockSyncEvent>();

    public struct NoARTestBlockSyncEvent : ILeapNetSpawnable,
      IInterpolable<NoARTestBlockSyncEvent>
    {
      public int networkId;
      public int GetNetworkId() { return networkId; }
      public void SetNetworkId(int networkId) { this.networkId = networkId; }

      public Pose pose;
      public Vector3 localScale;

      /// <summary> Copies a SyncEvent from another SyncEvent </summary>
      public NoARTestBlockSyncEvent CopyFrom(NoARTestBlockSyncEvent h) {
        pose = h.pose;
        localScale = h.localScale;
        return this;
      }

      public bool FillLerped(NoARTestBlockSyncEvent a, NoARTestBlockSyncEvent b,
        float t)
      {
        pose = Pose.LerpUnclamped(a.pose, b.pose, t);
        localScale = Vector3.LerpUnclamped(a.localScale, b.localScale, t);
        return true;
      }

      public bool FillSplined(NoARTestBlockSyncEvent a, NoARTestBlockSyncEvent b,
        NoARTestBlockSyncEvent c, NoARTestBlockSyncEvent d, float t)
      {
        pose.position = CatmullRom.ToCHS(a.pose.position, b.pose.position,
          c.pose.position, d.pose.position, false).PositionAt(t);
        pose.rotation = Quaternion.SlerpUnclamped(b.pose.rotation,
          c.pose.rotation, t);
        localScale = CatmullRom.ToCHS(a.localScale, b.localScale, c.localScale,
          d.localScale, false).PositionAt(t);
        return true;
      }
    }

    [SpawnHandler(typeof(NoARTestBlockSyncEvent))]
    public static LeapNetObject HandleSpawn(LeapNetManager network,
      int spawnedNetworkId, bool hasLocalAuthority,
      NoARTestBlockSyncEvent spawnState, int spawnRequestId)
    {
      Debug.Log("NetworkedBlock got HandleSpawn, spawnedNetworkId: " +
        spawnedNetworkId);

      var app = NoARTestAppGlobals.instance;
      var block = GameObject.Instantiate(app.blockToSpawn);
      var blockObj = block.gameObject;
      blockObj.SetActive(true);

      block.NotifyNetworkSpawned(network, spawnedNetworkId, hasLocalAuthority);

      // Special: To allow one editor to run two clients, only the block that
      // has local authority lives on the "main" layer.
      var isLocalTestingMode = app.useLocalTestingMode;
      if (isLocalTestingMode) block.updateLocalTestingModeRepresentation();

      block.interpolator.enqueueUpdate(spawnState, block.updateInterval);
      block.syncState(spawnState);
      return block;
    }

    [DespawnHandler(typeof(NoARTestBlockSyncEvent))]
    public static bool HandleDespawn(LeapNetObject objectToDespawn) {
      objectToDespawn.NotifyNetworkDespawned();
      Destroy(objectToDespawn.gameObject);
      return true;
    }

    private void OnEnable() {
      OnNetworkSpawned -= registerSyncEventListener;
      OnNetworkSpawned += registerSyncEventListener;
      OnNetworkDespawned -= unregisterSyncEventListener;
      OnNetworkDespawned += unregisterSyncEventListener;
      OnAuthorityChanged -= onAuthority;
      OnAuthorityChanged += onAuthority;
      if (colorControl == null) { colorControl = GetComponent<ColorControl>(); }
      rigidbody = GetComponent<Rigidbody>();
    }

    private void OnDisable() { }

    private void registerSyncEventListener() {
      network.Log("[" + netState + "] Registered sync event listener.");
      network.RegisterEventListener<NoARTestBlockSyncEvent>(networkId, this);
    }

    private void unregisterSyncEventListener() {
      network.RegisterEventListener<NoARTestBlockSyncEvent>(networkId, this);
    }

    private void onAuthority() {
      if (netState == LeapNetState.Remote) {
        NoARTestBlockSyncEvent syncEvent = new NoARTestBlockSyncEvent {
          pose = transform.ToPose(),
          localScale = transform.localScale
        };
        interpolator.clearToState(syncEvent);
      }
    }

    private float _skipTimer = 0;
    private void Update() {
      var shouldUpdateNetwork = false;
      float effectiveUpdateInterval = updateInterval;

      using (new ProfilerSample("Update skip timer")) {
        if (rigidbody.IsSleeping()) effectiveUpdateInterval *= 20f;

        if ((_skipTimer += Time.unscaledDeltaTime) > effectiveUpdateInterval) {
          _skipTimer -= effectiveUpdateInterval;
          shouldUpdateNetwork = true;
        }
      }

      var app = NoARTestAppGlobals.instance;

      // Halt events key
      if (Input.GetKey(app.haltSyncEventsKey)) {
        shouldUpdateNetwork = false;
      }

      // Player color (currently just "local" vs. "not-local")
      Color blockColor;
      if (network.hasLocalPlayerId && netState == LeapNetState.LocalAuthority) {
        blockColor = app.playerColors[network.localPlayerId];
      }
      else {
        blockColor = app.nonLocalPlayerColor;
      }
      colorControl.targetColor = blockColor;

      if (netState != LeapNetState.Inactive) {
        updateLocalTestingModeRepresentation();
      }

      if (netState == LeapNetState.LocalAuthority && shouldUpdateNetwork) {
        using (new ProfilerSample("Enqueue new sync event")) {
          NoARTestBlockSyncEvent syncEvent =
            new NoARTestBlockSyncEvent() {
              networkId = networkId,
              pose = transform.ToPose(),
              localScale = transform.localScale
            };

          if (allowSyncEvents) {
            network.EnqueueEvent(syncEvent);
          }
        }
      }
      else if (netState == LeapNetState.Remote) {
        NoARTestBlockSyncEvent syncEvent;
        while (network.TryDequeueEvent(networkId, this, out syncEvent)) {
          // network.Log("NetworkedBlock got sync event with id " +
          //   syncEvent.GetNetworkId());
          interpolator.enqueueUpdate(syncEvent, effectiveUpdateInterval);
        }

        if (interpolator.interpolateSample(ref syncEvent, Time.unscaledDeltaTime)) {
          syncState(syncEvent);
        }
      }
    }

    /// <summary>
    /// When in "local testing mode" (see NoARTestAppGlobals), two clients can
    /// be connected to a server all within a single Unity editor instance.
    /// In this situation, two representations of the block exist in the same
    /// PhysX context, so we move the "Remote" one to a different layer so it
    /// doesn't interfere with the simulation of the "LocalAuthority" one.
    /// </summary>
    private void updateLocalTestingModeRepresentation() {
      var app = NoARTestAppGlobals.instance;

      if (app.useLocalTestingMode) {
        if (netState == LeapNetState.LocalAuthority) {
          var localLayer = app.localLayer;
          gameObject.layer = localLayer;
          foreach (var child in transform.GetChildren()) {
            child.gameObject.layer = localLayer;
          }

          if (_originalLocalScale.HasValue) {
            var renderer = GetComponentInChildren<MeshRenderer>();
            renderer.transform.localScale = _originalLocalScale.Value;
          }
        }
        else if (netState == LeapNetState.Remote) {
          var remoteLayer = app.remoteLayer;
          gameObject.layer = remoteLayer;
          foreach (var child in transform.GetChildren()) {
            child.gameObject.layer = remoteLayer;
          }

          // Shrink the mesh renderer a bit so we don't get z-fighting in with
          // two clients in one scene.
          var renderer = GetComponentInChildren<MeshRenderer>();
          if (!_originalLocalScale.HasValue) {
            _originalLocalScale = renderer.transform.localScale;
          }
          renderer.transform.localScale =
            _originalLocalScale.Value.CompMul(Vector3.one * 0.98f);
        }
        else {
          Debug.LogWarning("updateLocalTestingModeRepresentation called, but this " +
            "block is inactive on the network.");
        }
      }
    }
    private Vector3? _originalLocalScale = null;

    /// <summary> Called whenever a new block sync packet comes in. </summary>
    public void syncState(NoARTestBlockSyncEvent syncEvent) {
      if (allowSyncEvents) {
        transform.position = syncEvent.pose.position;
        transform.rotation = syncEvent.pose.rotation;
        transform.localScale = syncEvent.localScale;
      }
    }

  }

}
