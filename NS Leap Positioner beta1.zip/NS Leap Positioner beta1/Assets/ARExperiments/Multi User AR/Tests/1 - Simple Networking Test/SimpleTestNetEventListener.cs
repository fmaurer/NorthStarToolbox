﻿using Leap.Unity.Attributes;
using LiteNetLib;
using System.Collections;
using System.Collections.Generic;
using System.Net;
using System.Net.Sockets;
using UnityEngine;

namespace Leap.Unity.AR.Experiments {

  public class SimpleTestNetEventListener : MonoBehaviour, INetEventListener {

    public string applicationConnectionKey =
      "Multi User AR - Simple Networking Test";
    public bool beServer = false;
    public int port = 5000;
    
    private NetManager _netManager;

    private void Start() {
      _netManager = new NetManager(this);
      _netManager.UpdateTime = 15;

      if (beServer) {
        _netManager.Start(port);
        _netManager.DiscoveryEnabled = true;
      }
      else {
        _netManager.Start();
      }
    }

    private void Update() {
      _netManager.PollEvents();

      if (beServer) {
        // nothin
      }
      else {
        var peer = _netManager.GetFirstPeer();
        if (peer != null && peer.ConnectionState == ConnectionState.Connected)
        {
          // stuff
        }
        else
        {
          Debug.Log("Sending Discovery Request...");
           _netManager.SendDiscoveryRequest(new byte[] {1}, port);
        }
      }
    }

    private void OnDestroy() {
      if (_netManager != null) {
        _netManager.Stop();
      }
    }

    public void OnConnectionRequest(ConnectionRequest request) {
      Debug.Log("Got connection request: " + request);
      request.AcceptIfKey(applicationConnectionKey);
    }

    public void OnPeerConnected(NetPeer peer) {
      Debug.Log("Peer connected: " + peer);
    }

    public void OnPeerDisconnected(NetPeer peer, DisconnectInfo disconnectInfo) {
      Debug.Log("Peer disconnected: " + peer +
        "\n Disconnect info: " + disconnectInfo);
    }

    public void OnNetworkError(IPEndPoint endPoint, SocketError socketError) {
      Debug.LogError("Network error at endpoint: " + endPoint +
        "\nSocket error: " + socketError);
    }

    public void OnNetworkReceive(NetPeer peer, NetPacketReader reader,
                                 DeliveryMethod deliveryMethod) {
      Debug.Log("Received some from peer " + peer + ".");
    }

    public void OnNetworkReceiveUnconnected(IPEndPoint remoteEndPoint,
                                            NetPacketReader reader,
                                            UnconnectedMessageType messageType) {
      Debug.Log("Got back a message (not yet connected). "
        + "messageType: " + messageType);

      if (beServer) {
        if (messageType == UnconnectedMessageType.DiscoveryRequest) {
          Debug.Log("Server received discovery request. Sending discovery " +
            "response to: " + remoteEndPoint);
          _netManager.SendDiscoveryResponse(new byte[] {1}, remoteEndPoint);
        }
      }
      else {
        if (messageType == UnconnectedMessageType.DiscoveryResponse &&
            _netManager.PeersCount == 0) {
          Debug.Log("Client received discovery response. Connecting to server at: " +
            remoteEndPoint);
          _netManager.Connect(remoteEndPoint, applicationConnectionKey);
        }
      }
    }

    public void OnNetworkLatencyUpdate(NetPeer peer, int latency) {
      Debug.Log("Got a latency update for peer: " + peer + 
        "\nNew latency: " + latency);
    }

  }

}
