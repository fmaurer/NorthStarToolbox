﻿using Leap.Unity.Geometry;
using Leap.Unity.Interaction;
using System.Collections.Generic;
using UnityEngine;

namespace Leap.Unity.AR.Experiments {

  using UnityRect = UnityEngine.Rect;
  using Rect = Leap.Unity.Geometry.Rect;

  public class Imhogui {

    public enum ElementType {
      Label,
      Button
    }

    public abstract class ElementInfo {
      public string path;
      public LocalRect rect;
      public string label;
      public ElementType elementType;
      /// <summary> Indicates the element had its path called in the latest GUI
      /// update and is visible or becoming visible. If this value is false, the
      /// element is inactive and about to be destroyed or in the process of
      /// deactivating. </summary> 
      public bool isActiveOrActivating;
      
      /// <summary> Returns the path string for this element as converted to
      /// a hash code more suitable for e.g. data transmission than
      /// variable-length strings. </summary>
      public int GetPathHash() { return path.GetHashCode(); }

      public ElementInfo(string path, LocalRect rect, string label,
        ElementType elementType)
      {
        this.path = path; this.rect = rect; this.label = label;
        this.elementType = elementType;
      }
    }

    public class LabelInfo : ElementInfo {
      public Transform parent;
      public RectTransform rectTransform;
      public TMPro.TextMeshPro labelTextMesh;

      public LabelInfo(string path, LocalRect rect, string label,
        Transform parent, RectTransform rectTransform,
        TMPro.TextMeshPro labelTextMesh)
        : base(path, rect, label, ElementType.Label)
      {
        this.parent = parent; this.rectTransform = rectTransform;
        this.labelTextMesh = labelTextMesh;
      }
    }

    public class ButtonInfo : ElementInfo {
      public Transform parent;
      public InteractionButton ieButton;
      public RectTransform surfaceRectTransform;
      public LineRect lineRect;
      public TMPro.TextMeshPro labelTextMesh;
      public bool wasPressedLastUpdate;

      public ButtonInfo(string path, LocalRect rect, string label,
        Transform parent, InteractionButton ieButton,
        RectTransform surfaceRectTransform, LineRect lineRect,
        TMPro.TextMeshPro labelTextMesh)
        : base(path, rect, label, ElementType.Button)
      {
        this.parent = parent; this.ieButton = ieButton;
        this.surfaceRectTransform = surfaceRectTransform;
        this.lineRect = lineRect; this.labelTextMesh = labelTextMesh;
        this.wasPressedLastUpdate = false;
      }
    }

    private const float M = 1f;
    private const float CM = 0.01f;
    private const float MM = 0.001f;

    private Transform _context;

    private List<ElementInfo> _elementsList = new List<ElementInfo>();
    public ReadonlyList<ElementInfo> elements { get { return _elementsList; } }

    private Dictionary<string, ElementInfo> _elements =
      new Dictionary<string, ElementInfo>();

    private HashSet<string> _namesUsedThisUpdate = new HashSet<string>();
    
    public Imhogui(Transform context) {
      _context = context;
    }

    public const string DEFAULT_LABEL = "Imhogui Label";
    public readonly LocalRect DEFAULT_LABEL_RECT =
      LocalRect.unit.Scale(new Vector2(5f * CM, 2.5f * CM));
    
    public void Label(string uniquePath, LocalRect? rect = null,
      string label = null, Color? color = null, bool? enabled = null)
    {
      validatePath(uniquePath);

      var useLabel = label.ValueOr(DEFAULT_LABEL);
      var useRect = rect.UnwrapOr(DEFAULT_LABEL_RECT);
      var useColor = color.UnwrapOr(Color.white);
      //var useEnabled = enabled.UnwrapOr(true);

      LabelInfo labelInfo = null;
      ElementInfo element;
      if (!_elements.TryGetValue(uniquePath, out element)) {
        labelInfo = createLabel(_context, uniquePath, useRect, useLabel);
        element = labelInfo;
        addElement(uniquePath, labelInfo);
        Debug.Log("Creating label.");
      }
      else if (element.elementType != ElementType.Label) {
        Debug.LogWarning("Overwriting existing non-label path with a label -- " +
          "this will cause the old element to dangle in the scene!");
        labelInfo = createLabel(_context, uniquePath, useRect, useLabel);
        element = labelInfo;
        addElement(uniquePath, labelInfo);
      }
      else {
        labelInfo = element as LabelInfo;
      }

      labelInfo.path = uniquePath;
      labelInfo.parent.SetPose(useRect.With(_context).pose);
      labelInfo.parent.localScale = Vector3.one;
      labelInfo.label = useLabel;
      labelInfo.labelTextMesh.text = labelInfo.label;
      if (string.IsNullOrEmpty(labelInfo.labelTextMesh.text)) {
        Debug.LogWarning("labelInfo.labelTextMesh.text is null or empty");
      }
      labelInfo.labelTextMesh.color = useColor;
      labelInfo.rect = useRect;
      labelInfo.rectTransform.anchorMin = Vector3.one * 0.5f;
      labelInfo.rectTransform.anchorMax = Vector3.one * 0.5f;
      labelInfo.rectTransform.sizeDelta = useRect.radii * 2f;
    }

    public const string DEFAULT_BUTTON_LABEL = "Imhogui Button";
    public readonly LocalRect DEFAULT_BUTTON_RECT = LocalRect.unit.Scale(5f * CM);       
    public const float DEFAULT_BUTTON_REST_HEIGHT = 2.0f * CM;

    public bool Button(string uniquePath, LocalRect? rect = null, 
      string label = null, float? restHeight = null, Color? color = null,
      bool? enabled = null)
    {
      validatePath(uniquePath);

      var useLabel = label.ValueOr(DEFAULT_BUTTON_LABEL);
      var useRect = rect.UnwrapOr(DEFAULT_BUTTON_RECT);
      var useRestHeight = restHeight.UnwrapOr(DEFAULT_BUTTON_REST_HEIGHT);
      var useColor = color.UnwrapOr(Color.white);
      var useEnabled = enabled.UnwrapOr(true);

      ButtonInfo buttonInfo = null;
      ElementInfo element;
      if (!_elements.TryGetValue(uniquePath, out element)) {
        buttonInfo = createButton(_context, uniquePath, useRect, useLabel,
          useRestHeight);
        element = buttonInfo;
        addElement(uniquePath, buttonInfo);
      }
      else if (element.elementType != ElementType.Button) {
        Debug.LogWarning("Overwriting existing non-button path with a button -- " +
          "this will cause the old element to dangle in the scene!");
        buttonInfo = createButton(_context, uniquePath, useRect, useLabel,
          useRestHeight);
        element = buttonInfo;
        addElement(uniquePath, buttonInfo);
      }
      else {
        buttonInfo = element as ButtonInfo;
      }

      buttonInfo.path = uniquePath;
      buttonInfo.parent.SetPose(useRect.With(_context).pose);
      buttonInfo.parent.localScale = Vector3.one;
      buttonInfo.ieButton.transform.localScale = Vector3.one;
      buttonInfo.label = useLabel;
      buttonInfo.labelTextMesh.text = buttonInfo.label;
      buttonInfo.rect = useRect;
      buttonInfo.surfaceRectTransform.anchorMin = Vector3.one * 0.5f;
      buttonInfo.surfaceRectTransform.anchorMax = Vector3.one * 0.5f;
      buttonInfo.surfaceRectTransform.sizeDelta = useRect.radii * 2f;
      buttonInfo.lineRect.color = useColor;
      buttonInfo.labelTextMesh.color = useColor;
      buttonInfo.ieButton.controlEnabled = useEnabled;

      var wasPressed = buttonInfo.ieButton.isPressed &&
        !buttonInfo.wasPressedLastUpdate;
      return wasPressed;
    }

    private void validatePath(string uniquePath) {
      if (uniquePath == null) {
        throw new System.InvalidOperationException("Element path cannot be null. " +
          "Must provide a path that will uniquely identify this button " +
          "throughout its lifetime.");
      }
      if (_namesUsedThisUpdate.Contains(uniquePath)) {
        Debug.LogWarning("Element path " + uniquePath + " has already been " +
          "declared this update. The element will inherit the configuration of " +
          "the latest declaration. This might make UI elements unstable.");
      }
      else {
        _namesUsedThisUpdate.Add(uniquePath);
      }
    }

    private void addElement(string path, ElementInfo element) {
      _elements[path] = element;
      _elementsList.Add(element);
    }

    public void Update() {
      // Update any per-element state.
      // Disable any elements who were not in the names used this update.
      foreach (var nameElementInfoPair in _elements) {
        var name = nameElementInfoPair.Key;
        var elementInfo = nameElementInfoPair.Value;

        var wasNameUsed = _namesUsedThisUpdate.Contains(name);
        switch (elementInfo.elementType) {
          case ElementType.Label:
            updateLabel(elementInfo as LabelInfo, wasNameUsed); break;
          case ElementType.Button:
            updateButton(elementInfo as ButtonInfo, wasNameUsed); break;
          default:
            throw new System.NotImplementedException("Unsupported element type: " +
              elementInfo.elementType);
        }
      }
      
      _namesUsedThisUpdate.Clear();
    }

    private void updateLabel(LabelInfo label, bool wasCalledThisUpdate) {
      label.isActiveOrActivating = wasCalledThisUpdate;
      label.parent.gameObject.SetActive(wasCalledThisUpdate);
    }

    private void updateButton(ButtonInfo button, bool wasCalledThisUpdate) {
      // Update last-pressed state so we can trigger events only when a button
      // was just pressed.
      button.wasPressedLastUpdate = button.ieButton.isPressed;

      button.isActiveOrActivating = wasCalledThisUpdate;
      button.parent.gameObject.SetActive(wasCalledThisUpdate);
    }

    private static LabelInfo createLabel(Transform context, string path,
      LocalRect rect, string label)
    {
      var objName = path + " - Imhogui Label";

      var parentObj = new GameObject(objName + " Parent");
      parentObj.transform.parent = context;
      parentObj.transform.SetLocalPose(Pose.identity);
      parentObj.transform.localRotation = Quaternion.AngleAxis(180f, Vector3.up);
      parentObj.transform.localScale = Vector3.one;

      var labelObj = new GameObject(objName);
      labelObj.transform.parent = parentObj.transform;
      labelObj.transform.SetLocalPose(Pose.identity);
      labelObj.transform.localRotation = Quaternion.identity;
      labelObj.transform.localScale = Vector3.one;
      
      var rectTransform = labelObj.AddComponent<RectTransform>();
      rectTransform.anchorMin = Vector3.one * 0.5f;
      rectTransform.anchorMax = Vector3.one * 0.5f;
      rectTransform.sizeDelta = rect.radii * 2f;

      var labelTextMesh = labelObj.AddComponent<TMPro.TextMeshPro>();
      labelTextMesh.text = label;
      labelTextMesh.fontSize = 0.25f;
      labelTextMesh.alignment = TMPro.TextAlignmentOptions.Center;
      labelTextMesh.enableAutoSizing = true;
      labelTextMesh.fontSizeMin = 0.01f;

      var labelInfo = new LabelInfo(path, rect, label, parentObj.transform,
        rectTransform, labelTextMesh);

      return labelInfo;
    }

    private static ButtonInfo createButton(Transform context, string path,
      LocalRect rect, string label, float restHeight)
    {
      var objName = path + " - Imhogui Button";

      var buttonParentObj = new GameObject(objName + " Parent");
      buttonParentObj.transform.parent = context;
      buttonParentObj.transform.SetLocalPose(Pose.identity);
      buttonParentObj.transform.localRotation =
        Quaternion.AngleAxis(180f, Vector3.up);
      buttonParentObj.transform.localScale = Vector3.one;

      var buttonObj = new GameObject(objName);
      var ieButton = buttonObj.AddComponent<InteractionButton>();
      ieButton.transform.parent = buttonParentObj.transform;
      ieButton.transform.SetLocalPose(Pose.identity);
      ieButton.rigidbody.position = ieButton.transform.position;
      ieButton.rigidbody.freezeRotation = true;
      ieButton.rigidbody.useGravity = false;
      ieButton.minMaxHeight = new Vector2(-restHeight / 2f, restHeight / 2f);

      var boxCollider = buttonObj.AddComponent<BoxCollider>();
      boxCollider.size = (2 * rect.radii).WithZ(restHeight);

      var lineRectObj = new GameObject(objName + " Surface Lines");
      lineRectObj.transform.parent = buttonObj.transform;
      lineRectObj.transform.SetLocalPose(Pose.identity);
      lineRectObj.transform.localPosition += Vector3.back * restHeight / 2f;

      var rectFilter = lineRectObj.AddComponent<LocalRectFilter>();
      rectFilter.localRect = rect;
      rectFilter.localRect.center = Vector3.zero;

      var lineRect = lineRectObj.AddComponent<LineRect>();
      lineRect.rectFilter = rectFilter;
      lineRect.color = Color.white;

      var rectTransform = lineRectObj.AddComponent<RectTransform>();
      rectTransform.anchorMin = Vector3.one * 0.5f;
      rectTransform.anchorMax = Vector3.one * 0.5f;
      rectTransform.sizeDelta = rect.radii * 2f;

      var labelTextMesh = lineRectObj.AddComponent<TMPro.TextMeshPro>();
      labelTextMesh.text = label;
      labelTextMesh.fontSize = 0.25f;
      labelTextMesh.alignment = TMPro.TextAlignmentOptions.Center;
      labelTextMesh.enableAutoSizing = true;
      labelTextMesh.fontSizeMin = 0.01f;

      var buttonInfo = new ButtonInfo(path, rect, label,
        buttonParentObj.transform, ieButton, rectTransform, lineRect,
        labelTextMesh);
      
      return buttonInfo;
    }

  }

}