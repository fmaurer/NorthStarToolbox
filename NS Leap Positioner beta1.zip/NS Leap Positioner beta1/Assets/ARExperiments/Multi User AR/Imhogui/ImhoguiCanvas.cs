﻿using Leap.Unity.Attributes;
using Leap.Unity.Geometry;
using Leap.Unity.Query;
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Leap.Unity.AR.Experiments {

  public interface IImhoguiControl {
    /// <summary> Call methods like Label() and Button() on the gui object to
    /// declare their existence during the GUI update, which is called by the
    /// ImhoguiCanvas every Update().
    ///
    /// TODO: Remove controlPath and only support one gui object per canvas.
    /// Each element call must have a unique identifying "path" per gui object.
    /// Use the controlPath string, which is provided by the canvas, as a prefix
    /// for element paths to ensure they are unique if multiple canvases use the
    /// same Imhogui object. </summary>
    void OnImhoGUI(Imhogui gui, string controlPath, LocalRect controlRect);
  }

  public class ImhoguiCanvas : MonoBehaviour {

    public LocalRectFilter rectFilter;

    private Imhogui _gui;
    public Imhogui imhogui {
      get {
        if (_gui == null) {
          _gui = new Imhogui(this.transform);
        }
        return _gui;
      }
    }

    [SerializeField]
    [ImplementsInterface(typeof(IImhoguiControl))]
    private MonoBehaviour _imhoguiControl;
    public IImhoguiControl control {
      get { return _imhoguiControl as IImhoguiControl; }
      set {
        if (!(value is MonoBehaviour)) {
          throw new System.InvalidCastException("Control element for the " +
          "ImhoguiCanvas currently must be a MonoBehaviour.");
        }
        _imhoguiControl = value as MonoBehaviour;
      }
    }

    public Action OnPostGuiUpdate = () => { };

    private void Reset() {
      if (rectFilter == null) { rectFilter = GetComponent<LocalRectFilter>(); }
    }

    private void Awake() {
      if (_gui == null) { _gui = new Imhogui(this.transform); }
    }

    private void Update() {
      var localRect = rectFilter.localRect;

      control.OnImhoGUI(_gui, this.name + "/", localRect);

      _gui.Update();

      OnPostGuiUpdate();
    }

  }

}
