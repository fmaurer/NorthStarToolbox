// using Leap.Unity.Geometry;
// using UnityEngine;

// namespace Leap.Unity.AR.Experiments {

//   using UnityGrid = UnityEngine.Grid;
//   using Grid = Geometry.Grid;

//   public class TabContainer : MonoBehaviour, IImhoguiControl {

//     void IImhoguiControl.OnGUI(Imhogui gui, LocalRect controlRect,
//       string controlPath)
//     {

//       foreach (var cell in Grid.FromRect(controlRect, numRows: 2, numCols: 2,
//         cellMargins: Margins.All(0.002f)))
//       {
//         if (gui.Button(name: "Button Test " + cell.index,
//           rect: cell.innerRect, label: "Button " + cell.index,
//           restHeight: 0.01f))
//         {
//           Debug.Log("Hi from " + cell.index + "!");
//         }
//       }

//     }

//   }

// }