﻿using Leap.Unity.Geometry;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Leap.Unity.AR.Experiments {

  using Rect = Geometry.Rect;

  [ExecuteInEditMode]
  public class LocalRectFilter : MonoBehaviour {
    
    public LocalRect localRect;
    public Rect rect {
      get { return localRect.With(this.transform); }
    }

    private void OnValidate() {
      updateRectTransform();
    }

    private void OnEnable() {
      updateRectTransform();
    }

    private void Update() {
      updateRectTransform();
    }

    private void updateRectTransform() {
      var rectTransform = GetComponent<RectTransform>();
      if (rectTransform != null) {
        localRect = LocalRect.FromUnityRect(rectTransform.rect);
      }
    }
    
    private void OnDrawGizmos() {
      Gizmos.color = LeapColor.cerulean.WithAlpha(0.2f);
      drawUnityGizmos();
    }

    private void OnDrawGizmosSelected() {
      Gizmos.color = LeapColor.white.WithAlpha(0.6f);
      drawUnityGizmos();
    }

    private void drawUnityGizmos() {
      rect.DrawLines(Gizmos.DrawLine);
    }

  }

}
