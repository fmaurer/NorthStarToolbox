﻿using Leap.Unity.Geometry;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Leap.Unity.AR.Experiments {

  [ExecuteInEditMode]
  public class LineCircle : MonoBehaviour {

    public LocalCircle localCircle;
    public Circle circle {
      get { return localCircle.With(this.transform); }
    }

    public Color color = Color.white;

    private void Update() {
      var drawer = HyperMegaStuff.HyperMegaLines.drawer;
      if (drawer != null) {
        drawer.color = color;
        circle.DrawLines(drawer.DrawLine);
      }
    }

  }

}