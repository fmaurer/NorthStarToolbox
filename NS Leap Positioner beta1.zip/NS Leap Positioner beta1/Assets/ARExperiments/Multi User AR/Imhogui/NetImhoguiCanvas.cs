
using Leap.Unity.Attributes;
using Leap.Unity.Encoding;
using Leap.Unity.Geometry;
using Leap.Unity.Networking;
using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using UnityEngine;

namespace Leap.Unity.AR.Experiments {

  public class NetImhoguiCanvas : LeapNetObject, IImhoguiControl {
    
    [Tooltip("The interval (in seconds) in which transform " +
      "updates are sent out or checked.")]
    [MinValue(0f)]
    public float updateInterval = 0.030f;

    public ImhoguiCanvas canvas;

    [Header("Local Only")]
    /// <summary> This should only be non-null on the local instance of a
    /// NetImhoguiCanvas. </summary>
    public LeapNetPlayerObject player;
    private int _remote_playerId = LeapNetManager.NO_NETWORK_ID;

    [Header("Remote Only")]
    [Range(0f, 0.3f)]
    public float prediction = 0.1f;

    [NonSerialized]
    private Transform remoteOrigin;
    private Matrix4x4 remoteOriginMatrix {
      get {
        if (remoteOrigin == null) { return Matrix4x4.identity; }
        else { return remoteOrigin.localToWorldMatrix; }
      }
    }

    private void Reset() {
      if (canvas == null) { canvas = GetComponent<ImhoguiCanvas>(); }
      if (player == null) { player = GetComponentInParent<LeapNetPlayerObject>(); }
    }

    private void Awake() {
      if (canvas == null) { canvas = GetComponent<ImhoguiCanvas>(); }
    }

    public struct ShortFixedString {
      public const int MAX_STRING_LENGTH = 12;

      public int strLength;
      [MarshalAs(UnmanagedType.ByValArray, SizeConst = MAX_STRING_LENGTH)]
      public char[] chars;

      public ShortFixedString(string sourceString) {
        strLength = 0;
        chars = new char[MAX_STRING_LENGTH];
        for (int i = 0; i < chars.Length; i++) {
          if (i < sourceString.Length) {
            chars[i] = sourceString[i];
            strLength += 1;
          }
          else {
            chars[i] = '#';
          }
        }
      }

      public override string ToString() {
        return new String(chars, 0, strLength);
      }
    }

    public struct ImhoguiElementSync {
      public ShortFixedString label;
      public LocalRect rect;
      public int pathHash;
    }

    public struct NetImhoguiObjectSync : ILeapNetSpawnable,
      IInterpolable<NetImhoguiObjectSync>
    {
      public const int MAX_ELEMENTS_LENGTH = 12;

      public int networkId;
      public int playerId;
      public Pose pose;
      public LocalRect rect;
      public Vector3 localScale;
      public bool isValid { get { return localScale != Vector3.zero; } }

      public int elementsLength;
      [MarshalAs(UnmanagedType.ByValArray, SizeConst=MAX_ELEMENTS_LENGTH)]
      public ImhoguiElementSync[] elements;

      public NetImhoguiObjectSync(int networkId,
        ImhoguiCanvas imhoguiCanvas, int? optionalPlayerId = null)
      {
        this.networkId = networkId;
        this.playerId = optionalPlayerId.UnwrapOr(LeapNetManager.NO_NETWORK_ID);
        elementsLength = 0;
        elements = new ImhoguiElementSync[MAX_ELEMENTS_LENGTH];
        pose = imhoguiCanvas.transform.ToPose();
        rect = imhoguiCanvas.rectFilter.localRect;
        localScale = imhoguiCanvas.transform.localScale;
        foreach (var element in imhoguiCanvas.imhogui.elements) {
          if (!element.isActiveOrActivating) { continue; }

          if (elementsLength >= MAX_ELEMENTS_LENGTH) {
            Debug.LogWarning("NetImhoguiObjectSync is full; exiting early " +
              "during construction. The max number of elements is currently " +
              MAX_ELEMENTS_LENGTH);
            break;
          }

          elements[elementsLength] = createElementSync(element);
          elementsLength++;
        }
      }

      public int GetNetworkId() { return networkId; }
      public void SetNetworkId(int assignedID) { networkId = assignedID; }
      public ElementSyncEnumerator EnumerateElements() {
        return new ElementSyncEnumerator(this);
      }

      public struct ElementSyncEnumerator {
        NetImhoguiObjectSync sync;
        int index;
        public ElementSyncEnumerator(NetImhoguiObjectSync sync) {
          this.sync = sync;
          index = -1;
        }
        public ElementSyncEnumerator GetEnumerator() { return this; }
        public ImhoguiElementSync Current { get { return sync.elements[index]; } }
        public bool MoveNext() { index++; return index < sync.elementsLength; }
        public void Reset() { index = -1; }
      }

      public NetImhoguiObjectSync CopyFrom(NetImhoguiObjectSync toCopy) {
        var elementsCopy = new ImhoguiElementSync[MAX_ELEMENTS_LENGTH];
        for (int i = 0; i < toCopy.elements.Length; i++) {
          elementsCopy[i] = toCopy.elements[i];
        }
        networkId = toCopy.networkId;
        playerId = toCopy.playerId;
        pose = toCopy.pose;
        rect = toCopy.rect;
        localScale = toCopy.localScale;
        elementsLength = toCopy.elementsLength;
        elements = elementsCopy;
        return this;
      }

      public bool FillLerped(NetImhoguiObjectSync from, NetImhoguiObjectSync to,
        float t)
      {
        this.networkId = to.networkId;
        this.playerId = to.playerId;
        this.pose.FillLerped(from.pose, to.pose, t);
        this.rect.FillLerped(from.rect, to.rect, t);
        this.localScale = Vector3.Max(Vector3.Lerp(from.localScale,
          to.localScale, t), Vector3.zero);
        this.elementsLength = to.elementsLength;
        this.elements = to.elements;
        return true;
      }

      public bool FillSplined(NetImhoguiObjectSync a, NetImhoguiObjectSync b,
        NetImhoguiObjectSync c, NetImhoguiObjectSync d, float t)
      {
        this.networkId = c.networkId;
        this.playerId = c.playerId;
        this.pose.FillSplined(a.pose, b.pose, c.pose, d.pose, t);
        this.rect.FillSplined(a.rect, b.rect, c.rect, d.rect, t);
        
        this.localScale = Vector3.Max(Splines.CatmullRom.ToCHS(a.localScale,
          b.localScale, c.localScale, d.localScale).PositionAt(t), Vector3.zero);
        this.elementsLength = c.elementsLength;
        this.elements = c.elements;
        return true;
      }
    }

    public static Dictionary<int, NetImhoguiCanvas> s_pendingRequests
      = new Dictionary<int, NetImhoguiCanvas>();

    [SpawnHandler(typeof(NetImhoguiObjectSync))]
    public static LeapNetObject HandleSpawn(LeapNetManager network,
      int spawnedNetworkId, bool hasLocalAuthority,
      NetImhoguiObjectSync spawnState, int spawnRequestId)
    {
      if (hasLocalAuthority) {
        // We must use the spawn request ID to identify which instance attempted
        // to activate itself on the network.
        NetImhoguiCanvas spawnedCanvas;
        if (!s_pendingRequests.TryGetValue(spawnRequestId, out spawnedCanvas)){
          throw new System.InvalidOperationException(
            "Can't spawn local-authority NetImhoguiCanvas without a known " +
            "pending request.");
        }
        else {
          spawnedCanvas._pendingRequestId = null;
          spawnedCanvas.NotifyNetworkSpawned(network, spawnedNetworkId,
            hasLocalAuthority);
          return spawnedCanvas;
        }
      }
      else { // Remote authority
        var remoteCanvasObj = new GameObject("Remote Imhogui Canvas");
        var remoteCanvas = remoteCanvasObj.AddComponent<ImhoguiCanvas>();
        var remoteControl = remoteCanvasObj.AddComponent<NetImhoguiCanvas>();
        remoteCanvas.control = remoteControl;
        remoteControl.canvas = remoteCanvas;

        var canvasRectFilter = remoteCanvasObj.AddComponent<LocalRectFilter>();
        canvasRectFilter.localRect = spawnState.rect;
        remoteCanvas.rectFilter = canvasRectFilter;
        var canvasLineRect = remoteCanvasObj.AddComponent<LineRect>();
        canvasLineRect.rectFilter = canvasRectFilter;

        remoteControl._remote_playerId = spawnState.playerId;
        remoteControl.NotifyNetworkSpawned(network, spawnedNetworkId,
          hasLocalAuthority);

        return remoteControl;
      }
    }

    [DespawnHandler(typeof(NetImhoguiObjectSync))]
    public static bool HandleDespawn(LeapNetObject objectToDespawn) {
      bool isRemote = objectToDespawn.netState == LeapNetState.Remote;
      Debug.Log("Got despawn request for object " + objectToDespawn.name,
        objectToDespawn);
      objectToDespawn.NotifyNetworkDespawned();
      if (isRemote) {
        Debug.Log("Destroying " + objectToDespawn.name, objectToDespawn);
        Destroy(objectToDespawn.gameObject);
      }
      return true;
    }

    public static ImhoguiElementSync createElementSync(
      Imhogui.ElementInfo element)
    {
      return new ImhoguiElementSync() {
        pathHash = element.GetPathHash(),
        rect = element.rect,
        label = new ShortFixedString(element.label)
      };
    }

    public static NetImhoguiObjectSync createSync(int networkId,
      ImhoguiCanvas canvas,
      int? optionalPlayerId = null)
    {
      return new NetImhoguiObjectSync(networkId, canvas, optionalPlayerId);
    }

    private bool _registeredListener = false;
    private bool _registeredPostGUI = false;

    private void OnEnable() {
      if (player != null) {
        //player.OnNetworkSpawned -= onPlayerSpawned;
        //player.OnNetworkSpawned += onPlayerSpawned;
        player.OnNetworkDespawned -= onPlayerDespawned;
        player.OnNetworkDespawned += onPlayerDespawned;
      }
    }

    private void onPlayerDespawned() {
      if (netState == LeapNetState.LocalAuthority) {
        network.RequestDespawn(networkId);
      }
    }

    private void OnDisable() {
      if (netState == LeapNetState.Remote) {
        if (_registeredListener) {
          network.UnregisterEventListener<NetImhoguiObjectSync>(networkId, this);
          _registeredListener = false;
        }
      }
      else if (netState == LeapNetState.LocalAuthority) {
        if (_registeredPostGUI) {
          canvas.OnPostGuiUpdate -= local_onPostGuiUpdate;
          _registeredPostGUI = false;
        }
      }
    }

    private int? _pendingRequestId = null;

    public void Update() {
      if (netState == LeapNetState.Remote) {
        if (!_registeredListener) {
          if (network == null) {
            Debug.LogError("Network is null! How is this possible?");
          }
          network.RegisterEventListener<NetImhoguiObjectSync>(networkId, this);
          _registeredListener = true;
        }
        NetImhoguiObjectSync sync;
        if (network.TryDequeueEvent(networkId, this, out sync)) {
          remote_loadSync(sync);
        }
      }
      else if (netState == LeapNetState.LocalAuthority) {
        if (!_registeredPostGUI && canvas != null) {
          canvas.OnPostGuiUpdate -= local_onPostGuiUpdate;
          canvas.OnPostGuiUpdate += local_onPostGuiUpdate;
          _registeredPostGUI = true;
        }
      }
      else {
        if (netState == LeapNetState.Inactive && player != null &&
          player.netState == LeapNetState.LocalAuthority &&
          player.network != null && canvas != null && _pendingRequestId == null)
        {
          // Request activation (spawning) on the network, and associate the
          // request ID with this instance so the static HandleSpawn call can
          // notify this local instance when its spawn is approved.
          var requestId = player.network.RequestSpawn(createSync(
            LeapNetManager.NO_NETWORK_ID, canvas, player.networkId),
            isSingleOwnership: true);
          s_pendingRequests[requestId] = this;
          _pendingRequestId = requestId;
        }
      }
    }

    private float _netUpdateTimer = 0f;
    private bool _requestedDespawn = false;

    private void local_onPostGuiUpdate() {
      if (this.netState != LeapNetState.LocalAuthority) {
        Debug.LogWarning("local_onPostGuiUpdate requires having local authority; " +
          "unsubscribing from local_onPostGuiUpdate.",
          this);
        canvas.OnPostGuiUpdate -= local_onPostGuiUpdate;
        return;
      }

      if (player == null) {
        Debug.LogError("Local authority canvas has no player reference.");
        return;
      }
      else {
        _netUpdateTimer += Time.unscaledDeltaTime;
        if (_netUpdateTimer > updateInterval) {
          _netUpdateTimer = 0f;

          if (canvas == null) {
            Debug.Log("Unable to sync canvas state because canvas is null.", this);
          }
          else {
            var sync = createSync(this.networkId, canvas, player.networkId);
            network.EnqueueEvent(sync, LiteNetLib.DeliveryMethod.ReliableOrdered);
          }
        }
      }
    }

    private NetImhoguiObjectSync _latestSync;
    private LeapNetInterpolator<NetImhoguiObjectSync> _interpolator =
      new LeapNetInterpolator<NetImhoguiObjectSync>(useSmoothingSpline: true);
    private NetImhoguiObjectSync _interpolatedSync;

    private void remote_loadSync(NetImhoguiObjectSync sync) {
      Debug.Log("Remote: Got sync");
      if (!sync.isValid) {
        Debug.LogWarning("Warning: Imhogui sync not valid.");
      }
      else {
        _latestSync = sync;
        
        foreach (var elementSync in sync.EnumerateElements()) {
          if (string.IsNullOrEmpty(elementSync.label.ToString())) {
            Debug.LogWarning("Element sync label is empty");
          }
        }

        _remote_playerId = sync.playerId;
        if (_remote_playerId != LeapNetManager.NO_NETWORK_ID) {
          var player = network.GetObjectFromId(_remote_playerId)
            as LeapNetPlayerObject;
          if (player != null) {
            remoteOrigin = player.remoteOrigin;
          }
        }

        _interpolator.enqueueUpdate(sync, updateInterval);
        _interpolator.prediction = this.prediction;
        if (_interpolator.interpolateSample(ref _interpolatedSync, 
          Time.unscaledDeltaTime))
        {
          this.transform.SetPose(remoteOriginMatrix.GetPose() *
            _interpolatedSync.pose);
          this.canvas.rectFilter.localRect = _interpolatedSync.rect;
          this.transform.localScale = _interpolatedSync.localScale;
        }
        else {
          this.transform.SetPose(remoteOriginMatrix.GetPose() * _latestSync.pose);
          this.canvas.rectFilter.localRect = _latestSync.rect;
          this.transform.localScale = _latestSync.localScale;
        }

      }
    }

    public void OnImhoGUI(Imhogui gui, string controlPath, LocalRect controlRect) {
      if (!_latestSync.isValid) { return; }
      else {
        var sync = _latestSync;
        foreach (var elementSync in sync.EnumerateElements()) {
          gui.Label(elementSync.pathHash.ToString(), elementSync.rect,
            elementSync.label.ToString());
        }
      }
    }

  }

}