﻿using Leap.Unity.Geometry;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Leap.Unity.AR.Experiments {

  using Rect = Geometry.Rect;

  [ExecuteInEditMode]
  public class LineRect : MonoBehaviour {
    
    public LocalRectFilter rectFilter;

    public Color color = Color.white;

    private void Update() {
      var drawer = HyperMegaStuff.HyperMegaLines.drawer;
      if (drawer != null && rectFilter != null) {
        drawer.color = color;
        rectFilter.rect.DrawLines(drawer.DrawLine);
      }
    }

  }

}