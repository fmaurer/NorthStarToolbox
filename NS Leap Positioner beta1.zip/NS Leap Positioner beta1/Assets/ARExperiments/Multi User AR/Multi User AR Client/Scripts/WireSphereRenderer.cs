﻿using System.Collections;
using System.Collections.Generic;
using Leap.Unity.Geometry;
using UnityEngine;

namespace Leap.Unity.Apps.MultiUserAR {

  [ExecuteInEditMode]
  public class WireSphereRenderer : MonoBehaviour {
    
    public LocalSphere localSphere;
    public Color color = Color.white;
    [Range(1, 16)]
    public int latitudinalDivisions = 6;
    [Range(1, 16)]
    public int longitudinalDivisions = 6;
    [Range(2, 42)]
    public int numCircleSegments = 22;

    private void Reset() {
      localSphere = LocalSphere.Default();
    }

    private void Update() {
      drawLines();
    }

    private void drawLines() {
      var drawer = HyperMegaStuff.HyperMegaLines.drawer;
      drawer.color = color;
      localSphere.With(this.transform).DrawLines(
        drawer.DrawLine,
        latitudinalDivisions: latitudinalDivisions,
        longitudinalDivisions: longitudinalDivisions,
        numCircleSegments: numCircleSegments,
        matrixOverride: null
      );
    }

  }

}
