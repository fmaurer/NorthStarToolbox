﻿using Leap.Unity.Animation;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class QuickTestSwitcher : MonoBehaviour {

  public MonoBehaviour _switch;
  public IPropertySwitch propSwitch {
    get { return _switch as IPropertySwitch; }
  }

  public KeyCode switchKeyCode = KeyCode.I;

  private void Update() {
    if (Input.GetKeyDown(switchKeyCode)) {
      if (propSwitch.GetIsOffOrTurningOff()) {
        propSwitch.AutoOn();
      }
      else {
        propSwitch.AutoOff();
      }
    }
  }

}
