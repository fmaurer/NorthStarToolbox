﻿using System.Collections;
using System.Collections.Generic;
using Leap.Unity.Networking;
using UnityEngine;

namespace Leap.Unity.Apps.MultiUserAR {

  public class SetTextFromLeapNetManagerLogs : MonoBehaviour {

    public LeapNetManager network;
    public TMPro.TextMeshPro text;
    public int numLines = 32;

    private void Reset() {
      if (network == null) { network = FindObjectOfType<LeapNetManager>(); }
      if (text == null) { text = GetComponent<TMPro.TextMeshPro>(); }
    }

    private void Start() {
      if (network == null) { network = FindObjectOfType<LeapNetManager>(); }
      if (text == null) { text = GetComponent<TMPro.TextMeshPro>(); }
    }

    private void Update() {
      if (network != null && text != null) {
        text.text = takeLastNLines(numLines, network.latestLogs);
      }
    }

    private string takeLastNLines(int numLines, string text) {
      var result = "";
      
      var lineEnumerator = new Leap.Unity.Config.LineEnumerator(text);
      int lineCount = 0;
      foreach (var line in lineEnumerator) { lineCount += 1; }
      
      lineEnumerator = new Leap.Unity.Config.LineEnumerator(text);
      int lineIdx = 0;
      foreach (var line in lineEnumerator) { 
        if (lineIdx >= lineCount - numLines) {
          result += line + "\n";
        }

        lineIdx++;
      }

      return result;
    }

  }

}
