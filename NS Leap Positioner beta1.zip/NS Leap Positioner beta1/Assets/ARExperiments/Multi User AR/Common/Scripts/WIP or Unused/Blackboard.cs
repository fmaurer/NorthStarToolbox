using System;
using System.Collections.Generic;

namespace Leap.Unity.Apps.MultiUserAR {

  public class Blackboard {

    #region Bools
    
    private Dictionary<string, bool> _bools = new Dictionary<string, bool>();

    /// <summary> Gets the value, or returns the default value of the type.
    /// </summary>
    public bool GetBool(string key) {
      var result = default(bool);
      if (TryGetBool(key, ref result)) {
        return result;
      }
      else {
        return default(bool);
      }
    }

    /// <summary> Outputs the value at the specified key into result and returns
    /// true, or if the key was not found for the specified type, return false
    /// and does not modify the reference argument. </summary>
    public bool TryGetBool(string key, ref bool result) {
      var temp = default(bool);
      if (_bools.TryGetValue(key, out temp)) {
        result = temp;
        return true;
      }
      else {
        return false;
      }
    }

    public void SetBool(string key, bool value) {
      _bools[key] = value;
    }

    #endregion

    #region Ints

    private Dictionary<string, int> _ints = new Dictionary<string, int>();

    /// <summary> Gets the value, or returns the default value of the type.
    /// </summary>
    public int GetInt(string key) {
      var result = default(int);
      if (TryGetInt(key, ref result)) {
        return result;
      }
      else {
        return default(int);
      }
    }

    /// <summary> Outputs the value at the specified key into result and returns
    /// true, or if the key was not found for the specified type, return false
    /// and does not modify the reference argument. </summary>
    public bool TryGetInt(string key, ref int result) {
      var temp = default(int);
      if (_ints.TryGetValue(key, out temp)) {
        result = temp;
        return true;
      }
      else {
        return false;
      }
    }

    public void SetInt(string key, int value) {
      _ints[key] = value;
    }

    #endregion

    #region Floats
    
    private Dictionary<string, float> _floats = new Dictionary<string, float>();

    /// <summary> Gets the value, or returns the default value of the type.
    /// </summary>
    public float GetFloat(string key) {
      var result = default(float);
      if (TryGetFloat(key, ref result)) {
        return result;
      }
      else {
        return default(float);
      }
    }

    /// <summary> Outputs the value at the specified key into result and returns
    /// true, or if the key was not found for the specified type, return false
    /// and does not modify the reference argument. </summary>
    public bool TryGetFloat(string key, ref float result) {
      var temp = default(float);
      if (_floats.TryGetValue(key, out temp)) {
        result = temp;
        return true;
      }
      else {
        return false;
      }
    }

    public void SetFloat(string key, float value) {
      _floats[key] = value;
    }

    #endregion

    #region Strings
    
    private Dictionary<string, string> _strings;

    /// <summary> Gets the value, or returns the default value of the type.
    /// </summary>
    public string GetString(string key) {
      var result = default(string);
      if (TryGetString(key, ref result)) {
        return result;
      }
      else {
        return default(string);
      }
    }

    /// <summary> Outputs the value at the specified key into result and returns
    /// true, or if the key was not found for the specified type, return false
    /// and does not modify the reference argument. </summary>
    public bool TryGetString(string key, ref string result) {
      var temp = default(string);
      if (_strings.TryGetValue(key, out temp)) {
        result = temp;
        return true;
      }
      else {
        return false;
      }
    }

    public void SetString(string key, string value) {
      _strings[key] = value;
    }

    #endregion

  }

}
