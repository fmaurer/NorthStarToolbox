using Leap.Unity.Geometry;
using Leap.Unity.Networking;
using UnityEngine;

namespace Leap.Unity.AR.Experiments {

  using UnityGrid = UnityEngine.Grid;
  using Grid = Leap.Unity.Geometry.Grid;

  public class NetworkedPhysicsObjectContextMenu : MonoBehaviour, 
    IHydraContextMenuControl
  {

    public NetworkedPhysicsObject physicsObject;

    private void Reset() {
      if (physicsObject == null) {
        physicsObject = GetComponent<NetworkedPhysicsObject>();
      }
    }

    private HydraContextMenu _contextMenu;
    public void ReceiveContextMenu(HydraContextMenu contextMenu) {
      _contextMenu = contextMenu;
    }

    public void OnImhoGUI(Imhogui gui, string path, LocalRect rect) {
      var enabledColor = Color.white;
      var disabledColor = Color.Lerp(Color.white, Color.black, 0.7f);

      var grid = new Grid(rect, numRows: 3, numCols: 2,
        cellMargins: Margins.All(0.005f));

      var isGravityEnabled = physicsObject.useGravity;
      var useColor = isGravityEnabled ? disabledColor : enabledColor;
      if (gui.Button(path + "Gravity On", label: "Gravity On",
        rect: grid[0].rect, enabled: !isGravityEnabled, color: useColor))
      {
        Debug.Log("Turning on gravity!");
        physicsObject.useGravity = true;
      }

      useColor = isGravityEnabled ? enabledColor : disabledColor;
      if (gui.Button(path + "Gravity Off", label: "Gravity Off",
        rect: grid[1].rect, enabled: isGravityEnabled, color: useColor))
      {
        Debug.Log("Turning off gravity!");
        physicsObject.useGravity = false;
      }

      var isKinematic = physicsObject.isKinematic;
      useColor = isKinematic ? enabledColor : disabledColor;
      if (gui.Button(path + "Momentum On", label: "Momentum On",
        rect: grid[2].rect, enabled: isKinematic, color: useColor))
      {
        Debug.Log("Turning on momentum!");
        physicsObject.isKinematic = false;
      }

      useColor = isKinematic ? disabledColor : enabledColor;
      if (gui.Button(path + "Momentum Off", label: "Momentum Off",
        rect: grid[3].rect, enabled: !isKinematic, color: useColor))
      {
        Debug.Log("Turning off momentum!");
        physicsObject.isKinematic = true;
      }

      var mergedCell = grid.GetMerged(4, 5);
      if (gui.Button(path + "Close", label: "Close",
        rect: mergedCell.rect))
      {
        Debug.Log("Closing!");
        _contextMenu.playerState.selectedObjectId = LeapNetManager.NO_NETWORK_ID;
      }
    }

  }

}