using UnityEngine;

namespace Leap.Unity.AR.Experiments {

  public class SelectableObject : MonoBehaviour { }

}