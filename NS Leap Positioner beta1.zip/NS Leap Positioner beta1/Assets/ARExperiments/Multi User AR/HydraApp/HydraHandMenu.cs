using Leap.Unity.Animation;
using Leap.Unity.Attributes;
using Leap.Unity.Geometry;
using Leap.Unity.Networking;
using UnityEngine;

namespace Leap.Unity.AR.Experiments {

  using UnityGrid = UnityEngine.Grid;
  using Grid = Geometry.Grid;

  public class HydraHandMenu : MonoBehaviour, IImhoguiControl {

    [SerializeField]
    [ImplementsInterface(typeof(IPropertySwitch))]
    private MonoBehaviour _menuSwitch;
    public IPropertySwitch menuSwitch {
      get { return _menuSwitch as IPropertySwitch; }
    }

    public int activeSpawnPrefabId = 0;
    public LeapNetPrefabInstantiator spawner;
    public Transform spawnPoint;
    public int activeTabIdx = 0;

    enum ActiveTab {
      Spawn,
      Tools
    }

    public void OnImhoGUI(Imhogui gui, string controlPath, LocalRect controlRect) {
      var cellMargins = Margins.one * 0.005f;

      // [0][1][2]
      // [3][4][5]
      // [6][7][8]
      var grid = new Grid(controlRect, numRows: 3, numCols: 3,
        cellMargins: cellMargins, verticalOrigin: VerticalOrigin.Top);
      var tabContentRect = grid.GetMerged(1, 8).rect;

      if (gui.Button(controlPath + "Spawn Tab", rect: grid[0].rect,
        label: "S"))
      {
        activeTabIdx = 0;
      }

      if (activeTabIdx == 0) {
        foreach (var lineRect in tabContentRect.TakeLines(
          height: grid[0].innerRect.radii.y * 2f,
          cellMargins: cellMargins))
        {
          byte lineIdx = (byte)lineRect.index;
          if (lineIdx >= spawner.spawnableGameObjects.Count) { break; }
          else {
            var spawnableObj = spawner.spawnableGameObjects[lineIdx];
            if (gui.Button(controlPath + "Spawn" + lineIdx, rect: lineRect.rect,
              label: spawnableObj.name))
            {
              spawner.InstantiateObject(lineIdx, spawnPoint.ToPose());
            }
          }
        }
      }

      if (gui.Button(controlPath + "Tools Tab", rect: grid[3].rect,
        label: "T"))
      {
        activeTabIdx = 1;
      }

      if (activeTabIdx == 1) {
        var playerState = HydraPlayerState.localSingleton;
        if (playerState != null) {
          var isSelectToolActive = playerState.tool ==
            HydraPlayerState.ToolType.Select;
          var color = isSelectToolActive ? Color.yellow : Color.white;
          if (gui.Button(controlPath + "Select Tool", rect: grid[7].rect,
            label: "Select Tool", color: color))
          {
            playerState.tool =
              HydraPlayerState.ToolType.Select;
          }
        
          var selectedId = playerState.selectedObjectId;
          var selectedIdText = selectedId == 0 ? "(None)" :
            selectedId.ToString();
          gui.Label(controlPath + " Selection Label", rect: grid[8].rect,
            label: "ID: " + selectedIdText);
        }
        else {
          gui.Label(controlPath + "NotActiveLabel", rect: tabContentRect,
            label: "(Couldn't find player)");
        }
      }


      // if (gui.Button(controlPath + "Decrement Prefab #", rect: grid[3].rect,
      //   label: "-"))
      // {
      //   activeSpawnPrefabId -= 1;
      // }
      // if (gui.Button(controlPath + "Spawn Prefab", rect: grid[4].rect,
      //   label: activeSpawnPrefabId.ToString()))
      // {
      //   spawner.InstantiateObject(activeSpawnPrefabId,
      //     pose: spawnPoint.ToPose());
      // }
      // if (gui.Button(controlPath + "Increment Prefab #", rect: grid[5].rect,
      //   label: "+"))
      // {
      //   activeSpawnPrefabId += 1;
      // }

    }

  }

}