﻿using Leap.Unity.Animation;
using Leap.Unity.Attributes;
using Leap.Unity.Geometry;
using Leap.Unity.Networking;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Leap.Unity.AR.Experiments {

  using UnityGrid = UnityEngine.Grid;
  using Grid = Leap.Unity.Geometry.Grid;

  /// <summary> Marks a class as implementing an IImhoguiControl intended for
  /// rendering a hydra context menu. </summary>
  public interface IHydraContextMenuControl : IImhoguiControl {
    void ReceiveContextMenu(HydraContextMenu contextMenu);
  }

  public class HydraContextMenu : MonoBehaviour, IImhoguiControl {

    [Tooltip("The context menu moves its canvas, so it needs a reference to its " +
      "canvas.")]
    public ImhoguiCanvas canvasToMove;

    [SerializeField]
    [ImplementsInterface(typeof(IPropertySwitch))]
    private MonoBehaviour _canvasSwitch;
    public IPropertySwitch canvasSwitch {
      get { return _canvasSwitch as IPropertySwitch; }
    }

    [MinValue(0.01f)]
    public float minMenuCameraDistance = 0.25f;
    [MinValue(0.01f)]
    public float maxMenuCameraDistance = 0.45f;

    public HydraPlayerState playerState {
      get { return HydraPlayerState.localSingleton; }
    }

    private void Update() {
      if (playerState == null) {
        // No local player state implies we aren't connected to a game session
        // yet.
        //Debug.LogWarning("No local player state found, won't open context " +
        //  "menu.", this);
        canvasSwitch.Off();
        return;
      }

      if (playerState.selectedObjectId == LeapNetManager.NO_NETWORK_ID) {
        canvasSwitch.Off();
      }
      else {
        var netObj = playerState.player.network.GetObjectFromId(
          playerState.selectedObjectId);
        if (netObj == null) {
          Debug.LogError("No object associated with selected ID: " +
            playerState.selectedObjectId);
          canvasSwitch.Off();
        }
        else {
          canvasSwitch.On();
          
          var didSelectThisFrame = playerState.didSelectThisFrame;
          if (didSelectThisFrame) {
            // Move the menu to a good position.
            var menuPose = getMenuPose(netObj.transform.position);
            canvasToMove.transform.SetPose(menuPose);
          }
        }
      }
    }

    public void OnImhoGUI(Imhogui gui, string controlPath,
      Geometry.LocalRect controlRect)
    {
      if (playerState == null) { return; }
      if (playerState.selectedObjectId == LeapNetManager.NO_NETWORK_ID) {
        return;
      }

      var netObj = playerState.player.network.GetObjectFromId(
        playerState.selectedObjectId);
      if (netObj == null) {
        Debug.LogError("No object associated with selected ID: " +
          playerState.selectedObjectId);
        return;
      }
      else {
        var contextMenuControl = netObj.GetComponent<IHydraContextMenuControl>();
        if (contextMenuControl == null) {
          Debug.LogWarning("No hydra context menu control could be found on " +
            "the selected object with ID " + playerState.selectedObjectId);
        }
        else {
          contextMenuControl.ReceiveContextMenu(this);
          contextMenuControl.OnImhoGUI(gui, controlPath + "Context Menu/",
            controlRect);
        }
      }
    }

    private Camera _cachedMainCamera = null;
    private Pose getMenuPose(Vector3 selectedObjectPosition) {
      var playerHead = playerState.player.headTransform;
      if (playerHead == null) {
        Debug.LogWarning("No head transform found for the local player; " +
          "might open the context menu in a sub-optimal location.");
        try { playerHead = (_cachedMainCamera = _cachedMainCamera == null ?
          Camera.main : _cachedMainCamera).transform; }
        catch (System.NullReferenceException) {
          throw new System.InvalidOperationException("Need to assign the " +
            "player's head transform for context menus to work.");
        }
      }
      
      var groundObjToHead = Vector3.ProjectOnPlane(
        (playerHead.position - selectedObjectPosition), Vector3.up);
      var menuFromHead = Quaternion.AngleAxis(20f, Vector3.up) * -groundObjToHead;
      var dist = menuFromHead.magnitude;
      if (dist < minMenuCameraDistance) {
        menuFromHead *= (minMenuCameraDistance / dist);
      }
      menuFromHead = Vector3.ClampMagnitude(menuFromHead, maxMenuCameraDistance);
      var position = playerHead.position + menuFromHead;
      position -= Vector3.up * 0.05f;
      
      var groundMenuToHead = Vector3.ProjectOnPlane(
        (playerHead.position - position), Vector3.up);
      var rotation = Quaternion.LookRotation(-groundMenuToHead);

      return new Pose(position, rotation);
    }

  }

}
