using Leap.Unity.Animation;
using Leap.Unity.Interaction;
using Leap.Unity.Networking;
using Leap.Unity.Networking.Events;
using System.Collections.Generic;
using UnityEngine;

namespace Leap.Unity.AR.Experiments {

  public class HydraPlayerState : MonoBehaviour {

    public enum ToolType {
      None,
      Select
    }

    public struct HydraPlayerStateSync : ILeapNetEvent {
      public int targetPlayerId;
      public ToolType activeTool;
      public int selectedObjectId;

      public int GetNetworkId() { return targetPlayerId; }
    }

    public LeapNetPlayerObject player;
    public bool autoFindControllersFromPlayer = true;
    public List<InteractionController> playerInteractionControllers;

    [Header("Tool Types")]
    public ToolType tool;

    [System.Serializable]
    public class ToolGraphicSwitchDictionary :
      SerializableDictionary<ToolType, GameObject> { }
    public ToolGraphicSwitchDictionary toolGraphicSwitches;

    [Header("Select Tool")]
    public int selectedObjectId = LeapNetManager.NO_NETWORK_ID;

    private bool _didSelectThisFrame = false;
    public bool didSelectThisFrame { get { return _didSelectThisFrame; } }

    /// <summary> If an instance of this object exists with local authority,
    /// this field will contain that instance. This only makes sense if you
    /// expect there will only be one instance with local authority at any
    /// given time.
    /// </summary>
    public static HydraPlayerState localSingleton = null;

    private void OnValidate() {
      if (autoFindControllersFromPlayer) {
        findControllersFromPlayer();
      }
    }

    private void findControllersFromPlayer() {
      if (player != null) {
        playerInteractionControllers.Clear();
        player.GetComponentsInChildren<InteractionController>(
          playerInteractionControllers);
      }
    }
    
    private void OnEnable() {
      player.OnNetworkSpawned -= onNetworkSpawned;
      player.OnNetworkSpawned += onNetworkSpawned;
      player.OnNetworkDespawned -= onNetworkDespawned;
      player.OnNetworkDespawned += onNetworkDespawned;

      if (autoFindControllersFromPlayer) {
        findControllersFromPlayer();
      }
    }

    private void OnDisable() {
      player.OnNetworkSpawned -= onNetworkSpawned;
      player.OnNetworkDespawned -= onNetworkDespawned;

      onNetworkDespawned();
    }

    private void onNetworkSpawned() {
      if (player.netState == LeapNetState.Remote) {
        player.RegisterEventListener<HydraPlayerStateSync>(this);
      }
      else if (player.netState == LeapNetState.LocalAuthority) {
        localSingleton = this;
      }
    }

    private void onNetworkDespawned() {
      if (player.netState == LeapNetState.Remote) {
        player.UnregisterEventListener<HydraPlayerStateSync>(this);
      }
      else if (player.netState == LeapNetState.LocalAuthority) {
        localSingleton = null;
      }
    }

    private void Update() {
      if (player.netState == LeapNetState.LocalAuthority) {
        doLocalUpdate();

        var currState = getCurrState();
        player.network.EnqueueEvent(currState);
      }
      else if (player.netState == LeapNetState.Remote) {
        HydraPlayerStateSync currState;
        if (player.TryDequeueEvent(this, out currState)) {
          syncFromState(currState);
        }
      }

      foreach (var typeGraphicSwitchPair in toolGraphicSwitches) {
        var toolType = typeGraphicSwitchPair.Key;
        var graphicSwitchObj = typeGraphicSwitchPair.Value;
        var isActiveTool = this.tool == toolType;
        var graphicSwitch = graphicSwitchObj.GetComponent<IPropertySwitch>();
        if (graphicSwitch == null) {
          Debug.LogWarning("Object " + graphicSwitchObj + " has no component " +
            "that implements IPropertySwitch.");
        }
        else {
          if (isActiveTool) {
            graphicSwitch.On();
          }
          else {
            graphicSwitch.Off();
          }
        }
      }
    }

    private HydraPlayerStateSync getCurrState() {
      if (!player.hasNetworkId) {
        throw new System.InvalidOperationException(
          "Must have a valid player network ID to construct the current " +
          "HydraPlayerStateSync event.");
      }
      return new HydraPlayerStateSync() {
        targetPlayerId = player.networkId,
        activeTool = this.tool,
        selectedObjectId = this.selectedObjectId
      };
    }

    private void syncFromState(HydraPlayerStateSync stateSync) {
      this.tool = stateSync.activeTool;
      this.selectedObjectId = stateSync.selectedObjectId;
    }

    private void doLocalUpdate() {
      _didSelectThisFrame = false;

      switch (tool) {

        case ToolType.None:
          break;

        case ToolType.Select:
          foreach (var intCtrl in playerInteractionControllers) {
            if (intCtrl.isPrimaryHovering &&
              intCtrl.primaryHoverDistance < 0.01f)
            {
              var intObj = intCtrl.primaryHoveredObject;
              var gameObj = intObj.gameObject;
              var isSelectable = gameObj.GetComponent<SelectableObject>() != null;
              var netObj = gameObj.GetComponent<LeapNetObject>();
              var netId = netObj == null ? LeapNetManager.NO_NETWORK_ID :
                netObj.networkId;
              if (isSelectable && netId != LeapNetManager.NO_NETWORK_ID) {
                selectedObjectId = netId;
                tool = ToolType.None;
                _didSelectThisFrame = true;
                break;
              }
            }
          }
          break;

      }
    }

  }
  
}