using System;
using System.Collections;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Net;
using System.Net.Sockets;
using System.Runtime.InteropServices;
using System.Threading;
using Leap.Unity.Attributes;
using Leap.Unity.Networking.Events;
using LiteNetLib;
using UnityEngine;

namespace Leap.Unity.Networking {

  using PlayerIdAndMethod = Tuple<int, DeliveryMethod>;

  public enum NetworkMode { Server, Client };

  /// <summary>
  /// When a client connects to a server, the server assigns the client a
  /// "player ID", and sends them this message. LeapNetManagers in Client mode
  /// automatically listen for this event and store their local player ID.
  /// Player IDs are not particularly special; they are network IDs that happen
  /// to be associated with a connected peer on the network thread.
  /// </summary>
  public struct AssignPlayerIdEvent : ILeapNetEvent {
    public int assignedPlayerId;
    public int GetNetworkId() {
      return assignedPlayerId; }
  }

  /// <summary> See client_onReceivedLocalPlayerId. </summary>
  public struct AcknowledgeAssignedPlayerIdEvent : ILeapNetEvent {
    public int assignedPlayerId;
    public int GetNetworkId() { return assignedPlayerId; }
  }
  
  public struct AnnouncePlayersEvent : ILeapNetEvent {
    public int numPlayers;
    public int GetNetworkId() { return LeapNetManager.NO_NETWORK_ID; }
    
    /// <summary>
    /// Warning: Use numPlayers to get the number of valid IDs in this array.
    /// </summary>
    [MarshalAs(UnmanagedType.ByValArray,
      SizeConst=LeapNetManager.MAX_PLAYER_COUNT)]
    public int[] playerIds;

    public AnnouncePlayersEvent(int numPlayers) {
      this.numPlayers = numPlayers;
      this.playerIds = new int[numPlayers];
    }
    public AnnouncePlayersEvent(int numPlayers, int[] playerIds) {
      this.numPlayers = numPlayers;
      this.playerIds = playerIds;
    }
  }

  /// <summary>
  /// The LeapNetManager is the top-level network management object in LeapNet.
  /// It operates in Server mode or Client mode.
  ///
  /// In Server mode, the LeapNetManager accepts connections from clients with
  /// matching application connection keys and serves as the central authority
  /// for game session state, mediating all communication from client-to-client.
  ///
  /// In Client mode, the LeapNetManager connects to a server with a matching
  /// application connection key and receives a player ID from the server. Upon
  /// receiving a player ID, the client is able to make requests from the server
  /// (such as object spawn requests) and will begin receiving synchronization
  /// data from other clients connected to the same server.
  /// </summary>
  public partial class LeapNetManager : MonoBehaviour,
    LiteNetLib.INetEventListener, ILeapNetObjectDatabase
  {

    /// <summary>
    /// A special network ID indicating a message that has no applicable network
    /// ID target or association. It may also indicate a direct message to the
    /// server, since the server is always assumed to have the first network ID
    /// of zero.
    /// </summary>
    public const int NO_NETWORK_ID = 0;

    /// <summary>
    /// The maximum number of players that are allowed to exist in a single game
    /// session. Player IDs start at 1 and the last player ID is this value.
    /// </summary>
    public const int MAX_PLAYER_COUNT = 64;

    /// <summary>
    /// The maximum number of LeapNetObjects that are allowed to exist in a
    /// single game session.
    /// </summary>
    public const int MAX_NUM_OBJECTS = 100000;

    /// <summary> 
    /// Since player IDs are just network IDs, non-player IDs begin after the
    /// last possible player ID.
    /// </summary>
    public const int FIRST_OBJECT_NETWORK_ID = MAX_PLAYER_COUNT + 1;

    /// <summary>
    /// The largest network ID that is allowed to be allocated by the server.
    /// Defined as MAX_PLAYER_COUNT + MAX_NUM_OBJECTS - 1.
    /// </summary> 
    public const int MAX_NETWORK_ID =
      MAX_PLAYER_COUNT + MAX_NUM_OBJECTS - 1;

    /// <summary>
    /// The size of the events buffer for event bytes that are passed to the
    /// network thread for sending. If we run out of buffered event byte arrays,
    /// we can't send any more messages to the thread pool until the thread
    /// passes the bytes back to the Unity thread.
    /// </summary>
    private const int EVENTS_FOR_THREAD_POOL_SIZE = 128;

    public const DeliveryMethod DEFAULT_DELIVERY_METHOD =
      DeliveryMethod.Unreliable;

    #region Inspector

    #region Network Configuration

    [Header("Network")]

    [SerializeField]
    //[OnEditorChange("networkMode")]
    [EditTimeOnly]
    private NetworkMode _networkMode = NetworkMode.Client;
    public NetworkMode networkMode { get { return _networkMode; } }

    [Tooltip("The port to serve through. Only used if the networkMode is Server.")]
    [DisableIf("_networkMode", isNotEqualTo: NetworkMode.Server)]
    public int port = 5000;
    public string applicationConnectionKey = "LeapNet Application";

    [Header("Config.json")]

    [Tooltip("This script loads prefixed variables from the Config: " +
      "<prefix><variable>, e.g., network_port.")]
    public string configPrefix = "network_";

    #endregion

    #region Logging Inspector & State

    /// <summary>
    /// Numerically ordered from most verbose to least verbose.
    /// Logs print to the Debug.Log console and the local queue of logs at the
    /// highest value and nowhere at all at the lowest.
    /// </summary>
    public enum LogMode {
      DebugLogsInBuilds       = 20,
      DebugLogsInDevBuilds    = 15,
      DebugLogsInEditorOnly   = 10,
      NoDebugLogs             = 5,
      NoLocalLogs             = 0
    }
    [Header("Logging")]
    public LogMode logMode = LogMode.DebugLogsInDevBuilds;
    private bool shouldLog {
      get { return (int)logMode > (int)LogMode.NoLocalLogs; }
    }
    private bool? _isBuild = null;
    private bool? _isDevBuild = null;
    private bool shouldDebugLog { 
      get {
        if (!_isBuild.HasValue || !_isDevBuild.HasValue) {
          // We'll just have to wait for initialization before some logs.
          return false;
        }
        var logMode = (int)this.logMode;
        var isBuild = _isBuild.Value;
        var isDevBuild = _isDevBuild.Value;
        if (isBuild && !isDevBuild)
          return logMode >= (int)LogMode.DebugLogsInBuilds;
        else if (isBuild && isDevBuild) {
          return logMode >= (int)LogMode.DebugLogsInDevBuilds;
        }
        else { // !isBuild
          return logMode > (int)LogMode.NoDebugLogs;
        }
      }
    }
    /// <summary>
    /// Numerically ordered from most verbose to least verbose.
    /// Filters log types. At InfoAndUp, all logs are let through.
    /// At CriticalOnly, only LogCritical calls are actually logged.
    /// </summary>
    public enum LogIntensity {
      InfoAndUp               = 20,
      ImportantAndUp          = 10,
      CriticalOnly            = 0
    }
    public LogIntensity logIntensity = LogIntensity.ImportantAndUp;
    public bool shouldLogInfo {
      get { return (int)logIntensity >= (int)LogIntensity.InfoAndUp; }
    }
    public bool shouldLogWarning {
      get { return (int)logIntensity >= (int)LogIntensity.ImportantAndUp; }
    }

    #endregion

    #endregion

    #region State

    /// <summary>
    /// Initialized in LeapNetManager.Awake(), this thread always references the
    /// Unity thread (also the main thread) once initialized. Use this to guard
    /// code that must always run on the Unity thread. For example:
    /// ```
    /// if (Thread.CurrentThread != LeapNetManager.unityThread) {
    /// /* error! */
    /// }
    /// ```
    /// </summary>
    public static Thread unityThread = null;

    /// <summary>
    /// Object data storage subsystem, handling per-object data storage and
    /// retrieval for, e.g., the latest sync events for objects so they can be
    /// spawned appropriately for newly-joining players, or the authoritative
    /// player ID associated with a particular object.
    /// </summary>
    private DatabaseSystem _databaseSystem;

    /// <summary>
    /// Spawn manager subsystem, handling server-side network ID allocation and
    /// calling client-side spawn and despawn handlers.
    /// </summary>
    private SpawnSystem _spawnSystem;

    /// <summary>
    /// Authority transfer subsystem, handling transfers of object authority
    /// from one client to another.
    /// </summary>
    private AuthoritySystem _authoritySystem;

    private NetManager _netManager;
    private Thread _networkThread;
    private bool _isAppRunning = false;
    private HashSet<int> _connectedPlayerIds = new HashSet<int>();
    public ReadonlyHashSet<int> server_playerIds {
      get { return _connectedPlayerIds; }
    }

    /// <summary>
    /// In Server mode, gets the number of connected players. In Client mode,
    /// usually there's only a single peer, the server.
    /// </summary>
    public int numConnectedPeers {
      get { return _connectedPlayerIds.Count; }
    }

    /// <summary>
    /// Gets whether there are any peers connected.
    /// </summary>
    public bool isConnected {
      get { return _connectedPlayerIds.Count > 0; }
    }

    private int _localPlayerId = NO_NETWORK_ID;
    public bool hasLocalPlayerId { get { return _localPlayerId != NO_NETWORK_ID; } }
    public int localPlayerId {
      get {
        if (!hasLocalPlayerId
            && networkMode == NetworkMode.Client
            && Application.isPlaying) {
          Debug.LogWarning("Client has no local player ID. Returning " +
            _localPlayerId + ". (You can prevent this spam by checking " +
            "hasLocalPlayerId before calling localPlayerId.)");
        }
        return _localPlayerId;
      }
    }

    /// <summary>
    /// If the NetManager restarts, this flag lets the Unity thread clear out
    /// any old state that may have come in from the network thread before it
    /// stopped the NetManager.
    /// </summary>
    private bool _wasStopNetManagerSent = false;

    #region Request Callbacks (Allocate Network ID)

    /// <summary>
    /// The maximum number of request callback structs the Unity thread can hold
    /// onto for the network thread to process.
    /// </summary>
    public const int MAX_REQUEST_CALLBACKS = 256;

    /// <summary>
    /// Struct containing success and error callbacks associated with a request.
    /// </summary> 
    private struct RequestCallbacks {
      public Action<int> onSuccess;
      public Action onError;
    }

    /// <summary>
    /// Contains pending callbacks when requests to the network thread are
    /// fulfilled.
    /// </summary>
    private RequestCallbacks?[] _requestCallbacks =
      new RequestCallbacks?[MAX_REQUEST_CALLBACKS];

    /// <summary>
    /// Tries to get a free index in _requestCallbacks, or fails if there are
    /// too many.
    /// </summary>
    private bool tryAllocateRequestCallbacks(Action<int> onSuccess,
                                             Action onError,
                                             out int requestCallbacksId) {
      for (int i = 0; i < _requestCallbacks.Length; i++) {
        if (!_requestCallbacks[i].HasValue) {
          requestCallbacksId = i;
          Debug.Log("Adding request callback.");
          _requestCallbacks[i] = new RequestCallbacks() {
            onSuccess = onSuccess,
            onError = onError
          };
          return true;
        }
      }
      requestCallbacksId = -1;
      Debug.LogError("Unable to allocate a new request callback set (too many " +
        "pending requests already.)");
      return false;
    }

    #endregion

    #region Thread State

    // TODO: deleteme, should be able to be replaced with Thread.IsAlive.
    // /// <summary>
    // /// Gets whether the network thread has any flags indicated it was stopped.
    // /// Will still return true if the thread is just asleep.
    // /// </summary>
    // private bool _isThreadRunning {
    //   get {
    //     return ((int)_networkThread.ThreadState &
    //       ((int)ThreadState.Aborted   | (int)ThreadState.AbortRequested |
    //        (int)ThreadState.Stopped   | (int)ThreadState.StopRequested  |
    //        (int)ThreadState.Suspended | (int)ThreadState.SuspendRequested)) == 0;
    //   }
    // }

    private bool _shouldRun_thread = false;
    private NetworkMode? _networkMode_thread = null; 

    /// <summary>
    /// When UnsyncedEvents is enabled on the NetManager, the network send
    /// thread is different than the network receive thread. This lock should be
    /// acquired before reading or writing player ID data or player NetPeer
    /// data to prevent player IDs or peers disappearing mid-send if,
    /// for example, a player peer disconnects while the server prepares to
    /// forward data to them.
    /// </summary>
    private readonly object _netIdsLock_thread = new object();

    /// <summary> Should be guarded by `_netIdsLock_thread`. </summary>
    private Dictionary<NetPeer, int> _peersToIdsMap_thread =
      new Dictionary<NetPeer, int>();
    /// <summary> Should be guarded by `_netIdsLock_thread`. </summary>
    private Dictionary<int, NetPeer> _idsToPeersMap_thread =
      new Dictionary<int, NetPeer>();

    /// <summary>
    /// Whether the server will allow new connections.
    ///
    /// Should be guarded by `_netIdsLock_thread`.
    /// </summary>
    private bool _allowConnections_thread = false;

    /// <summary>
    /// Starts at 1. The server uses this to assign new network IDs.
    ///
    /// Should be guarded by `_netIdsLock_thread`.
    /// </summary>
    private int _server_numPlayerIds_thread = 1;

    /// <summary>
    /// Starts at FIRST_OBJECT_NETWORK_ID, i.e. MAX_PLAYER_COUNT + 1. The server
    /// uses this value to assign new non-player network IDs. The largest
    /// network ID that can be allocated is MAX_NETWORK_ID, or MAX_PLAYER_COUNT +
    /// 1 + MAX_NUM_OBJECTS.
    ///
    /// Should be guarded by `_netIdsLock_thread`.
    /// </summary>
    private int _server_numNetworkIds_thread = FIRST_OBJECT_NETWORK_ID;

    /// <summary>
    /// Used for on-the-fly events packet construction and sending. Be careful
    /// to clear this before using it.
    /// </summary>
    private EventsPacket _scrapEventsPacket_thread =
      new EventsPacket(EventsPacket.MTU_SAFE_SIZE);

    /// <summary>
    /// In client mode, the thread has an events packet per delivery method.
    /// </summary>
    private Dictionary<DeliveryMethod, EventsPacket>
      _client_eventsPackets_thread =
      new Dictionary<DeliveryMethod, EventsPacket>();

    /// <summary>
    /// In server mode, the network manager maintains an events packet for
    /// each connected player and delivery method.
    /// </summary>
    private Dictionary<PlayerIdAndMethod, EventsPacket>
      _server_playerEventsPackets_thread =
      new Dictionary<PlayerIdAndMethod, EventsPacket>();
    private HashSet<PlayerIdAndMethod>
      _server_playerEventsPacketsRemovalBuffer_thread =
      new HashSet<PlayerIdAndMethod>();

    /// <summary>
    /// Bytes pool on the Unity side, passed to the thread for events.
    /// </summary>
    private Stack<byte[]> _eventBytesPoolForThread;

    #endregion

    #region Thread<->Unity Messaging

    private enum MessageType {
      StartNetManager,
      StopNetManager,
      AddPlayerId,
      RemovePlayerId,
      AssignLocalPlayerId,
      SendEvent,
      ReturnSendEventBytes,
      StopThread,
      AllocateNetworkId,
      NetworkIdWasAllocated,
      PlayerIdAssignmentAcknowledged
    }

    private struct Message {

      public MessageType type;
      public int networkId;
      public Type eventType;
      public byte[] eventBytes;
      public NetworkMode networkMode;
      public int requestId;
      public DeliveryMethod deliveryMethod;

      public static Message StartNetManager(NetworkMode networkMode) {
        return new Message() {
          type = MessageType.StartNetManager,
          networkMode = networkMode
        };
      }

      public static Message StopNetManager() {
        return new Message() {
          type = MessageType.StopNetManager
        };
      }

      public static Message AddPlayerId(int playerId) {
        return new Message() {
          type = MessageType.AddPlayerId,
          networkId = playerId
        };
      }

      public static Message RemovePlayerId(int playerId) {
        return new Message() {
          type = MessageType.RemovePlayerId,
          networkId = playerId
        };
      }

      public static Message AssignLocalPlayerId(int playerId) {
        return new Message() {
          type = MessageType.AssignLocalPlayerId,
          networkId = playerId
        };
      }

      public static Message SendEvent<T>(T networkEvent, byte[] useBytes,
        DeliveryMethod deliveryMethod = DEFAULT_DELIVERY_METHOD)
        where T : struct, ILeapNetEvent
      {
        var eventType = typeof(T);
        return new Message() {
          type = MessageType.SendEvent,
          networkId = networkEvent.GetNetworkId(),
          eventType = eventType,
          eventBytes = useBytes,
          deliveryMethod = deliveryMethod
        };
      }

      public static Message ReturnSendEventBytes(byte[] returnedBytes) {
        return new Message() {
          type = MessageType.ReturnSendEventBytes,
          eventBytes = returnedBytes
        };
      }

      public static Message StopThread() {
        return new Message() {
          type = MessageType.StopThread
        };
      }

      public static Message AllocateNetworkId(int requestId) {
        return new Message() {
          type = MessageType.AllocateNetworkId,
          requestId = requestId
        };
      }

      public static Message NetworkIdWasAllocated(int requestId, int networkId) {
        return new Message() {
          type = MessageType.NetworkIdWasAllocated,
          requestId = requestId,
          networkId = networkId
        };
      }

      public static Message PlayerIdAssignmentAcknowledged(int playerId) {
        return new Message() {
          type = MessageType.PlayerIdAssignmentAcknowledged,
          networkId = playerId
        };
      }

    }

    private const int MAX_MESSAGE_BUFFER_SIZE = 64;

    private ProduceConsumeBuffer<Message> _messagesToThread =
      new ProduceConsumeBuffer<Message>(MAX_MESSAGE_BUFFER_SIZE);

    private ProduceConsumeBuffer<Message> _messagesToUnity =
      new ProduceConsumeBuffer<Message>(MAX_MESSAGE_BUFFER_SIZE);

    #endregion

    #endregion

    #region Lifecycle Events

    protected virtual void Awake() {
      _isBuild = !Application.isEditor;
      _isDevBuild = Debug.isDebugBuild;
      _isAppRunning = Application.isPlaying;

      loadConfig();

      unityThread = Thread.CurrentThread;
      ensureNetworkThreadRunning();

      _eventBytesPoolForThread = new Stack<byte[]>(EVENTS_FOR_THREAD_POOL_SIZE);
      var largestEventSize = LeapNetEvents.GetLargestEventSize();
      for (int i = 0; i < EVENTS_FOR_THREAD_POOL_SIZE; i++) {
        _eventBytesPoolForThread.Push(new byte[largestEventSize]);
      }

      // Initialize subsystems.
      _spawnSystem = new SpawnSystem(this);
      _authoritySystem = new AuthoritySystem(this);
      if (networkMode == NetworkMode.Server) {
        _databaseSystem = new DatabaseSystem(this);
      }
    }

    private void loadConfig() {
      Config.TryRead(configPrefix + "port", ref port,
        verbose: true,
        logFunc: this.Log);
      Config.TryRead(configPrefix + "applicationConnectionKey",
        ref applicationConnectionKey,
        verbose: true,
        logFunc: this.Log);
    }

    private void OnEnable() {
      ensureNetworkThreadRunning();

      if (_wasStopNetManagerSent) {
        // Since we told the net manager to stop before, clear all messages now
        // before it starts back up.
        Message message_unused;
        _messagesToUnity.TryDequeueAll(out message_unused);
        _connectedPlayerIds.Clear();
        _wasStopNetManagerSent = false;
      }
      
      startNetManager();

      _spawnSystem.OnEnable();
      _authoritySystem.OnEnable();
    }

    private void OnDisable() {
      _spawnSystem.OnDisable();
      _authoritySystem.OnDisable();

      stopNetManager();
    }

    private void ensureNetworkThreadRunning() {
      if (_networkThread != null && _networkThread.IsAlive) {
        Log("No need to start thread, already alive. Thread state is " +
          _networkThread.ThreadState + ".");
      }
      else {
        Log("Starting a new network thread.");
        if (_networkThread == null) {
          Log("(Network thread was null.)");
        }
        else {
          Log("(Network thread state was " + _networkThread.ThreadState + ")");
        }

        _networkThread = new Thread(networkUpdate_thread);
        _networkThread.Name = "LeapNetManager Thread";
        _networkThread.IsBackground = true;
        // One-time set, before the thread is alive, _shouldRun_thread to true.
        Log("Setting _shouldRun_thread to true in ensureNetworkThreadRunning.");
        _shouldRun_thread = true;
        Log("Calling _networkThread.Start()...");
        _networkThread.Start();
      }
    }

    private void startNetManager() {
      Log("(startNetManager called on Unity thread.)");
      Log("", debug: false);
      Log("==============", debug: false);
      Log("LeapNetManager", debug: false);
      Log("==============", debug: false);
      Log("", debug: false);
      _messagesToThread.TryEnqueue(Message.StartNetManager(networkMode));
    }

    private void stopNetManager() {
      Log("stopNetManager called on Unity thread.");
      _messagesToThread.TryEnqueue(Message.StopNetManager());
      _localPlayerId = NO_NETWORK_ID;
      _connectedPlayerIds.Clear();
      _wasStopNetManagerSent = true;
    }

    // TODO: deleteme
    // protected virtual void OnDestroy() {
    //   if (Application.isEditor) {
    //     // Even if the thread is in the middle of something, too bad.
    //     if (_networkThread != null) {
    //       _networkThread.Abort();
    //     }
    //     if (netManager != null && netManager.IsRunning) {
    //       netManager.Stop();
    //     }
    //   }
    // }

    protected virtual void OnApplicationQuit() {
      _messagesToThread.TryEnqueue(Message.StopThread());
      if (_networkThread != null && _networkThread.IsAlive) {
        _networkThread.Join(timeout: TimeSpan.FromMilliseconds(2000));
      }
      // Even if the thread is in the middle of something, too bad.
      if (_netManager != null && _netManager.IsRunning) {
        LogCritical("OnApplicationQuit: Network thread still running :(");
        LogCritical("Force-stopping thread on Unity side. " +
          "Thread state was " + _networkThread.ThreadState);
        _netManager.Stop();
      }
    }

    #endregion

    #region Internal API

    /// <summary>
    /// LeapNetManager subsystems can get and set arbitrary data per-object.
    /// The method can be called by casting the network reference to the
    /// ILeapNetObjectDatabase type; the implementing methods are not public
    /// to avoid being visible in user-facing intellisense.
    ///
    /// e.g., `(network as ILeapNetObjectDatabase).GetObjectData`.
    /// </summary>
    bool ILeapNetObjectDatabase.TryGet<T>(int objectId, out T data) {
      if (networkMode == NetworkMode.Server) {
        return _databaseSystem.TryGet<T>(objectId, out data);
      }
      else { // NetworkMode.Client
        LogWarning("Client mode net manager doesn't have a database subsystem.");
        data = default(T);
        return false;
      }
    }

    /// <summary>
    /// TODO: DOCUMENTME
    /// </summary>
    void ILeapNetObjectDatabase.Remove<T>(int objectId) {
      if (networkMode == NetworkMode.Server) {
        _databaseSystem.Remove<T>(objectId);
      }
      else { // NetworkMode.Client
        LogWarning("Client mode net manager doesn't have a database subsystem.");
      }
    }

    /// <summary>
    /// LeapNetManager subsystems can get and set arbitrary data per-object.
    /// The method can be called by casting the network reference to the
    /// ILeapNetObjectDatabase type; the implementing methods are not public
    /// to avoid being visible in user-facing intellisense.
    ///
    /// e.g., `(network as ILeapNetObjectDatabase).SetObjectData`.
    /// </summary>
    void ILeapNetObjectDatabase.Set<T>(int objectId, T data) {
      if (networkMode == NetworkMode.Server) {
        _databaseSystem.Set(objectId, data);
      }
      else { // NetworkMode.Client
        LogWarning("Client mode net manager doesn't have a database subsystem.");
      }
    }

    #endregion

    #region Public API

    /// <summary>
    /// This event is only fired when the LeapNetManager is in Server mode.
    ///
    /// Fired when a new player joins the network session. The joined player's
    /// network ID (sometimes simply called "player ID") is passed as the event
    /// argument.
    ///
    /// This event is fired only after the client sends an acknowledgement
    /// back to the server that they received the server's assigned player ID;
    /// so once the event is fired, it's safe to send messages targeting that
    /// player ID. Use this when your server extension (e.g. LeapNetSpawnManager)
    /// needs to send messages to players to initialize game session data when
    /// they join.
    /// </summary>
    public event Action<int> OnPlayerJoined = (id) => { };

    /// <summary>
    /// This event is only fired when the LeapNetManager is in Client mode.
    ///
    /// Fired when the local player is assigned a player ID. The newly-assigned 
    /// ID can be accessed via the `localPlayerId` property.
    /// </summary>
    public event Action OnReceiveLocalPlayerId = () => { };

    //TODO: (Fired the local client disconnects from the server.)
    //public event Action OnLoseLocalPlayerId

    /// <summary>
    /// Registers the provided listener and networkId as a pair, assigning them
    /// a dedicated ProduceConsumeBuffer for reading event data.
    /// At any time from a single consumer thread, it's safe to call
    /// TryDequeueEvent with the same listener and networkId.
    /// </summary>
    public void RegisterEventListener<T>(int networkId, object listener,
                                         LeapNetEvents.TypeHint<T> typeHint = null)
                                         where T : struct, ILeapNetEvent {
      registerEventListener<T>(new EventListener(networkId, listener, typeof(T)));
    }

    /// <summary>
    /// Unregisters the provided listener and networkId for receiving event data.
    /// </summary>
    public void UnregisterEventListener<T>(int networkId, object listener,
                                           LeapNetEvents.TypeHint<T> typeHint = null)
                                           where T : struct, ILeapNetEvent {
      unregisterEventListener<T>(new EventListener(networkId, listener, typeof(T)));
    }

    /// <summary>
    /// If the argument networkId and listener pair have been registered with
    /// the type argument event, this method will dequeue any waiting object in
    /// a dedicated ProduceConsumeBuffer containing event data received over the
    /// network and return true. If no such data exists (or no such buffer
    /// exists), this method returns false.
    /// </summary>
    public bool TryDequeueEvent<T>(int networkId, object listener,
                                   out T networkEvent)
                                   where T : struct, ILeapNetEvent {
      return tryDequeueEvent<T>(new EventListener(networkId, listener, typeof(T)),
        out networkEvent);
    }

    /// <summary>
    /// This pattern avoids a `RuntimeBinderException` that occurs when generic
    /// ILeapNetEvents are used in combination with "out T networkEvent", even
    /// when the type hint has its type fully qualified.
    /// (As far as I can tell, this is a bug in the runtime.)
    /// 
    /// If you're running a subsystem that automatically generates and dequeues
    /// generic wrapper network events around other network event types,
    /// you'll need to use this method instead of TryDequeueEvent.
    /// (See: SpawnSystem.)
    /// </summary>
    public T SpecialDequeueEventWithGenerics<T>(int networkId, object listener,
      LeapNetEvents.TypeHint<T> typeHint, out bool wasEventDequeued)
      where T : struct, ILeapNetEvent
    {
      T dequeuedEvent = default(T);
      using (new ProfilerSample("Call tryDequeueEvent")) {
        wasEventDequeued = tryDequeueEvent<T>(new EventListener(networkId,
        listener, typeof(T)), out dequeuedEvent);
      }
      return dequeuedEvent;
    }

    /// <summary>
    /// Enqueues an event to be sent to the server if this LeapNetManager is
    /// in client mode. If the LeapNetManager is in server mode, the network ID
    /// indicates the target player ID, a broadcast (ID 0), or a broadcast that
    /// excludes a single player (negative excluded player ID; generally this is 
    /// a pattern the server only needs to use internally).
    /// 
    /// The events are dequeued and sent on a dedicated network thread.
    ///
    /// Returns false and fails to queue the event if the LeapNetManager is
    /// disabled, or has run out of byte arrays in its queueing buffer, or if
    /// enqueueing fails for any other reason.
    /// </summary>
    public bool EnqueueEvent<T>(T networkEvent,
      DeliveryMethod deliveryMethod = DEFAULT_DELIVERY_METHOD)
      where T : struct, ILeapNetEvent
    {
      if (!this.isActiveAndEnabled) {
        return false;
      }
      if (_eventBytesPoolForThread.Count == 0) {
        LogCritical("Unity thread ran out of byte arrays for enqueueing a " +
          "LeapNet event! Is the network thread halted?");
        return false;
      }
      else {
        var maxSizeGivenMethod = getEventsPacketSizeFromMethod(deliveryMethod);
        var minimumSize = LeapNetEvents.EVENT_CODE_SIZE +
          LeapNetEvents.GetEventSizeForType(typeof(T));
        var eventBytes = _eventBytesPoolForThread.Pop();
        ensureCapacity_unity(minimumSize, ref eventBytes);
        LeapNetEvents.FillBytes(networkEvent, eventBytes);
        if (minimumSize > maxSizeGivenMethod) {
          LogCritical("Cannot enqueue event of type " + typeof(T) + " because " +
            "it would require " + minimumSize + " bytes, but the size limit for " +
            "the " + deliveryMethod + " method is " + maxSizeGivenMethod);
          return false;
        }
        if (!_messagesToThread.TryEnqueue(Message.SendEvent(networkEvent,
            eventBytes, deliveryMethod))) {
          LogCritical("Failed to enqueue a message of type: " + typeof(T));
        }
      }
      return true;
    }

    private void ensureCapacity_unity(int minCapacity, ref byte[] bytes) {
      if (bytes.Length < minCapacity) {
        bytes = new byte[bytes.Length * 2];
      }
    }

    public void RequestNewNetworkId(Action<int> onSuccess, Action onError) {
      int requestCallbacksId;
      if (!tryAllocateRequestCallbacks(onSuccess, onError,
          out requestCallbacksId)) {
        onError();
      }
      else {
        Debug.Log("Enqueued request for new network ID.");
        _messagesToThread.TryEnqueue(Message.AllocateNetworkId(requestCallbacksId));
      }
    }

    /// <summary>
    /// This method can only be called when the spawn manager is in client mode.
    /// 
    /// Returns the spawned object associated with the network ID, if it is
    /// tracked by this spawn manager. If no such object is found, returns null.
    /// </summary>
    public LeapNetObject GetObjectFromId(int networkId) {
      return _spawnSystem.GetObjectFromId(networkId);
    }


    /// <summary>
    /// Requests a network ID from the server and spawns an object using the
    /// spawn handler associated with the argument object state event.
    /// Spawn handlers are static methods with a SpawnHandler attribute.
    /// You must also define a despawn handler with a DespawnHandler attribute
    /// that matches the object state event type provided to the spawn handler.
    ///
    /// Optionally, you can pass onSpawned and onDespawned callbacks.
    /// These aren't always necessary to use, since HandleSpawn and
    /// HandleDespawn for any given spawnable object is also handed by user
    /// code, but they are offered here as a convenience.
    ///
    /// The int returned is a request ID that will be passed along to the
    /// HandleSpawn call only on the local machine that requested the
    /// spawn. (It will be 0 or -1 under any other circumstances.)
    /// </summary>
    public int RequestSpawn<T>(T objectStateEvent,
      Action<int> onIdSpawned = null, bool isPlayerSpawn = false,
      bool isSingleOwnership = false)
      where T : struct, ILeapNetSpawnable
    {
      return _spawnSystem.RequestSpawn<T>(objectStateEvent, onIdSpawned,
        isPlayerSpawn, isSingleOwnership);
    }

    /// <summary>
    /// Requests that the server despawn the object ID.
    /// Will throw an KeyNotFoundException if the argument ID is not tracked by
    /// this spawn manager, or an Exception if the argument ID does not have a
    /// despawn handler associated with the despawn object's state event type.
    /// </summary>
    public void RequestDespawn(int objectNetworkId) {
      var type = _spawnSystem.GetTypeFromId(objectNetworkId);
      _spawnSystem.RequestDespawn(objectNetworkId,
        (dynamic)LeapNetEvents.GetTypeHint(type));
    }

    public void RequestAuthority(int requestingPlayerId, int objectNetworkId,
      Action onSuccess, Action<AuthorityRequestFailure> onFailure)
    {
      _authoritySystem.RequestAuthority(requestingPlayerId, objectNetworkId,
        onSuccess, onFailure);
    }

    #endregion

    #region Update Events

    private void Update() {
      // Dequeue any messages from the network thread and respond accordingly.
      Message threadMessage;
      while (_messagesToUnity.TryDequeue(out threadMessage)) {
        var m = threadMessage;
        var networkId = m.networkId;
        switch (m.type) {
          case MessageType.AddPlayerId:
            _connectedPlayerIds.Add(networkId);
            Log("Added a network ID: " + networkId);
            break;
          case MessageType.RemovePlayerId:
            if (networkId == NO_NETWORK_ID) {
              // This message indicates the client being disconnected from the
              // server.
              _localPlayerId = NO_NETWORK_ID;
            }
            _connectedPlayerIds.Remove(networkId);
            Log("Removed a network ID: " + networkId);
            break;
          case MessageType.ReturnSendEventBytes:
            var returnedBytes = m.eventBytes;
            _eventBytesPoolForThread.Push(returnedBytes);
            break;
          case MessageType.AssignLocalPlayerId:
            var assignedId = m.networkId;
            _localPlayerId = assignedId;
            client_onReceivedLocalPlayerId();
            OnReceiveLocalPlayerId();
            Log("Assigned local player ID: " + assignedId);
            break;
          case MessageType.NetworkIdWasAllocated:
            var requestId = m.requestId;
            var allocatedNetworkId = m.networkId;
            var callbacks = _requestCallbacks[requestId];
            Debug.Log("Hopefully this will call onSuccess");
            if (callbacks.HasValue) {
              callbacks.Value.onSuccess(allocatedNetworkId);
              Debug.Log("... onSuccess called.");
            }
            else {
              Debug.LogError("Tried to call back from allocated network ID " +
                "request " + requestId + ", but there were no callbacks " +
                "registered at that index in _requestCallbacks.");
            }
            break;
          case MessageType.PlayerIdAssignmentAcknowledged:
            var clientPlayerId = m.networkId;
            OnPlayerJoined(clientPlayerId);
            break;
          default:
            LogCritical("Unhandled message from the network thread: " +
              m.type);
            break;
        }
      }

      // Update subsystems.
      _spawnSystem.Update();
      _authoritySystem.Update();
    }

    /// <summary>
    /// When the client receives a local player ID from the server, it will
    /// respond back with an acknowledgement, so that server-side extensions
    /// like the spawn manager can safely send session initialization data to
    /// the newly-joined player.
    /// </summary>
    private void client_onReceivedLocalPlayerId() {
      if (networkMode == NetworkMode.Server) {
        Debug.LogError("Server should not have received a AssignLocalPlayerId " +
          "event.");
      }
      else {
        EnqueueEvent<AcknowledgeAssignedPlayerIdEvent>(
          new AcknowledgeAssignedPlayerIdEvent() {
            assignedPlayerId = this.localPlayerId
          },
          DeliveryMethod.ReliableUnordered
        );
      }
    }

    /// <summary> The main method of the network thread. </summary>
    private void networkUpdate_thread() {
      try {
        while (_shouldRun_thread) {
          // Safety: We don't want the network thread to run if we're in the
          // editor.
          if (!_isAppRunning && _netManager.IsRunning) {
            if (_netManager.ConnectedPeerList.Count > 0) {
              Debug.LogWarning("Net thread disconnecting NetManager due to " +
                "edit-mode.");
              _netManager.DisconnectAll();
            }
            else {
              Debug.LogWarning("Net thread stopping NetManager due to edit-mode.");
              _netManager.Stop();
              Log("Setting _shouldRun_thread to false because edit-mode.");
              _shouldRun_thread = false;
              break;
            }
          }

          // Check messages from Unity thread.
          Message message;
          while (_messagesToThread.TryDequeue(out message)) {
            switch (message.type) {
              case MessageType.SendEvent:
                processEvent_thread(message.networkId, message.eventType,
                  message.eventBytes, deliveryMethod: message.deliveryMethod);
                if (!_messagesToUnity.TryEnqueue(Message.ReturnSendEventBytes(
                      message.eventBytes))) {
                  LogCritical("Unity thread message queue is full! " + 
                    "Do you have a very large number of objects, or " +
                    "did something block the Unity thread for a long time? " +
                    "This is bad because some eventBytes were dropped!");
                }
                break;
              case MessageType.StartNetManager:
                if (_netManager == null) {
                  _netManager = new NetManager(this);
                  lock (_netIdsLock_thread) {
                    _server_numNetworkIds_thread = FIRST_OBJECT_NETWORK_ID;
                  }
                  _netManager.UnsyncedEvents = true;
                }

                var startMode = networkMode;
                var currMode = _networkMode_thread;
                if (_netManager.IsRunning && currMode.HasValue &&
                    startMode != currMode) {
                  Debug.LogWarning("Network thread got StartNetManager, but " +
                    "it was already running with old mode " + currMode + ". " +
                    "calling Stop() so it can be started as " + startMode);
                  _netManager.Stop();
                }
                switch (networkMode) {
                  case NetworkMode.Server:
                    Log("Launching in Server mode.");
                    if (!_netManager.IsRunning) { _netManager.Start(port); }
                    _netManager.DiscoveryEnabled = true;
                    break;
                  case NetworkMode.Client:
                    Log("Launching in Client mode.");
                    // Clients connect through an arbitrary port.
                    if (!_netManager.IsRunning) { _netManager.Start(); }
                    break;
                }
                lock (_netIdsLock_thread) {
                  _allowConnections_thread = true;
                }
                break;
              case MessageType.StopNetManager:
                Log("Network thread dequeued StopNetManager.");
                _netManager.DisconnectAll();
                lock (_netIdsLock_thread) {
                  lock (_netIdsLock_thread) {
                    _allowConnections_thread = false;
                  }
                  _idsToPeersMap_thread.Clear();
                  _peersToIdsMap_thread.Clear();
                  _server_numNetworkIds_thread = FIRST_OBJECT_NETWORK_ID;
                }
                Log("NetManager stopped listening. (It's still running though.)");
                break;
              case MessageType.StopThread:
                if (_netManager.IsRunning) {
                  lock (_netIdsLock_thread) {
                    _allowConnections_thread = false;
                  }
                  _netManager.DisconnectAll();
                }
                Log("Setting _shouldRun_thread to false because got StopThread " +
                  "message.");
                _shouldRun_thread = false;
                break;
              case MessageType.AllocateNetworkId:
                var requestId = message.requestId;
                lock (_netIdsLock_thread) {
                  var allocatedNetworkId = _server_numNetworkIds_thread++;
                  _messagesToUnity.TryEnqueue(Message.NetworkIdWasAllocated(
                    requestId,
                    allocatedNetworkId
                  ));
                }
                break;
              default:
                if (shouldDebugLog) {
                  Debug.LogError("Unable to handle a Unity-to-Network thread " +
                    "type: " + message.type.ToString());
                }
                break;
            }
          }

          // Poll the network manager.
          if (_shouldRun_thread && _netManager != null && _netManager.IsRunning) {
            // With UnsyncedEvents = true, PollEvents doesn't have to be
            // called.
            //_netManager.PollEvents();

            // If we're an unconnected client, send out a discovery request.
            if (_networkMode == NetworkMode.Client) {
              var serverPeer = _netManager.GetFirstPeer();
              if (serverPeer == null ||
                  serverPeer.ConnectionState != ConnectionState.Connected) {
                _netManager.SendDiscoveryRequest(new byte[] {1}, port);
              }
            }

            lock (_netIdsLock_thread) {
              if (_idsToPeersMap_thread.Count > 0) {
                // Flush (send) any remaining non-empty events packets.
                flushAllEventsPackets_thread();
              }
              else {
                // If we're not connected, just drop events packets.
                dropAllEventsPackets_thread(); 
              }
            }
          }

          // With UnsyncedEvents, this thread doesn't have to be fast.
          // NOTE: Sleeps are a minimum of 15 ms long on Windows.
          Thread.Sleep(1);
        }

        if (_netManager.IsRunning) {
          Log("Thread now shutting down. Calling Stop() on _networkThread.");
          _netManager.Stop();
        }
      }
      catch (System.Exception e) {
        Debug.LogError("Caught exception in network thread: " + e.ToString());
      }
    }

    private void processEvent_thread(int sendToNetworkId, Type eventType,
      byte[] eventBytes, DeliveryMethod deliveryMethod, int offset = 0)
    {
      // Add the event to the appropriate events packet based on the player ID.
      // If an events packet gets full as a part of this, we send it immediately
      // so we can clear it and keep going.
      if (networkMode == NetworkMode.Server) {
        // If the player ID is negative, this means send to "all but" that ID.
        // A positive player ID is a target message to that player ID.
        // A player ID of zero is a broadcast to all players.
        int? excludePlayerId = null; 
        if (sendToNetworkId < 0) { excludePlayerId = -sendToNetworkId; }
        if (sendToNetworkId > 0) {
          lock (_netIdsLock_thread) {
            if (_idsToPeersMap_thread.ContainsKey(sendToNetworkId)) {
              var eventsPacketKey = Tuple.Create(sendToNetworkId, deliveryMethod);
              var eventsPacket = server_ensureEventsPacketExists_thread(
                eventsPacketKey);
              var targetPeer = _idsToPeersMap_thread[sendToNetworkId];
              writeAndMaybeFlush_thread(targetPeer, eventsPacket, eventType,
                eventBytes, deliveryMethod, offset);
              Log("Wrote an event of type " + eventType + " for target ID " +
                sendToNetworkId + " with delivery method " + deliveryMethod);
            }
            else if (sendToNetworkId < _server_numNetworkIds_thread) {
              Log("Broadcasting network object ID " + sendToNetworkId + " event " +
                "to all players.");
              processEvent_thread(0, eventType, eventBytes, deliveryMethod,
                offset);
            }
            else {
              Log("Ignoring processEvent for non-existent player or network ID " +
              sendToNetworkId + "The request could be bad, or maybe the object " +
              "just disconnected recently.");
            }
          }
        }
        else {
          lock (_netIdsLock_thread) {
            // Broadcast; we might have an excludePlayerId.
            Log("Broadcasting a message of type " + eventType + " to " + 
              _idsToPeersMap_thread.Count + " players.");
            foreach (var idPeerPair in _idsToPeersMap_thread) {
              var targetId = idPeerPair.Key;
              var targetPeer = idPeerPair.Value;
              var eventsPacketKey = Tuple.Create(targetId, deliveryMethod);
              Log("[Server] Broadcasting to target ID " + targetId);
              var eventsPacket = server_ensureEventsPacketExists_thread(
                eventsPacketKey);
              if (!excludePlayerId.HasValue || excludePlayerId.Value != targetId) {
                writeAndMaybeFlush_thread(targetPeer, eventsPacket, eventType,
                  eventBytes, deliveryMethod, offset);
              }
            }
          }
        }
      }
      else { // NetworkMode.Client
        var targetPeer = _netManager.GetFirstPeer(); // The server peer.
        if (targetPeer == null) {
          // Server not connected; simply drop all events.
          dropAllEventsPackets_thread();
        }
        else {
          var eventsPacket = client_ensureEventsPacketExists_thread(
            deliveryMethod);
          writeAndMaybeFlush_thread(targetPeer, eventsPacket, eventType,
            eventBytes, deliveryMethod, offset);
        }
      }
    }

    private void writeAndMaybeFlush_thread(NetPeer targetPeer,
      EventsPacket eventsPacket, Type eventType, byte[] eventBytes,
      DeliveryMethod deliveryMethod, int offset = 0)
    {
      if (!eventsPacket.HasRemainingSpace(eventType)) {
        flushEventsPacket(targetPeer, eventsPacket, deliveryMethod);
      }
      eventsPacket.WriteEvent(eventType, eventBytes, readOffset: offset);
    }

    private void flushEventsPacket(NetPeer targetPeer, EventsPacket eventsPacket,
      DeliveryMethod deliveryMethod)
    {
      if (!eventsPacket.isEmpty) {
        try {
          targetPeer.Send(eventsPacket.GetBytes(), deliveryMethod);
        }
        catch(System.Exception e) {
          LogCritical("Network send thread failed to send events packet to " +
            "targetPeer. " + e);
        }
        eventsPacket.Clear();
      }
    }

    /// <summary>
    /// Sends out any and all pending (non-empty) events packets.
    /// </summary>
    private void flushAllEventsPackets_thread() {
      if (networkMode == NetworkMode.Server) {
        lock (_netIdsLock_thread) {
          foreach (var keyAndPacketPair in _server_playerEventsPackets_thread) {
            var playerId = keyAndPacketPair.Key.Item1;
            var deliveryMethod = keyAndPacketPair.Key.Item2;
            var eventsPacket = keyAndPacketPair.Value;
            var targetPeer = _idsToPeersMap_thread[playerId];
            flushEventsPacket(targetPeer, eventsPacket, deliveryMethod);
          }
        }
      }
      else { // NetworkMode.Client
        var targetPeer = _netManager.GetFirstPeer(); // The server peer.
        if (targetPeer == null) {
          // Server not connected; simply drop all events.
          dropAllEventsPackets_thread();
        }
        else {
          foreach (var methodAndPacketPair in _client_eventsPackets_thread) {
            var deliveryMethod = methodAndPacketPair.Key;
            var eventsPacket = methodAndPacketPair.Value;
            flushEventsPacket(targetPeer, eventsPacket, deliveryMethod);
          }
        }
      }
    }

    private EventsPacket server_ensureEventsPacketExists_thread(
      PlayerIdAndMethod playerIdAndMethod)
    {
      EventsPacket eventsPacket;
      if (!_server_playerEventsPackets_thread.TryGetValue(playerIdAndMethod,
          out eventsPacket)) {
        var eventsPacketSize =
          getEventsPacketSizeFromMethod(playerIdAndMethod.Item2);
        eventsPacket = new EventsPacket(eventsPacketSize);
        _server_playerEventsPackets_thread[playerIdAndMethod] = eventsPacket;
      }
      return eventsPacket;
    }

    private EventsPacket client_ensureEventsPacketExists_thread(
      DeliveryMethod deliveryMethod)
    {
      EventsPacket eventsPacket;
      if (!_client_eventsPackets_thread.TryGetValue(deliveryMethod,
          out eventsPacket)){ 
        var eventsPacketSize =
          getEventsPacketSizeFromMethod(deliveryMethod);
        eventsPacket = new EventsPacket(eventsPacketSize);
        _client_eventsPackets_thread[deliveryMethod] = eventsPacket;
      }
      return eventsPacket;
    }

    private int getEventsPacketSizeFromMethod(DeliveryMethod method) {
      if (method == DeliveryMethod.Sequenced || 
        method == DeliveryMethod.Unreliable ||
        method == DeliveryMethod.ReliableSequenced)
      {
        return EventsPacket.MTU_SAFE_SIZE; // about 400
      }
      else {
        return EventsPacket.MULTI_TRANSMISSION_SIZE; // allow up to 4x.
      }
    }

    private void dropAllEventsPackets_thread() {
      if (networkMode == NetworkMode.Server) {
        lock (_netIdsLock_thread) {
          foreach (var idAndPacketPair in _server_playerEventsPackets_thread) {
            var eventsPacket = idAndPacketPair.Value;
            eventsPacket.Clear();
          }
        }
      }
      else {
        foreach (var methodAndPacketPair in _client_eventsPackets_thread) {
          var eventsPacket = methodAndPacketPair.Value;
          eventsPacket.Clear();
        }
      }
    }

    #endregion

    #region Network Listeners & Callbacks

    /// <summary>
    /// This is the maximum size of each unique events buffer that is assigned
    /// to event unique event listener.
    /// </summary> 
    public const int LISTENER_EVENTS_BUFFER_SIZE = 32;

    /// <summary>
    /// A little pair struct matching a listener with its associated network ID.
    /// </summary>
    private struct EventListener
      : IEquatable<EventListener>
    {
      public int networkId;
      public object listener;
      public Type eventType;

      public EventListener(int networkId, object listener, Type eventType) {
        this.networkId = networkId;
        this.listener = listener;
        this.eventType = eventType;
      }

      // public bool Equals(EventListener x, EventListener y) {
      //   return x.networkId == y.networkId && x.listener == y.listener &&
      //     x.eventType == y.eventType;
      // }

      public bool Equals(EventListener other) {
        return this.networkId == other.networkId && this.listener == other.listener &&
          this.eventType == other.eventType;
      }
      // // public int GetHashCode(EventListener obj) {
      // //   return new Hash() { obj.networkId, obj.listener, obj.eventType };
      // // }
      public override int GetHashCode() {
        return new Hash() { networkId, listener, eventType };
      }
    }

    /// <summary> 
    /// As _eventTypesToListeners, but the listeners are wrapped in a pair
    /// struct alongside their associated player ID. This way, player event
    /// listeners can get events specific to their associated player ID.
    /// Maps an event type to a concurrent collection of key-value pairs where
    /// the key is the network ID being listened for and the EventListener
    /// contains the actual listener object.
    /// </summary>
    private ConcurrentDictionary<Type, ConcurrentDictionary<EventListener, object>>
      _eventTypesToListenersMap =
      new ConcurrentDictionary<Type, ConcurrentDictionary<EventListener, object>>();

    /// <summary>
    /// as _listenersToBuffersMap, but the key is a wrapper containing the
    /// listener and its associated player ID. This way, player event
    /// listeners can get events specific to their associated player ID.
    /// </summary>
    private ConcurrentDictionary<EventListener, object> _listenersToBuffersMap =
      new ConcurrentDictionary<EventListener, object>();

    /// <summary>
    /// This method should only be called from the Unity thread.
    /// </summary>
    private void registerEventListener<T>(EventListener eventListener)
                                         where T : struct, ILeapNetEvent {
      // Update the listeners map.
      var eventType = typeof(T);
      ConcurrentDictionary<EventListener, object> eventListeners;
      if (_eventTypesToListenersMap.TryGetValue(eventType,
                                                out eventListeners)) {
        eventListeners.TryAdd(eventListener, null);
      }
      else {
        eventListeners = new ConcurrentDictionary<EventListener, object>();
        eventListeners.TryAdd(eventListener, null);
        _eventTypesToListenersMap[eventType] = eventListeners;
      }

      // Update the buffers map.
      object buffer;
      if (!_listenersToBuffersMap.TryGetValue(eventListener, out buffer)) {
        buffer = new ProduceConsumeBuffer<T>(LISTENER_EVENTS_BUFFER_SIZE);
        _listenersToBuffersMap[eventListener] = buffer;
      }
    }

    /// <summary>
    /// This method should only be called from the Unity thread.
    /// </summary>
    private void unregisterEventListener<T>(EventListener eventListener)
                                            where T : struct, ILeapNetEvent {
      // Update the listeners map.
      var eventType = typeof(T);
      try {
        ConcurrentDictionary<EventListener, object> eventListeners;
        if (_eventTypesToListenersMap.TryGetValue(eventType,
                                                  out eventListeners)) {
          object oldValue_unused;
          eventListeners.TryRemove(eventListener, out oldValue_unused);
        }
      }
      catch (Exception e) {
        Debug.LogError("foo " + e);
      }

      // Update the buffers map.
      // We just remove the key, and let the ProduceConsumerBuffer be GC'd.
      object oldBuffer_unused;
      _listenersToBuffersMap.TryRemove(eventListener, out oldBuffer_unused);
    }

    /// <summary>
    /// This method should only be called from the Unity thread.
    /// </summary>
    private bool tryDequeueEvent<T>(EventListener eventListener,
                                    out T networkEvent)
                                    where T : struct, ILeapNetEvent {
      using (new ProfilerSample("tryDequeueEvent")) {
        object buffer;

        if (_listenersToBuffersMap.TryGetValue(eventListener, out buffer)) {
          //Log("Got a buffer for event type " + typeof(T));
          ProduceConsumeBuffer<T> produceConsumeBuffer;
          using (new ProfilerSample("buffer as ProduceConsumeBuffer")) {
            produceConsumeBuffer = buffer as ProduceConsumeBuffer<T>;
          }
          using (new ProfilerSample("return buffer.TryDequeue")) {
            return produceConsumeBuffer.TryDequeue(out networkEvent);
          }
        }
        else {
          networkEvent = default(T);
          return false;
        }
      }
    }

    [ThreadStatic]
    private static byte[] _backingEventsBuffer_socketThreads;
    /// <summary>
    /// This temporary buffer stores the data read from the NetPacketReader
    /// after OnNetworkReceive is called. Its backing array is lazy-loaded and
    /// ThreadStatic.
    /// </summary>
    private static byte[] _eventsBuffer_socketThreads {
      get {
        if (_backingEventsBuffer_socketThreads == null) {
          _backingEventsBuffer_socketThreads =
            new byte[EventsPacket.MULTI_TRANSMISSION_SIZE * 2];
        }
        return _backingEventsBuffer_socketThreads;
      }
    }

    /// <summary>
    /// This method runs on a socket thread.
    /// </summary>
    public void OnNetworkReceive(NetPeer peer, NetPacketReader reader,
                                 DeliveryMethod receivedDeliveryMethod) {
      // Log("Received network event from peer " + peer.EndPoint + ". Number of " +
      //   "bytes is " + reader.AvailableBytes + ".");

      reader.GetBytes(_eventsBuffer_socketThreads, 0, reader.AvailableBytes);

      var sendingClientPlayerId = NO_NETWORK_ID;
      lock (_netIdsLock_thread) {
        _peersToIdsMap_thread.TryGetValue(peer, out sendingClientPlayerId);
      }

      foreach (var genericEvent in new EventsPacket.Reader(
        _eventsBuffer_socketThreads))
      {
        var eventType = genericEvent.eventType;
        var bytes = genericEvent.bytes;
        var offset = genericEvent.offset;
        // Log("Identified network event of type: " + eventType +
        //   "; checking handlers.");

        int eventTargetNetworkId;
        dynamic eventTypeHint = LeapNetEvents.GetTypeHint(eventType);
        //Log("Calling parsedEvent with typeHint: " + eventTypeHint.GetType());
        dynamic parsedEvent;
        bool didParseEvent = false;
        try {
          parsedEvent = parseEvent(bytes, offset, eventTypeHint,
            out eventTargetNetworkId);
          didParseEvent = true;
        }
        catch (Exception e) {
          LogCritical("Unable to parse an event. Type was: " +
            eventTypeHint.GetType() + ". " + e.ToString());
          
          didParseEvent = false;
          parsedEvent = null;
          eventTargetNetworkId = -1;
        }
        
        var isServer = networkMode == NetworkMode.Server;

        // The server will forward messages containing non-player network IDs
        // to all players except the player who sent the message.
        // The server will also forward messages that players send "to
        // themselves" (targeting their own ID) to all other players.
        var shouldForwardMessage = false;
        var messageForwardTargetId = (int?)null;
        if (sendingClientPlayerId != NO_NETWORK_ID) {
          lock (_netIdsLock_thread) {
            shouldForwardMessage = !_idsToPeersMap_thread.ContainsKey(
              eventTargetNetworkId) ||
              sendingClientPlayerId == eventTargetNetworkId;
            // Negative ID means "everyone except the ID".
            messageForwardTargetId = -sendingClientPlayerId;
          }
        }

        // Special case: When a client receives an AssignPlayerId event from
        // the server, this event is handled directly by the LeapNetManager.
        if (networkMode == NetworkMode.Client
            && eventType == typeof(AssignPlayerIdEvent)) {
          onClientAssignPlayerIdEvent(
            LeapNetEvents.ReadBytes<AssignPlayerIdEvent>(bytes, offset));
        }

        // Special case: When a server receives AcknowledgeAssignedPlayerIdEvent
        // from a client, we enqueue a message for the Unity side so server
        // extensions like the spawn manager can then safely send session
        // initialization data to the newly-joined player.
        if (networkMode == NetworkMode.Server
            && eventType == typeof(AcknowledgeAssignedPlayerIdEvent)) {
          shouldForwardMessage = false;
          messageForwardTargetId = null;
          onServerAcknowledgeAssignedPlayerIdEvent(
            LeapNetEvents.ReadBytes<AcknowledgeAssignedPlayerIdEvent>(bytes,
              offset));
        }

        ConcurrentDictionary<EventListener, object> eventListeners;
        if (_eventTypesToListenersMap.TryGetValue(eventType, out eventListeners)) {
          if (eventListeners.Count > 0) {
            // Log("Found " + eventListeners.Count + " handler" +
            //   (eventListeners.Count == 1 ? "" : "s") + " for this event of " +
            //   "type: " + eventType);
            foreach (var eventListenerObjPair in eventListeners) {
              var eventListener = eventListenerObjPair.Key;
              if (eventListener.networkId != eventTargetNetworkId) continue;
              if (didParseEvent) {
                enqueueEvent(eventListener, parsedEvent);
              }
              // if (isServer) {
              //   Log(Enqueued event, type: " + eventType);
              // }
              // Log("...and was enqueued for event with networkId " + 
              //   (parsedEvent as ILeapNetEvent).GetNetworkId());
            }
          }
          else {
            //Log("No handler for " + eventType + " found. (Key existed.)");
          }
        }
        else {
          //Log("No handler for " + eventType + " found.");
        }

        // Message forwarding:
        // Currently, the server will forward messages sent "to" an object ID
        // to all players except the player who sent the message.
        // The server will also forward to all other players any messages that
        // players send "to" themselves. (This indicates sync data for a player
        // object, whose network ID _is_ the player ID.)
        if (isServer && shouldForwardMessage && messageForwardTargetId.HasValue) {
          processEvent_thread(messageForwardTargetId.Value,
            eventType, bytes, receivedDeliveryMethod, offset);
          //Log("[Server] Forwarded event of type " + eventType);
        }
      }
    }

    //private static ConcurrentQueue<int> foo = new ConcurrentQueue<int>();
    [ThreadStatic] private static int foo2;
    // DELETEME (obvi)
    //[ThreadStatic] private static int foo = 0;
    private void aPlainOldFunction() {
      //foo += 1;
      //Thread.Sleep(0);
      //Log("foo");
      //foo.Enqueue(0);
    }

    private T parseEvent<T>(byte[] bytes, int offset,
      LeapNetEvents.TypeHint<T> typeHint, out int eventTargetNetworkId)
      where T : struct, ILeapNetEvent
    {
      //Log("Doing parseEvent on thread " + Thread.CurrentThread.Name);
      //Log("hiii");
      //aPlainOldFunction();
      var networkEvent = LeapNetEvents.ReadBytes<T>(bytes, offset);
      eventTargetNetworkId = networkEvent.GetNetworkId();
      return networkEvent;
    }

    private T parseAndProcessEvent<T>(byte[] bytes, int offset,
      DeliveryMethod deliveryMethod, LeapNetEvents.TypeHint<T> typeHint)
      where T : struct, ILeapNetEvent
    {
      var networkEvent = LeapNetEvents.ReadBytes<T>(bytes, offset);
      processEvent_thread(networkEvent.GetNetworkId(), typeof(T), bytes,
        deliveryMethod, offset);
      return networkEvent;
    }

    /// <summary>
    /// This method should only be called from the Unity thread.
    /// </summary>
    private void enqueueEvent<T>(EventListener listener, T networkEvent)
                                 where T : struct, ILeapNetEvent {
      if (listener.networkId != networkEvent.GetNetworkId()) {
        return;
      }
      object buffer;
      if (_listenersToBuffersMap.TryGetValue(listener, out buffer)) {
        var produceConsumeBuffer = buffer as ProduceConsumeBuffer<T>;
        if (buffer == null) {
          LogCritical("Produce consume buffer for listener with ID " +
            listener.networkId + " and type " + typeof(T) + " was " +
            "in the buffers map, but was null.");
        }
        if (produceConsumeBuffer == null) {
          LogCritical("Produce consume buffer for listener with ID " +
            listener.networkId + " and type " + typeof(T) + " was " +
            "not convertible to ProduceConsumerBuffer of that type.");
        }
        produceConsumeBuffer.TryEnqueue(networkEvent);
      }
      else {
        LogCritical("Failed to enqueue an event of type: " + typeof(T));
      }
    }

    private void onClientAssignPlayerIdEvent(AssignPlayerIdEvent ev) {
      if (networkMode == NetworkMode.Server) {
        LogCritical("Server received AssignPlayerIdEvent; this isn't " +
          "supposed to happen; servers should be doing the assigning.");
      }
      else { // NetworkMode.Client
        var assignedPlayerId = ev.assignedPlayerId;
        Log("Network thread got a player ID: " + assignedPlayerId);
        _messagesToUnity.TryEnqueue(Message.AssignLocalPlayerId(assignedPlayerId));
      }
    }

    private void onServerAcknowledgeAssignedPlayerIdEvent(
      AcknowledgeAssignedPlayerIdEvent ev
    ) {
      _messagesToUnity.TryEnqueue(Message.PlayerIdAssignmentAcknowledged(
        ev.assignedPlayerId
      ));
    }

    /// <summary>
    /// This method runs on the network thread.
    /// </summary>
    public void OnNetworkReceiveUnconnected(IPEndPoint remoteEndPoint,
                                            NetPacketReader reader,
                                            UnconnectedMessageType messageType) {
      if (networkMode == NetworkMode.Server) {
        if (messageType == UnconnectedMessageType.DiscoveryRequest) {
          lock (_netIdsLock_thread) {
            if (_allowConnections_thread) {
              _netManager.SendDiscoveryResponse(new byte[] {1}, remoteEndPoint);
            }
          }
        }
      }
      else { // NetworkMode.Client
        if (messageType == UnconnectedMessageType.DiscoveryResponse &&
            _netManager.PeersCount == 0) {
          lock (_netIdsLock_thread) {
            if (_allowConnections_thread) {
              _netManager.Connect(remoteEndPoint, applicationConnectionKey);
            }
          }
        }
      }
    }

    /// <summary>
    /// This method runs on the network thread.
    /// </summary>
    public void OnConnectionRequest(ConnectionRequest request) {
      if (networkMode == NetworkMode.Server) {
        lock (_netIdsLock_thread) {
          if (_allowConnections_thread &&
              _server_numPlayerIds_thread < MAX_PLAYER_COUNT) {
            request.AcceptIfKey(applicationConnectionKey);
          }
          else {
            Log("Rejected connection request.");
            request.Reject();
          }
        }
      }
      else { // NetworkMode.Client

      }
    }

    /// <summary>
    /// This method runs on the network thread.
    /// </summary>
    public void OnPeerConnected(NetPeer peer) {
      if (networkMode == NetworkMode.Server) {
        lock (_netIdsLock_thread) {
          Log("Peer connected at " + peer.EndPoint + ". This peer will "
            + "receive player ID " + _server_numPlayerIds_thread + ".");

          var newPlayerId = _server_numPlayerIds_thread++;
            
          _idsToPeersMap_thread[newPlayerId] = peer;
          _peersToIdsMap_thread[peer] = newPlayerId;

          // For the player that just joined, send an event assigning them a
          // player ID, followed by a list of all the players currently connected.
          threadSendNewPlayerIdAndAnnounce(peer, newPlayerId);

          // Since a new peer joined, announce all connected players to all other
          // connected players.
          threadSendAnnouncePlayers(excludePlayerId: newPlayerId);

          // Notify the Unity thread about the change.
          _messagesToUnity.TryEnqueue(Message.AddPlayerId(newPlayerId));
        }
      }
      else { // NetworkMode.Client
        Log("Connected to server at " + peer.EndPoint);

        lock (_netIdsLock_thread) {
          // Remember the server peer via the 'null' network ID.
          _idsToPeersMap_thread[NO_NETWORK_ID] = peer;
          _peersToIdsMap_thread[peer] = NO_NETWORK_ID;

          // Notify the Unity thread about the change.
          _messagesToUnity.TryEnqueue(
            Message.AddPlayerId(LeapNetManager.NO_NETWORK_ID));
        }
      }
    }

    /// <summary>
    /// _playersLock_thread is assumed to be acquired for the duration of this
    /// function.
    /// </summary>
    private void threadSendNewPlayerIdAndAnnounce(NetPeer peer, int newPlayerId) {
      // ServerAssignPlayerIdEvent.
      var assignPlayerIdEvent = new AssignPlayerIdEvent() {
        assignedPlayerId = newPlayerId
      };
      _scrapEventsPacket_thread.Clear();
      _scrapEventsPacket_thread.TryWriteEvent<AssignPlayerIdEvent>(
        assignPlayerIdEvent);

      // ServerAnnouncePlayersEvent.
      var announcePlayersEvent = new AnnouncePlayersEvent(
        _idsToPeersMap_thread.Count);
      int announcedIdIdx = 0;
      foreach (var idPeerPair in _idsToPeersMap_thread) {
        var id = idPeerPair.Key;
        announcePlayersEvent.playerIds[announcedIdIdx++] = id;
      }
      _scrapEventsPacket_thread.TryWriteEvent<AnnouncePlayersEvent>(
        announcePlayersEvent);

      // Send the temporary events packet to the peer.
      peer.Send(_scrapEventsPacket_thread.GetBytes(), DEFAULT_DELIVERY_METHOD);
    }

    /// <summary>
    /// _playersLock_thread is assumed to be acquired for the duration of this
    /// function.
    /// </summary>
    private void threadSendAnnouncePlayers(int? excludePlayerId = null) {
      var announcePlayersEvent = new AnnouncePlayersEvent(
        _idsToPeersMap_thread.Count);
      int announcedIdIdx = 0;
      foreach (var idPeerPair in _idsToPeersMap_thread) {
        var id = idPeerPair.Key;
        announcePlayersEvent.playerIds[announcedIdIdx++] = id;
      }
      _scrapEventsPacket_thread.Clear();
      _scrapEventsPacket_thread.TryWriteEvent<AnnouncePlayersEvent>(
        announcePlayersEvent);

      foreach (var idPeerPair in _idsToPeersMap_thread) {
        var peer = idPeerPair.Value;

        // Send the temporary events packet to the peer.
        peer.Send(_scrapEventsPacket_thread.GetBytes(), DEFAULT_DELIVERY_METHOD);
      }
    }

    public void OnPeerDisconnected(NetPeer peer, DisconnectInfo disconnectInfo) {
      var disconnectWasTimeout =
        disconnectInfo.Reason == DisconnectReason.Timeout;
      Log("Peer disconnected: " + peer.EndPoint +
        " Disconnect reason: " + disconnectInfo.Reason);
      if (disconnectWasTimeout) {
        LogWarning("A peer was disconnected due to connection timeout.");
      }

      if (networkMode == NetworkMode.Server) {
        lock (_netIdsLock_thread) {
          int disconnectedId;
          if (_peersToIdsMap_thread.TryGetValue(peer, out disconnectedId)) {
            Log("Got disconnect for peer at " + peer.EndPoint);
            _peersToIdsMap_thread.Remove(peer);
            _idsToPeersMap_thread.Remove(disconnectedId);
            
            server_removePlayerEventsPacketsForId(disconnectedId);

            // Since a peer disconnected, announce all connected players.
            // Spawn managers will receive despawn calls for any missing players.
            threadSendAnnouncePlayers();

            // Notify Unity about the change.
            _messagesToUnity.TryEnqueue(Message.RemovePlayerId(disconnectedId));
          }
          else {
            Log("Had no ID for peer " + peer.EndPoint + " on disconnect. " +
              "ConnectId was " + peer.ConnectId);
            _peersToIdsMap_thread.Remove(peer);
            int maybeFoundDisconnectedId = -1;
            foreach (var idAndPeerPair in _idsToPeersMap_thread) {
              Log("Checking idAndPeerPair... ID " + idAndPeerPair.Key + " at " +
                idAndPeerPair.Value.ConnectId);
              if (peer.ConnectId == idAndPeerPair.Value.ConnectId) {
                maybeFoundDisconnectedId = idAndPeerPair.Key;
                break;
              }
            }
            if (maybeFoundDisconnectedId != -1) {
              Log("Found an ID (" + maybeFoundDisconnectedId +
                ") that matched for peer at " + peer.EndPoint + ", though.");

              _idsToPeersMap_thread.Remove(maybeFoundDisconnectedId);
              server_removePlayerEventsPacketsForId(maybeFoundDisconnectedId);

              threadSendAnnouncePlayers();

              // Notify Unity about the change.
              _messagesToUnity.TryEnqueue(Message.RemovePlayerId(disconnectedId));
            }
            else {
              Log("Had no known peer that matched " + peer.EndPoint + ".");
            }
          }
        }
      } // NetworkMode.Client
      else {
        lock (_netIdsLock_thread) {
          // Remove the server connection.
          _idsToPeersMap_thread.Remove(NO_NETWORK_ID);
          _peersToIdsMap_thread.Remove(peer);

          _messagesToUnity.TryEnqueue(
            Message.RemovePlayerId(LeapNetManager.NO_NETWORK_ID));
        }
      }
    }

    private void server_removePlayerEventsPacketsForId(int playerIdToRemove) {
      _server_playerEventsPacketsRemovalBuffer_thread.Clear();
      foreach (var idAndMethodPair in _server_playerEventsPackets_thread) {
        var testPlayerId = idAndMethodPair.Key.Item1;
        if (testPlayerId == playerIdToRemove) {
          var deliveryMethod = idAndMethodPair.Key.Item2;
          var eventsPacketKey = Tuple.Create(playerIdToRemove, deliveryMethod);
          _server_playerEventsPacketsRemovalBuffer_thread.Add(eventsPacketKey);
        }
      }
      foreach (var eventsPacketKey in
          _server_playerEventsPacketsRemovalBuffer_thread) {
        _server_playerEventsPackets_thread.Remove(eventsPacketKey);
      }
      _server_playerEventsPacketsRemovalBuffer_thread.Clear();
    }

    public void OnNetworkError(IPEndPoint endPoint, SocketError socketError) {
      //_messagesToUnity.TryEnqueue(/* a meaningful string for logging */);
    }

    public void OnNetworkLatencyUpdate(NetPeer peer, int latency) {
      //_messagesToUnity.TryEnqueue(/* a Message with latency info */);
    }

    #endregion

    #region Logging (Unity thread only)

    public const int MAX_LATEST_LOG_MESSAGES = 48;

    private ConcurrentQueue<string> _backingLatestLogsBuffer;
    private ConcurrentQueue<string> _latestLogsBuffer {
      get {
        if (_backingLatestLogsBuffer == null) {
          _backingLatestLogsBuffer = new ConcurrentQueue<string>();
        }
        return _backingLatestLogsBuffer;
      }
      set { _backingLatestLogsBuffer = value; }
    }

    #pragma warning disable 0414 // "unused" warning
    [SerializeField]
    [TextArea]
    private string _latestLogs = "";
    #pragma warning restore 0414 
    
    public string latestLogs { get { return _latestLogs; } }

    public void Log(string message, bool? debug) {
      if (!shouldLogInfo) return;
      if (shouldDebugLog && (!debug.HasValue || debug.Value)) {
        Debug.Log("[" + networkMode + "] " + message);
      }
      if (shouldLog) {
        _latestLogsBuffer.Enqueue(message);
        updateLatestLogs();
      }
    }
    public void Log(string message) {
      Log(message, null);
    }

    public void LogWarning(string message, bool? debug = null) {
      if (!shouldLogWarning) return;
      if (shouldDebugLog && (!debug.HasValue || debug.Value)) {
        Debug.LogWarning("[" + networkMode + "] [Warning] " + message);
      }
      _latestLogsBuffer.Enqueue(message);
      updateLatestLogs();
    }

    public void LogCritical(string message) {
      if (shouldDebugLog) { Debug.LogError("[" + networkMode + "] [Critical] " + message); }
      _latestLogsBuffer.Enqueue(message);
      updateLatestLogs();
    }

    protected virtual void updateLatestLogs() {
      while (_latestLogsBuffer.Count > Mathf.Max(1, MAX_LATEST_LOG_MESSAGES)) {
        string unusedResult;
        _latestLogsBuffer.TryDequeue(out unusedResult);
      }
      _latestLogs = string.Join("\n", _latestLogsBuffer);
    }

    #endregion
    
  }

}
