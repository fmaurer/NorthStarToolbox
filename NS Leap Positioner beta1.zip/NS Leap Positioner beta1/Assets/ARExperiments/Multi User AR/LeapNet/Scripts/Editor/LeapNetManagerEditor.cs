using UnityEngine;
using UnityEditor;

namespace Leap.Unity.Networking {

  [CustomEditor(typeof(LeapNetManager))]
  public class LeapNetManagerEditor : CustomEditorBase<LeapNetManager> {
    
    // protected override void OnEnable() {
    //   base.OnEnable();
    // }

    public override void OnInspectorGUI() {
      if (target.networkMode == NetworkMode.Client) {
        var playerIdString = target.hasLocalPlayerId ?
          target.localPlayerId.ToString() : "N/A (Not connected.)";
        GUILayout.Label("Local Player ID: " + playerIdString);
      }
      else {
        GUILayout.Label("Connected Peers: " + target.numConnectedPeers);
      }

      base.OnInspectorGUI();
    }

  }

}
