﻿using UnityEngine;
using System.Collections.Generic;
using Leap.Unity.Attributes;
using Leap.Unity.AR.Experiments;
namespace Leap.Unity.Networking {
  public class LeapNetPrefabInstantiator : MonoBehaviour {

    public static IDGameObjectDict s_IDsToGameObjects;

    public IDGameObjectDict spawnableGameObjects = new IDGameObjectDict();
    [System.Serializable]
    public class IDGameObjectDict :
      SerializableDictionary<byte, NetworkedPhysicsObject> { }

    public LeapNetManager network;

    public void OnEnable() {
      s_IDsToGameObjects = spawnableGameObjects;
      if (network.hasLocalPlayerId) {
        network.RegisterEventListener<SpawnSystem.InitialServerStateSyncEvent>
          (0, this);
      } else {
        network.OnReceiveLocalPlayerId += () => {
          network.RegisterEventListener<SpawnSystem.InitialServerStateSyncEvent>
            (0, this);
        };
      }
    }
    public void OnDisable() {
      s_IDsToGameObjects = null;
      if (network.hasLocalPlayerId) {
        network.UnregisterEventListener<SpawnSystem.InitialServerStateSyncEvent>
          (0, this);
      }
    }

    bool hasSpawnedInitialState = false;
    void Update() {
      SpawnSystem.InitialServerStateSyncEvent initialSyncEvent;
      if (network.TryDequeueEvent(0, this, out initialSyncEvent) &&
          !hasSpawnedInitialState) { // Necessary for two clients in same scene
        if (initialSyncEvent.numPrexistingObjects == 0) {
          foreach (Transform child in transform) {
            NetworkedPhysicsObject obj = 
              child.GetComponent<NetworkedPhysicsObject>();
            if (obj != null) {
              foreach (KeyValuePair<byte, NetworkedPhysicsObject>
                IDedObject in s_IDsToGameObjects) {
                if (IDedObject.Value.gameObject.Equals(obj.gameObject)) {
                  InstantiateObject(IDedObject.Key, 
                                    obj.transform.ToPose(),
                                    obj.transform.localScale);
                  break;
                }
              }
            }
          }
          hasSpawnedInitialState = true;
        }
      }
    }

    public void InstantiateObject(int id) {
      NetworkedPhysicsObject prefab;
      if (spawnableGameObjects.TryGetValue((byte)id, out prefab)) {
        InstantiateObject(id, new Pose(prefab.transform.position,
          prefab.transform.rotation), prefab.transform.lossyScale);
      }
    }

    public void InstantiateObject(int objID, Pose pose,
      Vector3? localScale = null)
    {
      NetworkedPhysicsObject prefab;
      if (spawnableGameObjects.TryGetValue((byte)objID, out prefab)) {
        if (network == null) {
          Debug.Log("Could not find network!", this);
          GameObject instance = Instantiate(prefab.gameObject,
            transform.position, Quaternion.identity);
          instance.SetActive(true);
        } else if (network.hasLocalPlayerId) {
          NetworkedPhysicsObject.PhysicsSyncEvent sync;
          var useLocalScale = localScale.HasValue ? localScale.Value :
            prefab.transform.lossyScale;
          sync = new NetworkedPhysicsObject.PhysicsSyncEvent {
            pose = pose,
            localScale = useLocalScale,
            prefabID = (byte)objID,
            isKinematic = prefab.isKinematic,
            useGravity = prefab.useGravity,
            deltaTime = prefab.updateInterval,
            authoritySoftLocked = false
          };
          network.RequestSpawn(sync);
        }
      }
    }
  }
}
