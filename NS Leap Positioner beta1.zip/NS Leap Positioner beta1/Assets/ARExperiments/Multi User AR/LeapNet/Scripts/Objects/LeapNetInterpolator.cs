﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Leap.Unity.Encoding;

namespace Leap.Unity.Networking {

  public class LeapNetInterpolator<T> where T : IInterpolable<T>, new() {

    [Range(0f, 0.3f)]
    public float prediction = 0f;
    public bool useSmoothingSpline = false;

    private float _playheadTime = 0f;
    private float _playheadSampleInterval = 0.03f;
    private Queue<T> _updateBuffer = new Queue<T>();
    private bool firstUpdate = true;

    private T _prevprevprevUpdate = new T(),
              _prevprevUpdate = new T(),
              _prevUpdate = new T(),
              _curUpdate = new T();

    public LeapNetInterpolator(bool useSmoothingSpline = true) {
      this.useSmoothingSpline = useSmoothingSpline;
    }

    public void clearToState(T state) {
      firstUpdate = true;
      _updateBuffer.Clear();
      enqueueUpdate(state, 0.0001f);
    }

    public void enqueueUpdate(T update, float deltaTime) {
      if (firstUpdate) {
        _prevprevprevUpdate.CopyFrom(update);
        _prevprevUpdate.CopyFrom(update);
        _prevUpdate.CopyFrom(update);
        _curUpdate.CopyFrom(update);
        firstUpdate = false;
      }

      _playheadSampleInterval = Mathf.Clamp(
        Mathf.Lerp(_playheadSampleInterval, deltaTime, 0.1f),
        0f, 1f
      );

      _updateBuffer.Enqueue(update);
    }

    public bool interpolateSample(ref T toFill, float unscaledDeltaTime) {
      // Constantly adjust the playback speed so there is always at least one
      // sample in the buffer.
      var playbackSpeed = _updateBuffer.Count * 0.5f;

      // Move the playhead forward.
      _playheadTime += unscaledDeltaTime * playbackSpeed;
      _playheadTime = Mathf.Clamp(_playheadTime, 0f,
                                  _playheadSampleInterval * 3f);

      // Read from the state buffer until playback has caught up.
      while ((_updateBuffer.Count > 0) &&
             (_playheadTime > _playheadSampleInterval)) {
        T update = _updateBuffer.Dequeue();

        _prevprevprevUpdate.CopyFrom(_prevprevUpdate);
        _prevprevUpdate.CopyFrom(_prevUpdate);
        _prevUpdate.CopyFrom(_curUpdate);
        _curUpdate.CopyFrom(update);

        _playheadTime -= _playheadSampleInterval;
      }

      // Interpolate to get the state at the current playhead time
      var t = (_playheadTime + prediction) / _playheadSampleInterval;
      if (toFill != null && (!useSmoothingSpline ?
          toFill.FillLerped(_prevUpdate, _curUpdate, t) :
          toFill.FillSplined(_prevprevprevUpdate, _prevprevUpdate, _prevUpdate,
            _curUpdate, t)) &&
          t < 2f) {
        return true;
      }
      return false;
    }
  }
}
