﻿using System;
using System.Collections;
using System.Collections.Generic;
using Leap.Unity.Networking;
using Leap.Unity.Networking.Events;
using UnityEngine;
using Leap.Unity.Encoding;
using Leap.Unity.Splines;
using Leap.Unity.RuntimeGizmos;
using Leap.Unity.Interaction;

namespace Leap.Unity.AR.Experiments {

  public class NetworkedPhysicsObject : LeapNetObject {

    [Tooltip("The interval (in seconds) in which transform " +
      "updates are sent out or checked.")]
    public float updateInterval = 0.030f;

    [Tooltip("Despawns this object when request despawn is called; " +
      "unsetting this is useful for scene singletons which should not " +
      "be despawnable.")]
    public bool despawnable = true;

    private LeapNetInterpolator<PhysicsSyncEvent> interpolator = 
      new LeapNetInterpolator<PhysicsSyncEvent>();
    private bool authoritySoftLocked = false;
    private byte prefabID = 0; // For future sync events

    private Rigidbody _rigidbody;
    private InteractionBehaviour _intObj;
    private void findRigidbody() { _rigidbody = GetComponent<Rigidbody>(); }
    private void findIntObj() { _intObj = GetComponent<InteractionBehaviour>(); }
    public bool useGravity {
      get { 
        if (_rigidbody == null) { return false; }
        else { return _rigidbody.useGravity; }
      }
      set {
        if (_rigidbody != null) { _rigidbody.useGravity = value; }
      }
    }
    public bool isKinematic {
      get {
        if (_intObj != null) { return _intObj.GetKinematicWithoutGrasp(); }
        else if (_rigidbody != null) { return _rigidbody.isKinematic; }
        else { return true; }
      }
      set {
        if (_intObj != null) { _intObj.SetKinematicWithoutGrasp(value); }
        else if (_rigidbody != null) { _rigidbody.isKinematic = value; }
      }
    }

    public struct PhysicsSyncEvent : ILeapNetSpawnable, 
                                     IInterpolable<PhysicsSyncEvent> {
      public int networkId;
      public int GetNetworkId() { return networkId; }
      public void SetNetworkId(int networkId) { this.networkId = networkId; }

      [SerializeField]
      public byte prefabID;
      public Pose pose;
      public Vector3 localScale;
      public bool authoritySoftLocked;
      public float deltaTime;
      public bool useGravity;
      public bool isKinematic;

      /// <summary> Copies a SyncEvent from another SyncEvent </summary>
      public PhysicsSyncEvent CopyFrom(PhysicsSyncEvent h) {
        pose = h.pose;
        localScale = h.localScale;
        prefabID = h.prefabID;
        authoritySoftLocked = h.authoritySoftLocked;
        deltaTime = h.deltaTime;
        useGravity = h.useGravity;
        isKinematic = h.isKinematic;
        return this;
      }
      public bool FillLerped(PhysicsSyncEvent a, PhysicsSyncEvent b, float t) {
        pose = Pose.LerpUnclamped(a.pose, b.pose, t);
        localScale = Vector3.LerpUnclamped(a.localScale, b.localScale, t);
        prefabID = a.prefabID;
        authoritySoftLocked = a.authoritySoftLocked;
        deltaTime = b.deltaTime;
        useGravity = a.useGravity;
        isKinematic = a.isKinematic;
        return true;
      }
      public bool FillSplined(PhysicsSyncEvent a, PhysicsSyncEvent b, 
                              PhysicsSyncEvent c, PhysicsSyncEvent d, 
                              float t) {
        pose.position = CatmullRom.ToCHS(
                   a.pose.position, b.pose.position, 
                   c.pose.position, d.pose.position, false).PositionAt(t);
        pose.rotation = Quaternion.SlerpUnclamped(b.pose.rotation, 
                                                  c.pose.rotation, t);
        localScale = CatmullRom.ToCHS(
           a.localScale, b.localScale, 
           c.localScale, d.localScale, false).PositionAt(t);
        prefabID = b.prefabID;
        authoritySoftLocked = b.authoritySoftLocked;
        deltaTime = c.deltaTime;
        useGravity = b.useGravity;
        isKinematic = b.isKinematic;
        return true;
      }
    }

    [SpawnHandler(typeof(PhysicsSyncEvent))]
    public static LeapNetObject HandleSpawn(LeapNetManager network,
      int spawnedNetworkId, bool hasLocalAuthority, PhysicsSyncEvent spawnState,
      int spawnRequestId)
    {
      Debug.Log("NetworkedBlock got HandleSpawn, spawnedNetworkId: " +
        spawnedNetworkId);

      //Need to have a LeapPrefabInstantiator component in your scene
      NetworkedPhysicsObject prefab;
      //Debug.LogWarning("STATIC OBJECT BEING CREATED WITH ID: " + spawnState.prefabID);
      if (LeapNetPrefabInstantiator.s_IDsToGameObjects.
            TryGetValue(spawnState.prefabID, out prefab)) {
        GameObject instance = Instantiate(prefab.gameObject, 
          spawnState.pose.position, spawnState.pose.rotation);
        instance.SetActive(true);
        NetworkedPhysicsObject physObj = instance.
          GetComponent<NetworkedPhysicsObject>();
        if (physObj != null) {
          if (spawnState.localScale != Vector3.zero) {
            physObj.syncState(spawnState);
            physObj.interpolator.enqueueUpdate(spawnState, 
                                               physObj.updateInterval);
          } else {
            Debug.LogError("Got spawn event with zero local scale!!");
          }
          physObj.NotifyNetworkSpawned(network, spawnedNetworkId, 
                                       hasLocalAuthority);
        } else {
          Debug.Log("COULD NOT FIND NETWORKED PHYSICS OBJECT");
        }
        return physObj;
      } else { Debug.Log("COULD NOT FIND PREFAB!"); }
      return null;
    }

    [DespawnHandler(typeof(PhysicsSyncEvent))]
    public static bool HandleDespawn(LeapNetObject objectToDespawn) {
      bool despawnable = (objectToDespawn as 
                          NetworkedPhysicsObject).despawnable;
      if (despawnable) {
        objectToDespawn.NotifyNetworkDespawned();
        Destroy(objectToDespawn.gameObject);
      }
      return despawnable;
    }

    private void OnEnable() {
      findRigidbody();
      findIntObj();

      OnNetworkSpawned -= registerSyncEventListener;
      OnNetworkSpawned += registerSyncEventListener;
      OnNetworkDespawned -= unregisterSyncEventListener;
      OnNetworkDespawned += unregisterSyncEventListener;
      OnAuthorityChanged -= onAuthority;
      OnAuthorityChanged += onAuthority;
    }

    private void OnDisable() { }

    private void registerSyncEventListener() {
      network.Log("[" + netState + "] Registered sync event listener.");
      network.RegisterEventListener<PhysicsSyncEvent>(networkId, this);
    }

    private void unregisterSyncEventListener() {
      network.RegisterEventListener<PhysicsSyncEvent>(networkId, this);
    }

    private void onAuthority() {
      if (netState == LeapNetState.Remote) {
        PhysicsSyncEvent syncEvent = new PhysicsSyncEvent {
          pose = transform.ToPose(),
          localScale = transform.localScale,
        };
        interpolator.clearToState(syncEvent);
      }
      //Always set to false to prevent accumulation of bad state
      hasLocalAuthorityMandate = false;
    }

    Vector3 lastPosition;
    float lastMoved = 0f;
    private float _skipTimer = 0;
    public PhysicsSyncEvent? lastSyncEvent = null;
    bool hasLocalAuthorityMandate = false;
    private void Update() {
      var shouldUpdateNetwork = false;
      float effectiveUpdateInterval = updateInterval;

      using (new ProfilerSample("Update skip timer")) {
        if (_rigidbody == null) { _rigidbody = GetComponent<Rigidbody>(); }
        if ((!_rigidbody.isKinematic && _rigidbody.IsSleeping()) ||
            Vector3.Distance(lastPosition, transform.position) < 0.0001f) {
          if ((Time.unscaledTime - lastMoved) > 0.5f) {
            effectiveUpdateInterval *= 100f;
            /*RuntimeGizmoDrawer drawer;
            if (RuntimeGizmoManager.TryGetGizmoDrawer(out drawer)) {
              drawer.DrawWireSphere(transform.position, 0.1f);
            }*/
          }
        } else {
          lastMoved = Time.unscaledTime;
        }

        if ((_skipTimer += Time.unscaledDeltaTime) > effectiveUpdateInterval) {
          _skipTimer -= effectiveUpdateInterval;
          shouldUpdateNetwork = true;
        }
      }

      if (netState == LeapNetState.LocalAuthority && shouldUpdateNetwork) {
        using (new ProfilerSample("Enqueue new sync event")) {
          if (_rigidbody == null) { findRigidbody(); }
          PhysicsSyncEvent syncEvent =
            new PhysicsSyncEvent() {
              networkId = networkId,
              pose = transform.ToPose(),
              localScale = transform.localScale,
              authoritySoftLocked = authoritySoftLocked,
              prefabID = prefabID,
              deltaTime = effectiveUpdateInterval,
              //useGravity = _rigidbody == null ? false : _rigidbody.useGravity,
              //isKinematic = _rigidbody == null ? true : _rigidbody.isKinematic
            };

          network.EnqueueEvent(syncEvent);
          lastPosition = transform.position;
        }
      } else if (netState == LeapNetState.Remote && !hasLocalAuthorityMandate) {
        PhysicsSyncEvent syncEvent;
        while (network.TryDequeueEvent(networkId, this, out syncEvent)) {
          // network.Log("NetworkedBlock got sync event with id " +
          //   syncEvent.GetNetworkId());
          interpolator.enqueueUpdate(syncEvent, syncEvent.deltaTime);
        }

        if (interpolator.interpolateSample(ref syncEvent, 
                                           Time.unscaledDeltaTime)) {

          if (syncEvent.localScale == Vector3.zero) {
            Debug.LogError("Interpolated sync event with zero local scale!! Ignoring it.");
            return;
          }
          syncState(syncEvent);
          lastSyncEvent = syncEvent;
        }
      }
    }

    /// <summary> Called whenever a new block sync packet comes in. </summary>
    public void syncState(PhysicsSyncEvent syncEvent) {

      transform.position = syncEvent.pose.position;
      transform.rotation = syncEvent.pose.rotation;
      transform.localScale = syncEvent.localScale;
      authoritySoftLocked = syncEvent.authoritySoftLocked;
      this.prefabID = syncEvent.prefabID;

      if (_rigidbody == null) { findRigidbody(); }
      if (_rigidbody != null) {

        if (lastSyncEvent.HasValue) {
          var lastSync = lastSyncEvent.Value;
          if (syncEvent.pose.position != lastSync.pose.position) {
            if (syncEvent.deltaTime == 0f) {
              Debug.LogError("Sync event delta time was zero! Ignoring setting " +
                "velocity and angular velocity.");
            }
            else {
              _rigidbody.velocity = (syncEvent.pose.position -
                              lastSync.pose.position) / syncEvent.deltaTime;
              Quaternion deltaRot = syncEvent.pose.rotation *
                                  Quaternion.Inverse(lastSync.pose.rotation);
              _rigidbody.angularVelocity = InteractionEngineUtility.PhysicsUtility.
                                  ToAngularVelocity(deltaRot, syncEvent.deltaTime);
            }
          }
        }

        //_rigidbody.useGravity = syncEvent.useGravity;
        //_rigidbody.isKinematic = syncEvent.isKinematic;
      }
    }

    /// <summary> Called by scripts upon beginning interaction. </summary>
    public void requestLocalAuthority() {
      if (!authoritySoftLocked) {
        network.RequestAuthority(network.localPlayerId, networkId, null, null);
        if(netState != LeapNetState.LocalAuthority) hasLocalAuthorityMandate = true;
      } else { network.Log("Authority Request Failed: Object is Softlocked"); }
    }

  }

}