using System.Collections.Generic;
using Leap.Unity.Attributes;
using Leap.Unity.Networking.Events;
using UnityEngine;

namespace Leap.Unity.Networking {

  /// <summary>
  /// Players are exceedingly simple LeapNetObjects: They don't actually need
  /// to sync any data; they simply need to be identified by their player
  /// network ID (sometimes called a "player ID" in this context).
  /// <summary>
  public struct PlayerSyncEvent : ILeapNetEvent {
    public int networkId;
    public int GetNetworkId() { return networkId; }
  }

  public class PlayerSpawnManager : MonoBehaviour {

    public LeapNetManager network;

    [Header("Local Player")]

    [Tooltip("The local player. If instantiateLocalPlayer is true, this will " +
      "be treated as a prefab or disabled object to spawn and enable when the " +
      "scene starts, as for a remote player.")]
    public LeapNetObject localPlayer;
    [EditTimeOnly, SerializeField]
    private bool _instantiateLocalPlayer = false;
    public bool instantiateLocalPlayer { get { return _instantiateLocalPlayer; } }
    private LeapNetObject _localPlayerInstance;

    [Header("Remote Players")]

    [Tooltip("Prefab or disabled scene object to spawn and enable for a remote " +
      "player when the player is connected.")]
    public LeapNetObject remotePlayerTemplate;

    public string remotePlayerRigPrefix = "Remote Player ";

    private void OnEnable() {
      // AnnouncePlayers is a special event that's not associated with any
      // particular network ID.
      network.RegisterEventListener<AssignPlayerIdEvent>(
        LeapNetManager.NO_NETWORK_ID, this);
    }

    private void OnDisable() {
      network.UnregisterEventListener<AssignPlayerIdEvent>(
        LeapNetManager.NO_NETWORK_ID, this);
    }

    private int _TODO_TEMP_FIXME_connectedPlayerCount = 0;

    private void Update() {
      if (!network.isConnected && _TODO_TEMP_FIXME_connectedPlayerCount > 0) {
        // If the network disconnects, we should deactivate all spawns,
        // including the network player.
        // TODO: Will this be handled by the LeapNetSpawnManager?
        throw new System.NotImplementedException();
      }

      AssignPlayerIdEvent assignPlayerIdEvent;
      while (network.TryDequeueEvent(LeapNetManager.NO_NETWORK_ID, this,
                                     out assignPlayerIdEvent)) {
        // When we are assigned a local player ID, we should spawn the local
        // player in the network session.
        //network.TryEnqueueEvent()
      }

      // AnnouncePlayersEvent announcedPlayers;
      // while (network.TryDequeueEvent(LeapNetManager.NO_NETWORK_ID, this,
      //                                out announcedPlayers)) {
      //   onServerAnnouncePlayers(announcedPlayers);
      // }
    }

    // private Dictionary<int, LeapNetObject> _connectedPlayers =
    //   new Dictionary<int, LeapNetObject>();
    // private HashSet<int> _announcedPlayers = new HashSet<int>();
    // private HashSet<int> _playersToRemoveCache = new HashSet<int>();
    // private void onServerAnnouncePlayers(AnnouncePlayersEvent ev) {
    //   if (!network.hasLocalPlayerId && ev.numPlayers > 0) {
    //     // Without a local player ID, we can't do any spawning.
    //     // (Despawning is OK.)
    //     return;
    //   }
    //   if (ev.numPlayers == 0) {
    //     Debug.Log("Got announced disconnect from client.");
    //   }

    //   // Get the announced players from the event.
    //   _announcedPlayers.Clear();
    //   for (int i = 0; i < ev.numPlayers; i++) {
    //     var playerId = ev.playerIds[i];
    //     if (playerId == 0) { break; } // 0 is not a valid ID; indicates end.
    //     else {
    //       _announcedPlayers.Add(playerId);
    //     }
    //   }

    //   // Spawn players in the announced set but not in the connected set.
    //   foreach (var announcedId in _announcedPlayers) {
    //     if (!_connectedPlayers.ContainsKey(announcedId)) {
    //       var isLocalId = announcedId == network.localPlayerId;
    //       var newPlayer = SpawnNetworkPlayer(announcedId);
    //       _connectedPlayers[announcedId] = newPlayer;
    //     }
    //   }

    //   // Despawn players in the connected set but not in the announced set.
    //   foreach (var idNetPlayerPair in _connectedPlayers) {
    //     var connectedId = idNetPlayerPair.Key;
    //     if (!_announcedPlayers.Contains(connectedId)) {
    //       var playerToDespawn = idNetPlayerPair.Value;
    //       DespawnNetworkPlayer(playerToDespawn);
    //       _playersToRemoveCache.Add(connectedId);
    //     }
    //   }

    //   // Remove despawned player keys.
    //   foreach (var despawnId in _playersToRemoveCache) {
    //     _connectedPlayers.Remove(despawnId);
    //   }
    //   _playersToRemoveCache.Clear();
    // }

    public LeapNetObject SpawnNetworkPlayer(int playerId) {
      if (!network.hasLocalPlayerId) {
        // This shouldn't ever happen, but it's the first implementation so
        // I'm being extra cautious.
        throw new System.Exception("Can't spawn any network players if the " +
          "network hasn't been assigned a player ID.");
      }

      _TODO_TEMP_FIXME_connectedPlayerCount += 1;

      LeapNetObject spawnedPlayer;
      GameObject obj;
      if (network.localPlayerId == playerId) {
        if (_instantiateLocalPlayer) {
          spawnedPlayer = GameObject.Instantiate(localPlayer);
          _localPlayerInstance = spawnedPlayer;
          obj = spawnedPlayer.gameObject;
          obj.SetActive(true);
          _localPlayerInstance.NotifyNetworkSpawned(this.network, playerId,
            hasLocalAuthority: true);
          network.Log("Instantiated and activated local player, ID " + playerId +
            ".");
        }
        else {
          spawnedPlayer = localPlayer;
          obj = spawnedPlayer.gameObject;
          obj.SetActive(true);
          localPlayer.NotifyNetworkSpawned(this.network, playerId,
            hasLocalAuthority: true);
          network.Log("Activated existing local player, ID " + playerId + ".");
        }
      }
      else {
        spawnedPlayer = GameObject.Instantiate(remotePlayerTemplate);
        obj = spawnedPlayer.gameObject;
        obj.name = remotePlayerRigPrefix + "(ID " + playerId + ")";
        obj.SetActive(true);
        spawnedPlayer.NotifyNetworkSpawned(this.network, playerId,
          hasLocalAuthority: false);
        network.Log("Instantiated and activated remote player, ID " + playerId +
          ".");
      }

      return spawnedPlayer;
    }

    public void DespawnNetworkPlayer(LeapNetObject playerToDespawn) {
      if (playerToDespawn == localPlayer) {
        network.Log("Deactivating local player, ID " + localPlayer.networkId +
          ".");
        playerToDespawn.NotifyNetworkDespawned();
      }
      else if (playerToDespawn == _localPlayerInstance) {
        network.Log("Destroying GameObject of local player, ID " + 
          _localPlayerInstance.networkId);
        _localPlayerInstance.NotifyNetworkDespawned();
        GameObject.Destroy(_localPlayerInstance.gameObject);
      }
      else {
        network.Log("Destroying GameObject of NetworkPlayer, ID " +
          playerToDespawn.networkId + ".");
        playerToDespawn.NotifyNetworkDespawned();
        GameObject.Destroy(playerToDespawn.gameObject);
      }
    }
  }

}
