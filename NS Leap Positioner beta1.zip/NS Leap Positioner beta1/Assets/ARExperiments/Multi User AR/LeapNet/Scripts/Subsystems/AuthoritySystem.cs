using System;
using System.Collections.Generic;
using Leap.Unity.Networking.Events;
using UnityEngine;

namespace Leap.Unity.Networking {

  /// <summary>
  /// Database storage type for rememembering authority data per object.
  /// Provided for the DatabaseSystem subsystem.
  /// </summary>
  public struct LeapNetObjectAuthorityData : LeapNetObjectData {
    public int playerWithAuthority;

    /// <summary> The singleOwnership flag indicates an object can only be
    /// owned by the player that spawned that object. Authority cannot be
    /// transferred to another player; if authority would transfer to another
    /// player due to spawning-player disconnect or the object loses its
    /// heartbeat, the object is instead despawned. </summary>
    public bool singleOwnership;
  }

  /// <summary>
  /// Clients produce these events when they want to receive local authority
  /// object in order to affect its simulation or network representation in
  /// some way.
  /// </summary>
  public struct AuthorityRequestEvent : ILeapNetEvent,
    IEquatable<AuthorityRequestEvent>
  {
    public int requestingPlayerId;
    public int requestId;
    public int objectNetworkId;

    // Authority requests are always sent from the client to the server.
    // The network ID to use for routing just should be the server's ID.
    public int GetNetworkId() { return LeapNetManager.NO_NETWORK_ID; }

    public bool Equals(AuthorityRequestEvent other) {
      return this.requestingPlayerId == other.requestingPlayerId &&
        this.requestId == other.requestId &&
        this.objectNetworkId == other.objectNetworkId;
    }
  }

  public enum AuthorityRequestResult { Granted, Rejected };
  public enum AuthorityRequestFailure {
    None,
    NetworkInactive,
    RequestRaisedException,
    NetworkQueueFull,
    AuthorityWasLocked,
    ObjectWasSingleOwnership
  }

  /// <summary>
  /// Servers produce these events in response to AuthorityRequestEvents,
  /// sending them directly to the client that produced the request.
  /// The server responds with a result if Accepted or Rejected depending on
  /// its decision to grant or deny the authority transfer.
  /// If the request is granted, an AuthorityTransfer event is also embedded
  /// in the authority response event sent back to the requesting client.
  /// (Otherwise, the embedded transfer event's IsValid property will be false.)
  /// </summary>
  public struct AuthorityResponseEvent : ILeapNetEvent {
    public int requestingPlayerId;
    public int requestId;
    public int objectNetworkId;
    public AuthorityRequestResult requestResult;
    public AuthorityRequestFailure failureReason;
    public AuthorityTransferEvent transferIfGranted;

    public int GetNetworkId() { return requestingPlayerId; }
  }

  /// <summary>
  /// Servers produce these events when it approves an authority transfer,
  /// sending the events (using a Reliable method) to both the client who will
  /// receive the new authority and the client who will be losing authority over
  /// the chosen object.
  /// </summary>
  public struct AuthorityTransferEvent : ILeapNetEvent {
    public int messageTargetPlayerId;
    public int objectNetworkId;
    public int originalAuthorityPlayerId;
    public int newAuthorityPlayerId;

    public int GetNetworkId() { return messageTargetPlayerId; }
    public bool IsValid { get { return objectNetworkId != 0; } }
  }

  /// <summary>
  /// An obscuring interface to protect the NotifyAuthorityGiven and
  /// NotifyAuthorityLost methods on LeapNetObjects, since only the
  /// AuthoritySystem should be calling those methods.
  /// </summary>
  public interface IInternalAuthorityNotifiable {
    void NotifyAuthorityGiven();
    void NotifyAuthorityLost();
  }

  public class AuthoritySystem {

    public const LiteNetLib.DeliveryMethod AUTHORITY_DELIVERY_METHOD =
      LiteNetLib.DeliveryMethod.ReliableUnordered;

    public LeapNetManager network;

    public AuthoritySystem(LeapNetManager network) {
      this.network = network;
    }

    private struct AuthorityRequestCallbacks :
      IEquatable<AuthorityRequestCallbacks>
    {
      public AuthorityRequestEvent authorityRequestEvent;
      public Action onSuccess;
      public Action<AuthorityRequestFailure> onFailure;

      public bool Equals(AuthorityRequestCallbacks other) {
        return this.authorityRequestEvent.Equals(other.authorityRequestEvent) &&
          this.onSuccess == other.onSuccess && this.onFailure == other.onFailure;
      }
    }

    private int _maxRequestId = 0;
    private Dictionary<AuthorityRequestEvent, AuthorityRequestCallbacks>
      _client_pendingRequests =
      new Dictionary<AuthorityRequestEvent, AuthorityRequestCallbacks>();
    private bool _wereAnyEventsRegistered = false;
      
    public void OnEnable() {
      if (network.networkMode == NetworkMode.Server) {
        // Listen for AuthorityRequestEvents.
        network.RegisterEventListener<AuthorityRequestEvent>(
          LeapNetManager.NO_NETWORK_ID, this);
        _wereAnyEventsRegistered = true;
      }
      else { // NetworkMode.Client
        network.OnReceiveLocalPlayerId -= client_onReceiveLocalPlayerId;
        network.OnReceiveLocalPlayerId += client_onReceiveLocalPlayerId;
      }
    }

    public void OnDisable() {
      if (_wereAnyEventsRegistered) {
        if (network.networkMode == NetworkMode.Server) {
          network.UnregisterEventListener<AuthorityRequestEvent>(
            LeapNetManager.NO_NETWORK_ID, this);
        }
        else {
          network.UnregisterEventListener<AuthorityResponseEvent>(
            network.localPlayerId, this);
        }
      }
        network.OnReceiveLocalPlayerId -= client_onReceiveLocalPlayerId;
    }

    private void client_onReceiveLocalPlayerId() {
      // Listen for AuthorityResponseEvents.
      network.RegisterEventListener<AuthorityResponseEvent>(
        network.localPlayerId, this);
      _wereAnyEventsRegistered = true;

      // Listen for AuthorityTransferEvents.
      network.RegisterEventListener<AuthorityTransferEvent>(
        network.localPlayerId, this);
      _wereAnyEventsRegistered = true;
    }
    
    public void RequestAuthority(int requestingPlayerId, int objectNetworkId,
      Action onSuccess, Action<AuthorityRequestFailure> onFailure)
    {
      if (network.networkMode == NetworkMode.Server) {
        ILeapNetObjectDatabase database = (network as ILeapNetObjectDatabase);

        // Send the Authority Transfer event to the client receiving authority
        // And the client losing authority
        LeapNetObjectAuthorityData authorityData;
        if (database.TryGet(objectNetworkId, out authorityData)) {
          if (authorityData.singleOwnership) {
            // The authority request originated from the server.
            network.LogWarning("Server requested authority transfer for an " +
              "object marked single-ownership. The object will instead be " +
              "despawned.");
            onFailure(AuthorityRequestFailure.ObjectWasSingleOwnership);
            network.RequestDespawn(objectNetworkId);
          }
          else if (authorityData.playerWithAuthority != requestingPlayerId) {
            var receivedAuthorityEvent = new AuthorityTransferEvent() {
              messageTargetPlayerId = authorityData.playerWithAuthority,
              objectNetworkId = objectNetworkId,
              originalAuthorityPlayerId = authorityData.playerWithAuthority,
              newAuthorityPlayerId = requestingPlayerId
            };
            network.EnqueueEvent(receivedAuthorityEvent, AUTHORITY_DELIVERY_METHOD);

            var lostAuthorityEvent = receivedAuthorityEvent;
            lostAuthorityEvent.messageTargetPlayerId = requestingPlayerId;
            network.EnqueueEvent(lostAuthorityEvent, AUTHORITY_DELIVERY_METHOD);

            //Set the internal authority representation
            var newAuthority = new LeapNetObjectAuthorityData() {
              playerWithAuthority = requestingPlayerId
            };
            database.Remove<LeapNetObjectAuthorityData>(objectNetworkId);
            database.Set(objectNetworkId, newAuthority);
          } else {
            Debug.Log("PLAYER ALREADY HAS AUTHORITY");
            onSuccess();
          }
        } else {
          network.Log("Authority Reassignment failed, no original.");
        }
      } else { // NetworkMode.Client
        if (network.GetObjectFromId(objectNetworkId).netState != 
              LeapNetState.LocalAuthority) {
          var authorityRequest = new AuthorityRequestEvent() {
            requestingPlayerId = requestingPlayerId,
            requestId = _maxRequestId++,
            objectNetworkId = objectNetworkId
          };
          if (!network.EnqueueEvent(authorityRequest, AUTHORITY_DELIVERY_METHOD)) {
            onFailure(AuthorityRequestFailure.NetworkQueueFull);
          } else {
            var requestCallbacks = new AuthorityRequestCallbacks() {
              authorityRequestEvent = authorityRequest,
              onSuccess = onSuccess,
              onFailure = onFailure
            };
            _client_pendingRequests[authorityRequest] = requestCallbacks;
          }
        } else {
          //Player already has Authority
          if (onSuccess != null) { onSuccess(); }
        }
      }
    }

    public void Update() {
      if (network.networkMode == NetworkMode.Server) {
        AuthorityRequestEvent authorityRequest;
        while (network.TryDequeueEvent<AuthorityRequestEvent>(
          LeapNetManager.NO_NETWORK_ID, this, out authorityRequest))
        {
          server_onAuthorityRequestEvent(authorityRequest);
        }
      }
      else { // NetworkMode.Client
        if (network.hasLocalPlayerId) {
          AuthorityResponseEvent authorityResponse;
          while (network.TryDequeueEvent<AuthorityResponseEvent>(
            network.localPlayerId, this, out authorityResponse))
          {
            client_onAuthorityResponseEvent(authorityResponse);
          }

          AuthorityTransferEvent authorityTransfer;
          while (network.TryDequeueEvent<AuthorityTransferEvent>(
            network.localPlayerId, this, out authorityTransfer))
          {
            client_onAuthorityTransferEvent(authorityTransfer);
          }
        }
      }
    }

    private void server_onAuthorityRequestEvent(
      AuthorityRequestEvent authorityRequest)
    {
      if (network.networkMode == NetworkMode.Client) {
        network.LogCritical("Client is not supposed to call " +
          "server_onAuthorityRequestEvent.");
      }

      var objectId = authorityRequest.objectNetworkId;
      var objectDb = (network as ILeapNetObjectDatabase);
      LeapNetObjectAuthorityData currAuthorityData;
      if (!objectDb.TryGet<LeapNetObjectAuthorityData>(objectId,
        out currAuthorityData))
      {
        network.LogWarning("Got authority request for object ID " + objectId +
          ", but the object database had no authority data for that object.");
      }
      else {
        var currAuthorityId = currAuthorityData.playerWithAuthority;
        // TODO: Implement authority locking
        var isAuthorityLocked = false;//currAuthorityData.isAuthorityLocked;
        var isSingleOwnership = currAuthorityData.singleOwnership;
        if (isAuthorityLocked) {
          // Reject the authority request, for the reason that the owning
          // authority has locked their authority over the requested object.
          var rejectionResponse = new AuthorityResponseEvent() {
            requestingPlayerId = authorityRequest.requestingPlayerId,
            requestId = authorityRequest.requestId,
            objectNetworkId = objectId,
            requestResult = AuthorityRequestResult.Rejected,
            failureReason = AuthorityRequestFailure.AuthorityWasLocked,
            transferIfGranted = default(AuthorityTransferEvent)
          };
          network.EnqueueEvent<AuthorityResponseEvent>(rejectionResponse,
            AUTHORITY_DELIVERY_METHOD);
        }
        else if (isSingleOwnership) {
          // Reject the authority request because authority is not allowed to
          // change for single-ownership objects.
          var rejectionResponse = new AuthorityResponseEvent() {
            requestingPlayerId = authorityRequest.requestingPlayerId,
            requestId = authorityRequest.requestId,
            objectNetworkId = objectId,
            requestResult = AuthorityRequestResult.Rejected,
            failureReason = AuthorityRequestFailure.ObjectWasSingleOwnership,
            transferIfGranted = default(AuthorityTransferEvent)
          };
          network.EnqueueEvent<AuthorityResponseEvent>(rejectionResponse,
            AUTHORITY_DELIVERY_METHOD);
        }
        else {
          // Apply the authority change, respond with an acceptance of the
          // authority request, and send an authority transfer message to
          // both the player who is getting authority and the player who is
          // losing authority.
          var originalAuthorityId = currAuthorityId;
          currAuthorityData.playerWithAuthority = currAuthorityId =
            authorityRequest.requestingPlayerId;
          objectDb.Set<LeapNetObjectAuthorityData>(objectId,
            currAuthorityData);

          // For the player who is receiving authority, we embed the authority
          // transfer inside the authority response event.
          var receivingPlayerAuthorityTransfer = new AuthorityTransferEvent() {
            messageTargetPlayerId = authorityRequest.requestingPlayerId,
            objectNetworkId = objectId,
            originalAuthorityPlayerId = originalAuthorityId,
            newAuthorityPlayerId = currAuthorityId
          };
          var acceptanceResponse = new AuthorityResponseEvent() {
            requestingPlayerId = authorityRequest.requestingPlayerId,
            requestId = authorityRequest.requestId,
            objectNetworkId = objectId,
            requestResult = AuthorityRequestResult.Granted,
            failureReason = AuthorityRequestFailure.None,
            transferIfGranted = receivingPlayerAuthorityTransfer
          };
          network.EnqueueEvent(acceptanceResponse, AUTHORITY_DELIVERY_METHOD);
          
          // Authority transfer from the player losing authority. This transfer
          // is sent on its own, since no request was sent for it.
          var removedPlayerAuthorityTransfer =
            receivingPlayerAuthorityTransfer;
          removedPlayerAuthorityTransfer.messageTargetPlayerId =
            originalAuthorityId;
          network.EnqueueEvent(removedPlayerAuthorityTransfer,
            AUTHORITY_DELIVERY_METHOD);
        }
      }
    }

    private void client_onAuthorityResponseEvent(
      AuthorityResponseEvent authorityResponse) 
    {
      // Reconstruct the request from the response data and check for the
      // corresponding pending request in memory.
      var reconstructedRequest = new AuthorityRequestEvent() {
        requestingPlayerId = authorityResponse.requestingPlayerId,
        requestId = authorityResponse.requestId,
        objectNetworkId = authorityResponse.objectNetworkId
      };
      AuthorityRequestCallbacks callbacks;
      if (!_client_pendingRequests.TryGetValue(reconstructedRequest,
        out callbacks))
      { 
        network.LogWarning("Got an authority response event, but had no " +
          "pending request for which we were waiting for a response. " +
          "Ignoring it.");
      }
      else {
        if (authorityResponse.requestResult == AuthorityRequestResult.Rejected) {
          // Fire the failed callback.
          callbacks.onFailure(authorityResponse.failureReason);
        }
        else if (authorityResponse.requestResult ==
          AuthorityRequestResult.Granted)
        {
          // Apply the embedded authority transfer and fire the success callback.
          var embeddedAuthorityTransfer = authorityResponse.transferIfGranted;
          client_onAuthorityTransferEvent(embeddedAuthorityTransfer);
          if (callbacks.onSuccess != null) { callbacks.onSuccess(); }
        }
        else {
          network.LogCritical("Unknown AuthorityRequestResult: " +
            authorityResponse.requestResult);
        }
      }
    }

    // private void client_onAuthorityTransferEvent(
    //   AuthorityTransferEvent authorityTransfer)
    // {
    //   if (!network.hasLocalPlayerId) {
    //     throw new System.InvalidOperationException(
    //       "client_onAuthorityTransferEvent requires that the network have a " +
    //       "local player ID.");
    //   }
    //   var isReceivingAuthority = authorityTransfer.newAuthorityPlayerId ==
    //     network.localPlayerId;
    //   var objectId = authorityTransfer.objectNetworkId;
    //   var networkObject = network.GetObjectFromId(objectId);
    //   if (isReceivingAuthority) {
    //     (networkObject as IInternalAuthorityNotifiable).NotifyAuthorityGiven();
    //   }
    //   else {
    //     (networkObject as IInternalAuthorityNotifiable).NotifyAuthorityLost();
    //   }
    // }

    private void client_onAuthorityTransferEvent(
      AuthorityTransferEvent authorityTransfer)
    {
      if (network.networkMode == NetworkMode.Server) {
        network.LogCritical("Server should not receive AuthorityTransfer events, " +
          "it should be the one sending them.");
      }
      else { // NetworkMode.Client
        var networkId = authorityTransfer.objectNetworkId;
        var originalAuthorityId = authorityTransfer.originalAuthorityPlayerId;
        var newAuthorityId = authorityTransfer.newAuthorityPlayerId;

        if (!network.hasLocalPlayerId) {
          network.LogCritical("Got AuthorityTransfer event, but don't have a " +
            "local player ID.");
        }
        else {
          var netObject = network.GetObjectFromId(networkId);
          if (netObject == null) {
            network.LogWarning("No object found associated with network ID " +
              networkId + " during authority transfer event. Ignoring the " +
              "authority transfer event.");
          }
          else {
            if (originalAuthorityId == network.localPlayerId) {
              // This local player is losing authority over the object.
              (netObject as IInternalAuthorityNotifiable).NotifyAuthorityLost();
            }
            else if (newAuthorityId == network.localPlayerId) {
              // This local player is gaining authority over the object.
              (netObject as IInternalAuthorityNotifiable).NotifyAuthorityGiven();
            }
            else {
              network.LogWarning("Got AuthorityTransfer event, but it didn't have " +
                "any relation to local player ID " + network.localPlayerId + ". " +
                "Object ID was " + networkId + ". Original authority was " + 
                originalAuthorityId + "; new authority is " + newAuthorityId);
            }
          }
        }
      }
    }
    
  }

}