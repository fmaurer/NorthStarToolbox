﻿using System;
using System.Runtime;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Reflection;
using Leap.Unity.Networking.Events;

namespace Leap.Unity.Networking {

  /// <summary>
  /// Marks ILeapNetEvent structs as spawnable by providing a method for setting
  /// the struct's network ID.
  /// (If you implement ILeapNetSpawnable, you automatically also implement
  /// ILeapNetEvent.)
  ///
  /// Not all ILeapNetEvents represent synchronizable, spawnable objects. Those
  /// that do, however, can have their spawns and despawns handled by the
  /// LeapNet Spawn Manager.
  /// <summary>
  public interface ILeapNetSpawnable : ILeapNetEvent {
    void SetNetworkId(int assignedNetworkId);
  }

  /// <summary>
  /// The data we'd like to store per-object for the spawn system is just the
  /// latest sync event data that was sent to sync the state of a given
  /// LeapNetObject. This allows the spawn system to notify just-joined players
  /// of objects they need to spawn to get up-to-date with the networked session.
  ///
  /// NOTE: NOT YET USED. Because only SpawnSystem requires data about the 
  /// latest sync state for spawned objects, it isn't necessarily required that
  /// the data live in the LeapNetObjectDatabase (DatabaseSystem), which is
  /// intended to store _cross-system_ data for the network session. Currently,
  /// this data is stored inside the SpawnSystem in
  /// _server_spawnIdsToLatestStates.
  /// (As a result, struct might be removed, but see 
  /// LeapNetObjectAuthorityData for a practical example of LeapNetObjectData,
  /// which is used both by the SpawnSystem to set authority when objects are
  /// spawned and AuthoritySystem to handle authority requests.)
  /// </summary>
  public struct LeapNetObjectSpawnData : LeapNetObjectData {
    public GenericNetworkEvent latestSyncState;
  }

  [AttributeUsage(AttributeTargets.Method)]
  /// <summary>
  /// Marks the static method as the spawn handler for the specified spawn
  /// request event.
  /// When a spawn request of the argument type is received, the spawn manager
  /// will invoke this method and pass the spawn request event as well as
  /// whether the local machine should have authority over the spawned object.
  ///
  ///
  /// Spawn handlers should call NotifyNetworkSpawned on the spawned object
  /// in order to notify the object of its network ID. Then, the spawn handler
  /// should return the spawned object.
  /// </summary>
  public class SpawnHandlerAttribute : Attribute {
    public Type objectStateEventType;

    /// <summary>
    /// Marks a static method as the spawn handler for objects whose states are
    /// defined by the argument type.
    ///
    /// The type argument should be the ILeapNetEvent type that synchronizes the
    /// states of the spawned objects, and not the spawned object type itself.
    ///
    /// spawnRequestId will be non-negative and non-zero on the local machine
    /// that called RequestSpawn and received a corresponding HandleSpawn.
    /// The spawnRequestId will match the ID returned by RequestSpawn.
    ///
    /// Spawn handlers should call NotifyNetworkSpawned on the spawned object
    /// in order to notify the object of its network ID. Then, the spawn handler
    /// should return the spawned object.
    /// </summary>
    public SpawnHandlerAttribute(Type objectStateEventType) {
      this.objectStateEventType = objectStateEventType;
    }
  }

  /// <summary>
  /// Marks the static method as the despawn handler for the specified spawn
  /// request event.
  /// When a spawn request of the argument type is received, the spawn manager
  /// will invoke this method and pass the object to despawn.
  /// </summary>
  public class DespawnHandlerAttribute : Attribute {
    public Type objectStateEventType;

    /// <summary>
    /// Marks a static method as the despawn handler for objects whose states
    /// are defined by the argument type.
    ///
    /// As for SpawnHandlerAttribute, the argument type should not be the type
    /// of the object to be spawned. Rather, it should be the ILeapNetEvent type
    /// that synchronizes the states of the spawned objects. This type is used
    /// to initially spawn the object, and to match objects spawned from a
    /// given spawn handler with a corresponding despawn handler when the object
    /// is to be despawned.
    /// </summary> 
    public DespawnHandlerAttribute(Type objectStateEventType) {
      this.objectStateEventType = objectStateEventType;
    }  
  }

  public class SpawnSystem {

    /// <summary>
    /// Server-mode only. If we don't see any sync events from a spawned object
    /// for this duration of time in seconds, the server will assume the object
    /// is dead and send despawn events for it.
    /// </summary>
    public const float MAX_SPAWN_HEARTBEAT_INTERVAL = 2f;

    /// <summary>
    /// Messages to spawn and despawn objects should be sent "reliably."
    /// </summary>
    public const LiteNetLib.DeliveryMethod SPAWN_DELIVERY_METHOD =
      LiteNetLib.DeliveryMethod.ReliableUnordered;

    public LeapNetManager network;

    public SpawnSystem(LeapNetManager network) {
      this.network = network;
    }

    #region Static

    private static HashSet<Type> s_spawnableTypes = new HashSet<Type>();
    private static Dictionary<Type, MethodInfo> s_typesToSpawnHandlersMap =
      new Dictionary<Type, MethodInfo>();
    private static Dictionary<Type, MethodInfo> s_typesToDespawnHandlersMap =
      new Dictionary<Type, MethodInfo>();
    private static Dictionary<Type, Type> s_typesToSpawnRequestTypesMap =
      new Dictionary<Type, Type>();
    private static Dictionary<Type, Type> s_typesToDespawnRequestTypesMap =
      new Dictionary<Type, Type>();

    // Scan the assembly for spawn and despawn handlers.
    static SpawnSystem() {
      // Scan the assembly for all classes with decorated spawn handlers.
      var assembly = Assembly.GetExecutingAssembly();
      var types = assembly.GetTypes();
      foreach (var type in types) {
        MethodInfo[] staticMethods = type.GetMethods(BindingFlags.Public |
          BindingFlags.Static);
        foreach (var method in staticMethods) {
          SpawnHandlerAttribute spawnHandlerAttr =
            method.GetCustomAttribute<SpawnHandlerAttribute>();
          if (spawnHandlerAttr != null) {
            s_typesToSpawnHandlersMap[spawnHandlerAttr.objectStateEventType] =
              method;
          }
          else {
            DespawnHandlerAttribute despawnHandlerAttr =
              method.GetCustomAttribute<DespawnHandlerAttribute>();
            if (despawnHandlerAttr != null) {
              s_typesToDespawnHandlersMap[despawnHandlerAttr.objectStateEventType] =
                method;
            }
          }
        }
      }

      // Validate that we have a spawner and despawner for each spawnable
      // type. Here we also build the set of all spawnable types that have
      // been validated.
      var combinedTypeSet = new HashSet<Type>();
      foreach (var typeAndSpawnerPair in s_typesToSpawnHandlersMap) {
        combinedTypeSet.Add(typeAndSpawnerPair.Key);
      }
      foreach (var typeAndDespawnerPair in s_typesToDespawnHandlersMap) {
        combinedTypeSet.Add(typeAndDespawnerPair.Key);
      }
      foreach (var spawnType in combinedTypeSet) {
        MethodInfo spawner;
        s_typesToSpawnHandlersMap.TryGetValue(spawnType, out spawner);
        MethodInfo despawner;
        s_typesToDespawnHandlersMap.TryGetValue(spawnType, out despawner);
        if (!(spawnType).ImplementsInterface(typeof(ILeapNetSpawnable)) ||
            (spawner == null && despawner == null)) {
          Debug.LogError("Error preparing type " + spawnType + " for " +
            "spawning: No spawn handler nor despawn handler found. " +
            "Use the SpawnHandler and DespawnHandler attributes to mark " +
            "ILeapNetObject spawn and despawn events, and provide an " +
            "ILeapNetSpawnable type to use to synchronize data for the spawned " +
            "object.");
        }
        else if (spawner == null && despawner != null) {
          Debug.LogError("Error preparing type " + spawnType + " for " +
            "spawning: No spawn handler found. Despawn handler found was: " +
            despawner.Name + ". Mark spawn handlers with a " +
            "SpawnHandlerAttribute.");
        }
        else if (spawner != null && despawner == null) {
          Debug.LogError("Error preparing type " + spawnType + " for " +
            "spawning: No despawn handler found. Spawn handler found was: " +
            spawner.Name + ". Mark despawn handlers with a " +
            "DespawnHandlerAttribute.");
        }
        else { // spawner != null && despawner != null
          s_spawnableTypes.Add(spawnType);
        }
      }

      // For every spawnable event type we found, we need to cache type hints
      // for the spawn & despawn generic events that correspond to those types.
      foreach (var spawnableType in s_spawnableTypes) {
        var spawnManagerType = typeof(SpawnSystem);
        var genericSpawnRequestType =
          spawnManagerType.GetNestedType("SpawnRequestEvent`1",
            BindingFlags.Public);
        var spawnRequestOfSpawnableType =
          genericSpawnRequestType.MakeGenericType(spawnableType);
        if (!LeapNetEvents.RegisterNetEventType(spawnRequestOfSpawnableType)) {
          Debug.LogError("Unsuccessfully tried to cache spawn event type: " +
            spawnRequestOfSpawnableType);
        }
        else {
          // Debug.Log("Cached type hint for type: " + spawnRequestOfSpawnableType);
          // Debug.Log(LeapNetEvents.GetTypeHint(spawnRequestOfSpawnableType));
          s_typesToSpawnRequestTypesMap[spawnableType] =
            spawnRequestOfSpawnableType;
        }
        var genericDespawnRequestType =
          spawnManagerType.GetNestedType("DespawnRequestEvent`1",
            BindingFlags.Public);
        var despawnRequestOfSpawnableType =
          genericDespawnRequestType.MakeGenericType(spawnableType);
        if (!LeapNetEvents.RegisterNetEventType(despawnRequestOfSpawnableType)) {
          Debug.LogError("Unsuccessfully tried to cache despawn event type: " + 
            despawnRequestOfSpawnableType);
        }
        else {
          // Debug.Log("Cached type hint for type: " + despawnRequestOfSpawnableType);
          // Debug.Log(LeapNetEvents.GetTypeHint(despawnRequestOfSpawnableType));
          s_typesToDespawnRequestTypesMap[spawnableType] =
            despawnRequestOfSpawnableType;
        }
      }
    }

    #endregion

    #region Internal Types

    /// <summary>
    /// Generic struct that wraps information about the object to spawn (a normal
    /// ILeapNetEvent) with a spawn request ID.
    ///
    /// Two SpawnRequestEvents for a given type are considered equal if they
    /// have the same requestId and requestingClientPlayerId, even if the sync
    /// event contents are different. (TODO: Does this cause any problems?)
    /// </summary>
    public struct SpawnRequestEvent<T> : ILeapNetEvent,
                                         IEquatable<SpawnRequestEvent<T>>
                                         where T : ILeapNetSpawnable {
      public int targetNetworkId;
      /// <summary>
      /// The network ID the message is intended for. Often this is going to be
      /// NO_NETWORK_ID (0, or "the server", which causes a broadcast to all 
      /// connected players, but sometimes it's a specific player, e.g. if they
      /// just joined and need to be updated with spawned objects.
      /// </summary>
      public int GetNetworkId() { return targetNetworkId; }

      public int requestingClientPlayerId;
      public int requestId;
      public bool isPlayerSpawnRequest;
      public bool isSingleOwnershipRequest;

      public T objectSyncEvent;

      public bool Equals(SpawnRequestEvent<T> other) {
        return other.requestId == this.requestId
          && other.requestingClientPlayerId == this.requestingClientPlayerId;
      }

      /// <summary>
      /// Spawn requests are identified by their request ID and the ID of the
      /// player who requested the spawn. Their hash codes are, accordingly:
      /// requestId + requestingClientPlayerId * MAX_NUM_OBJECTS.
      /// </summary>
      public override int GetHashCode() {
        return requestId + requestingClientPlayerId *
          LeapNetManager.MAX_NUM_OBJECTS;
      }
    }

    /// <summary>
    /// Struct that generically holds the type of object to despawn and the
    /// network ID of that object.
    /// </summary>
    public struct DespawnRequestEvent<T> : ILeapNetEvent
      where T : ILeapNetSpawnable
    {
      public int networkIdToDespawn;
      public int GetNetworkId() { return networkIdToDespawn; }

      public int requestingPlayerId;
    }

    /// <summary>
    /// Struct that signals the server is about to spawn pre-existing objects
    /// </summary>
    public struct InitialServerStateSyncEvent : ILeapNetEvent {
      public int GetNetworkId() { return 0; }
      public int numPrexistingObjects;
    }

    #endregion

    #region State

    // TODO: DELETEME -- older inspector stuff from the MonoBehaviour days
    // /// <summary>
    // /// Gets whether the network has a local player ID. Without one, the spawn
    // /// manager cannot spawn anything.
    // /// </summary>
    // public bool isNetworkActive {
    //   get { return network != null && network.hasLocalPlayerId; }
    // }
    // public NetworkMode networkMode {
    //   get {
    //     if (network == null) {
    //       throw new System.Exception("Cannot access spawn manager network mode " +
    //         "without an attached network. (The network field is null.)");
    //     }
    //     else {
    //       return network.networkMode;
    //     }
    //   }
    // }

    private Dictionary<int, LeapNetObject> _client_spawnIdsToObjectsMap =
      new Dictionary<int, LeapNetObject>();
    /// <summary>
    /// Despawn request event handlers receive objects enumerated from this
    /// buffer so that they can remove objects from the primary map,
    /// _client_spawnedIdsToObjectsMap, without erroring due to modifying the
    /// collection while it is being enumerated.
    /// </summary>
    private Dictionary<int, LeapNetObject> _client_spawnedIdsToObjectsMapBuffer =
      new Dictionary<int, LeapNetObject>();

    /// <summary> This map is used in both client and server mode. </summary>
    private Dictionary<int, Type> _spawnIdsToSpawnableTypesMap =
      new Dictionary<int, Type>();
    /// <summary>
    /// Any time LeapNetManager.RegisterEventListener is called,
    /// this flag is set to true. OnDisable uses this flag to check whether it
    /// needed to unregister any event listeners. If this flag is set and
    /// OnDisable isn't able to unregister any events (for example, because the
    /// spawn manager doesn't know the local player ID), this indicates a bug.
    /// </summary>
    private bool _wereAnyEventsRegistered = false;
      
    /// <summary>
    /// Maps request hash codes to data associated with the pending request.
    /// Currently, the only associated data is a spawn-callback event that is
    /// not used internally, but provided as a convenience to consumers of the
    /// LeapNetSpawnManager API. This value can be null, indicating no callback
    /// is necessary.
    /// </summary>
    private Dictionary<int, Action<int>> _pendingRequests =
      new Dictionary<int, Action<int>>();

    private int _maxRequestId = 1;

    private HashSet<int> _server_spawnIDs = new HashSet<int>();
    private Dictionary<int, GenericNetworkEvent>
      _server_spawnIdsToLatestStates =
      new Dictionary<int, GenericNetworkEvent>();
    private Dictionary<int, float> _server_spawnIdsToHeartbeatTimers = 
      new Dictionary<int, float>();

    private ILeapNetObjectDatabase _objectDb {
      get { return network as ILeapNetObjectDatabase; }
    }

    #endregion

    #region Lifecycle Events

    public void OnEnable() {
      // If we're in server mode, we need to notify all incoming players of
      // objects that have spawned.
      if (network.networkMode == NetworkMode.Server) {
        network.OnPlayerJoined -= server_handlePlayerJoined;
        network.OnPlayerJoined += server_handlePlayerJoined;
        // Debug.Log("[Server] LeapNetSpawnManager subscribed to OnPlayerJoined.");

        foreach (Type type in s_spawnableTypes) {
          var spawnRequestType = s_typesToSpawnRequestTypesMap[type];
          dynamic eventTypeHint = LeapNetEvents.GetTypeHint(spawnRequestType);
          network.RegisterEventListener(0, this, eventTypeHint);
          _wereAnyEventsRegistered = true;
        }
      }
      else { // NetworkMode.Client
        // On the client side, we subscribe to events only when we have a local
        // player ID.
        if (network.hasLocalPlayerId) {
          client_registerSpawnableEventListeners();
        }
        else {
          network.OnReceiveLocalPlayerId -= client_registerSpawnableEventListeners;
          network.OnReceiveLocalPlayerId += client_registerSpawnableEventListeners;
        }
      }
    }

    public void OnDisable() {
      if (_wereAnyEventsRegistered) {
        if (network.networkMode == NetworkMode.Server) {
          // Unsubscribe to SpawnRequestEvent<T> for each T in the spawnable types.
          foreach (Type type in s_spawnableTypes) {
            var spawnRequestType = s_typesToSpawnRequestTypesMap[type];
            dynamic eventTypeHint = LeapNetEvents.GetTypeHint(spawnRequestType);
            network.UnregisterEventListener(0, this, eventTypeHint);
          }
        }
        else { // NetworkMode.Client
          client_unregisterSpawnableEventListeners();
        }
      }

      // Despawn all objects known to this client.
      _client_spawnedIdsToObjectsMapBuffer.Clear();
      foreach (var idObjectPair in _client_spawnIdsToObjectsMap) {
        _client_spawnedIdsToObjectsMapBuffer[idObjectPair.Key] =
          idObjectPair.Value;
      }
      foreach (var idObjectPair in _client_spawnedIdsToObjectsMapBuffer) {
        var spawnId = idObjectPair.Key;
        var spawnedObject = idObjectPair.Value;
        // If the spawned object is null, we're likely shutting down the scene
        // and the object has already been destroyed. Otherwise, we process a
        // despawn request event to take the object through its normal despawn
        // lifecycle event.
        if (spawnedObject != null) {
          var spawnType = _spawnIdsToSpawnableTypesMap[spawnId];
          dynamic typeHint = LeapNetEvents.GetTypeHint(spawnType);
          var despawnRequest = createDespawnRequestEvent(spawnId,
            typeHint: typeHint);
          onDespawnRequestEvent(despawnRequest);
        }
      }
    }

    private void client_registerSpawnableEventListeners() {
      if (!network.hasLocalPlayerId) {
        Debug.LogError("Can't register spawnable event listeners without a " +
          "local player ID.", this.network);
      }
      else {
        _lastKnownLocalPlayerId = network.localPlayerId;
        foreach (Type type in s_spawnableTypes) {
          var spawnRequestType = s_typesToSpawnRequestTypesMap[type];
          dynamic eventTypeHint = LeapNetEvents.GetTypeHint(spawnRequestType);
          network.RegisterEventListener(network.localPlayerId, this,
            eventTypeHint);
          _wereAnyEventsRegistered = true;
          // Debug.Log("[" + network.networkMode + "] Registering event listener, " +
          //   "targetId: " + network.localPlayerId + ", type: " + this.GetType() +
          //   ", eventType(hint): " + eventTypeHint);
        }
      }
    }

    private int _lastKnownLocalPlayerId = LeapNetManager.NO_NETWORK_ID;
    private void client_unregisterSpawnableEventListeners() {
      if (_lastKnownLocalPlayerId == LeapNetManager.NO_NETWORK_ID) {
        network.LogWarning("Unable to unregister spawnable event listeners " +
          "because there was no last known local player ID.");
      }
      else {
        // Unsubscribe to SpawnRequestEvent<T> for each T in the spawnable types.
        foreach (Type type in s_spawnableTypes) {
          var spawnRequestType = s_typesToSpawnRequestTypesMap[type];
          dynamic eventTypeHint = LeapNetEvents.GetTypeHint(spawnRequestType);
          network.UnregisterEventListener(_lastKnownLocalPlayerId, this,
            eventTypeHint);
        }
      }
    }

    private void server_handlePlayerJoined(int joinedPlayerId) {
      network.Log("Got handlePlayerJoined");
      //Debug.Log("_server_spawnIDs count is " + _server_spawnIDs.Count);
      var serverSync = new InitialServerStateSyncEvent() {
        numPrexistingObjects = _server_spawnIDs.Count
      };
      network.EnqueueEvent(serverSync, SPAWN_DELIVERY_METHOD);
      foreach (var spawnedId in _server_spawnIDs) {
        var spawnableType = _spawnIdsToSpawnableTypesMap[spawnedId];
        ensureLatestStateExists(spawnedId);
        var latestSyncEvent = _server_spawnIdsToLatestStates[spawnedId];

        int latestAuthority;
        var latestAuthorityData = default(LeapNetObjectAuthorityData);
        if (!_objectDb.TryGet(spawnedId, out latestAuthorityData)) {
          network.LogCritical("Didn't have any latest authority data for " +
            "known-spawned object ID " + spawnedId + ", of type " + 
            spawnableType);
        }
        else  {
          latestAuthority = latestAuthorityData.playerWithAuthority;

          if (!latestSyncEvent.isValid) {
            network.LogCritical("Didn't have any latest state for known-spawned " +
              "object id " + spawnedId + ", of type " + spawnableType);
          }
          else if (latestAuthority == LeapNetManager.NO_NETWORK_ID) {
            network.LogCritical("Didn't have any latest authority for known-spawned " +
              "object id " + spawnedId + ", of type " + spawnableType);
          }
          else {
            var requestId = _maxRequestId++;
            dynamic syncEventTypeHint = LeapNetEvents.GetTypeHint(spawnableType);
            dynamic syncEvent = latestSyncEvent.ToEvent(syncEventTypeHint);
            dynamic spawnRequestEvent = createSpawnRequestEvent(
              joinedPlayerId,
              requestId,
              syncEvent,
              overrideRequestingPlayerId: latestAuthority
            );
            network.EnqueueEvent(spawnRequestEvent, SPAWN_DELIVERY_METHOD);
            network.Log("Enqueued spawn request event for type " + spawnableType +
              " because player " + joinedPlayerId + " joined. " +
              "requestId is " + spawnRequestEvent.requestId);
          }
        }
      }
    }

    private SpawnRequestEvent<T> createSpawnRequestEvent<T>(
      int targetId, int requestId, T syncEvent, bool isPlayerSpawn = false,
      bool isSingleOwnership = false, int? overrideRequestingPlayerId = null)
      where T: struct, ILeapNetSpawnable
    {
      var requestingPlayerId = network.localPlayerId;
      if (overrideRequestingPlayerId.HasValue &&
          network.networkMode == NetworkMode.Client) {
        network.LogCritical("Client mode spawn manager is not allowed to spoof " +
          "requesting-client player IDs for spawn requests.");
        throw new System.Exception();
      }
      else {
        if (overrideRequestingPlayerId.HasValue) {
          requestingPlayerId = overrideRequestingPlayerId.Value;
        }
        network.Log("Creating spawn request, request ID " + requestId + " and " +
          "requestingPlayerId " + requestingPlayerId);
        return new SpawnRequestEvent<T>() {
          targetNetworkId = targetId,
          requestingClientPlayerId = requestingPlayerId,
          requestId = requestId,
          objectSyncEvent = syncEvent,
          isPlayerSpawnRequest = isPlayerSpawn,
          isSingleOwnershipRequest = isSingleOwnership
        };
      }
    }

    private DespawnRequestEvent<T> createDespawnRequestEvent<T>(
      int objectToDespawnId, int? overrideRequestingPlayerId = null,
      LeapNetEvents.TypeHint<T> typeHint = null)
      where T: struct, ILeapNetSpawnable
    {
      var requestingPlayerId = network.localPlayerId;
      if (overrideRequestingPlayerId.HasValue &&
          network.networkMode == NetworkMode.Client) {
        network.LogCritical("Client spawn manager is not allowed to spoof " +
          "requesting-player IDs for despawn requests.");
        throw new System.Exception();
      }
      else {
        if (overrideRequestingPlayerId.HasValue) {
          requestingPlayerId = overrideRequestingPlayerId.Value;
        }
        network.Log("Creating spawn request to despawn ID " + objectToDespawnId +
          " with requestingPlayerId " + requestingPlayerId);
        return new DespawnRequestEvent<T>() {
          networkIdToDespawn = objectToDespawnId,
          requestingPlayerId = requestingPlayerId
        };
      }
    }

    private List<int> _idsToReassign = new List<int>(16);

    public void Update() {
      if (network.networkMode == NetworkMode.Server) {
        using (new ProfilerSample("[Server] Iterate spawnIDs", network)) {
          _idsToReassign.Clear();
          foreach (var spawnId in _server_spawnIDs) {
            var spawnableType = _spawnIdsToSpawnableTypesMap[spawnId];
            // For sync events, we only store the latest sync event so new players
            // can be notified of the latest world state when they join.
            // (Each type of object is expected to handle its own state
            // synchronization by its own sync event registration.)
            dynamic syncEventTypeHint = LeapNetEvents.GetTypeHint(spawnableType);
            bool wasSyncDequeued;
            dynamic syncEvent = network.SpecialDequeueEventWithGenerics(
              spawnId, this, syncEventTypeHint, out wasSyncDequeued);
            if (wasSyncDequeued) {
              server_onSyncEvent(syncEvent);
            }

            // Update object heartbeat timers. These timers are reset whenever
            // the server sees a sync event for a spawned object. If we don't
            // get any heartbeats (sync events) from a spawned object after
            // MAX_SPAWN_HEARTBEAT_INTERVAL, we'll despawn that object.
            float heartbeatTimer;
            if (!_server_spawnIdsToHeartbeatTimers.TryGetValue(spawnId,
                out heartbeatTimer)) {
              _server_spawnIdsToHeartbeatTimers[spawnId] = 0f;
            }
            else {
              heartbeatTimer += Time.deltaTime;
              if (heartbeatTimer > MAX_SPAWN_HEARTBEAT_INTERVAL) {
                // Call time-of-death -- reassign the object ID unless the
                // object is designated single-ownership only.
                network.Log("Reassigning authority for object ID " + spawnId + 
                  " because we didn't get a heartbeat for " + 
                  MAX_SPAWN_HEARTBEAT_INTERVAL + " seconds.");
                
                _idsToReassign.Add(spawnId);
              }
              else {
                _server_spawnIdsToHeartbeatTimers[spawnId] = heartbeatTimer;
              }
            }
          }
          foreach (var idToReassign in _idsToReassign) {
            var type = _spawnIdsToSpawnableTypesMap[idToReassign];
            _server_spawnIdsToHeartbeatTimers[idToReassign] = 0f;
            // Reassign the object's authority unless it is a player avatar or
            // marked single-ownership, in which case despawn it.
            LeapNetObjectAuthorityData authorityData;
            if ((network as ILeapNetObjectDatabase).TryGet(idToReassign,
              out authorityData)) 
            {
              if (idToReassign == authorityData.playerWithAuthority) {
                // The ID is a player ID, so despawn the player.
                network.RequestDespawn(idToReassign);
              }
              else if (authorityData.singleOwnership) {
                network.RequestDespawn(idToReassign);
              }
              else {
                // Find another player to give authority to and give it to them.
                foreach (int playerID in network.server_playerIds) {
                  if (playerID != authorityData.playerWithAuthority) {
                    network.RequestAuthority(playerID, idToReassign, null, null);
                    break;
                  }
                }
              }
            }
          }
          _idsToReassign.Clear();
        }

        using (new ProfilerSample("[Server] Check spawn requests", network)) {
          foreach (Type spawnableType in s_spawnableTypes) {
            // For spawn request events, assign the request an ID and respond
            // with another spawn request event, but with the target ID of the
            // spawned object itself. The assigned ID is also copied into the
            // underlying sync object.
            Type spawnRequestType;
            using (new ProfilerSample("Get spawn request type")) {
              spawnRequestType = s_typesToSpawnRequestTypesMap[spawnableType];
            }
            using (new ProfilerSample("Declare dynamic requestTypeHint")) {
              dynamic requestTypeHint;
              using (new ProfilerSample("Set dynamic requestTypeHint")) {
                requestTypeHint = LeapNetEvents.GetTypeHint(spawnRequestType);
              }
              using (new ProfilerSample("Begin try block")) {
                try {
                  bool wasDequeued;
                  // Debug.Log("[" + network.networkMode + "]" + " Checking
                  // network ID: 0, " +
                  //   "listener: + " + this.GetType() +
                  //   ", eventType(hint): " + eventTypeHint.GetType());
                  dynamic spawnEvent = network.SpecialDequeueEventWithGenerics(
                    LeapNetManager.NO_NETWORK_ID, this, requestTypeHint,
                    out wasDequeued);
                  if (wasDequeued) {
                    using (new ProfilerSample("Call onSpawnRequestEvent")) {
                      // network.Log("[" + network.networkMode + "] firing " +
                      //   "onSpawnRequestEvent for spawnEvent type " +
                      //   spawnEvent.GetType());
                      onSpawnRequestEvent(spawnEvent);
                    }
                  }
                }
                catch (System.Exception e) {
                  Debug.LogError("[Server] Caught exception of type " + e.GetType() +
                    ";\n" + e.ToString());
                  Debug.LogError("eventTypeHint was " + requestTypeHint.GetType());
                }
              }
            }
          }
        }
      }
      else { // NetworkMode.Client
        // For each spawnable type, check if a spawn request event has been
        // produced for it.
        using (new ProfilerSample("[Client] Check spawn requests", network)) {
          foreach (Type spawnableType in s_spawnableTypes) {
            var spawnRequestType = s_typesToSpawnRequestTypesMap[spawnableType];
            dynamic requestTypeHint = LeapNetEvents.GetTypeHint(spawnRequestType);
            using (new ProfilerSample("Begin try block")) {
              try {
                if (network.hasLocalPlayerId) {
                  bool wasDequeued;
                  dynamic spawnEvent = network.SpecialDequeueEventWithGenerics(
                    network.localPlayerId, this, requestTypeHint, out wasDequeued);
                  if (wasDequeued) {
                    onSpawnRequestEvent(spawnEvent);
                  }
                }
              }
              catch (System.Exception e) {
                Debug.LogError("[Client] Caught exception of type " + e.GetType() +
                  ";\n" + e.ToString());
                Debug.LogError("eventTypeHint was " + requestTypeHint.GetType());
              }
            }
          }
        }

        // For each currently spawned object, check if a despawn event has been
        // produced for it.
        using (new ProfilerSample("[Client] Check despawn requests", network)) {
          // Use a secondary map to enumerate for despawn events because despawn
          // events will attempt to remove objects from the spawned IDs to
          // objects map.
          _client_spawnedIdsToObjectsMapBuffer.Clear();
          foreach (var idAndSpawnedObjectPair in _client_spawnIdsToObjectsMap) {
            _client_spawnedIdsToObjectsMapBuffer[idAndSpawnedObjectPair.Key] =
              idAndSpawnedObjectPair.Value;
          }
          foreach (var idAndSpawnedObjectPair in _client_spawnedIdsToObjectsMapBuffer) {
            var spawnedObjectId = idAndSpawnedObjectPair.Key;
            var spawnedObject = idAndSpawnedObjectPair.Value;
            var spawnableType = _spawnIdsToSpawnableTypesMap[spawnedObjectId];

            var despawnRequestType = s_typesToDespawnRequestTypesMap[spawnableType];
            dynamic despawnEventTypeHint = LeapNetEvents.GetTypeHint(
              despawnRequestType);
            bool wasDespawnDequeued;
            using (new ProfilerSample("SpecialDequeueEventWithGenerics")) {
              dynamic despawnEvent = network.SpecialDequeueEventWithGenerics(
                spawnedObjectId, this, despawnEventTypeHint, out wasDespawnDequeued);
              using (new ProfilerSample("Fire onDespawn")) {
                if (wasDespawnDequeued) {
                  onDespawnRequestEvent(despawnEvent);
                }
              }
            }
          }
          _client_spawnedIdsToObjectsMapBuffer.Clear();
        }
      }
    }

    private void ensureLatestStateExists(int spawnedObjectId) {
      GenericNetworkEvent genericEvent;
      if (!_server_spawnIdsToLatestStates.TryGetValue(spawnedObjectId,
          out genericEvent)) {
        _server_spawnIdsToLatestStates[spawnedObjectId] =
          GenericNetworkEvent.CreateSingleGenericContainer();
      }
    }

    /// <summary>
    /// Gets the spawn handler associated with this object state event type.
    /// Throws a KeyNotFoundException if no handler exists for the type.
    /// </summary>
    public static MethodInfo GetSpawnHandlerForType(Type objectStateEventType) {
      return s_typesToSpawnHandlersMap[objectStateEventType];
    }

    /// <summary>
    /// Gets the despawn handler associated with this object state event type.
    /// Throws a KeyNotFoundException if no handler exists for the type.
    /// </summary>
    public static MethodInfo GetDespawnHandlerForType(Type objectStateEventType) {
      return s_typesToDespawnHandlersMap[objectStateEventType];
    }

    private void onSpawnRequestEvent<T>(SpawnRequestEvent<T> spawnRequestEvent,
      LeapNetEvents.TypeHint<T> typeHint = null)
      where T : struct, ILeapNetSpawnable
    {
      if (network.networkMode == NetworkMode.Server) {
        network.Log("Got spawn request event.");

        if (spawnRequestEvent.isPlayerSpawnRequest) {
          // No need to wait for a new network ID, it's already the player's
          // ID.
          server_handleSpawnRequestEventWithId(spawnRequestEvent,
            spawnRequestEvent.requestingClientPlayerId);
        }
        else {
          network.RequestNewNetworkId(
            (newNetworkId) => {
              server_handleSpawnRequestEventWithId(spawnRequestEvent,
                newNetworkId);
            },
            () => {
              network.LogCritical("Unable to allocate a new network ID.");
            }
          );
        }
      }
      else { // NetworkMode.Client
        network.Log("Got onSpawnRequestEvent.");
        MethodInfo spawnHandler = GetSpawnHandlerForType(typeof(T));

        var requestId = spawnRequestEvent.requestId;
        var requestHash = spawnRequestEvent.GetHashCode();
        var hasLocalAuthority = false;
        var spawnCallback = (Action<int>)null;
        if (_pendingRequests.TryGetValue(requestHash, out spawnCallback)) {
          hasLocalAuthority = true;

          // Remove the pending request so we don't assume we have local 
          // authority in local test scenarios where we leave and re-join with
          // a new player ID. (In general, requests shouldn't linger.)
          _pendingRequests.Remove(requestHash);
        }

        var objectSyncEvent = spawnRequestEvent.objectSyncEvent;
        var spawnedId = objectSyncEvent.GetNetworkId();
        if (spawnedId == LeapNetManager.NO_NETWORK_ID) {
          network.LogCritical("Client got a spawn event, but the spawned object " +
            "had no network ID.");
        }
        object[] spawnEventArgs = {
          network,
          spawnedId,
          hasLocalAuthority,
          objectSyncEvent,
          requestId
        };
        var spawnedObject = (LeapNetObject)spawnHandler.Invoke(null,
          spawnEventArgs);
        if (spawnedObject == null) {
          Debug.LogError("Failed to spawn object with state event " + typeof(T));
        }
        else {
          _client_spawnIdsToObjectsMap[spawnedId] = spawnedObject;
          _spawnIdsToSpawnableTypesMap[spawnedId] = typeof(T);

          // When we spawn an object, we need to register a listener for its
          // despawn. This listener will be unregistered when the object
          // is actually despawned.
          network.RegisterEventListener<DespawnRequestEvent<T>>(spawnedId, this);
          _wereAnyEventsRegistered = true;
          network.Log("Registered despawn event listener for spawned id " +
            spawnedId);
          
          // Finally, if we have a non-null user callback associated with this
          // spawn request, call it now.
          if (spawnCallback != null) {
            spawnCallback(spawnedId);
          }
        }
      }
    }

    private void server_handleSpawnRequestEventWithId<T>(SpawnRequestEvent<T> spawnRequest,
      int idToAssign)
      where T : struct, ILeapNetSpawnable
    {
      var syncEvent = spawnRequest.objectSyncEvent;
      var requestingPlayerId = spawnRequest.requestingClientPlayerId;
      var requestId = spawnRequest.requestId; // Only unique per-player.
      var isPlayerSpawnRequest = spawnRequest.isPlayerSpawnRequest;
      if (isPlayerSpawnRequest) {
        if (_server_spawnIDs.Contains(requestingPlayerId)) {
          network.LogCritical("Player ID " + requestingPlayerId +
            " is already spawned!");
          return;
        }
        if (requestingPlayerId != idToAssign) {
          network.LogCritical("A player spawn request must have identical player " +
            "and assignment IDs.");
          return;
        }
        else {
          // We can assume requestingPlayerId == idToAssign.
        }
      }

      _server_spawnIDs.Add(idToAssign);
      _spawnIdsToSpawnableTypesMap[idToAssign] = syncEvent.GetType();
      _objectDb.Set(idToAssign, new LeapNetObjectAuthorityData() {
        playerWithAuthority = requestingPlayerId,
        singleOwnership = spawnRequest.isSingleOwnershipRequest
      });

      syncEvent.SetNetworkId(idToAssign);
      foreach (var notifiedPlayerId in network.server_playerIds) {
        spawnRequest.targetNetworkId = notifiedPlayerId;
        spawnRequest.objectSyncEvent = syncEvent;

        // For players that didn't initiate the spawn request, zero out
        // the request ID.
        if (notifiedPlayerId != requestingPlayerId) {
          spawnRequest.requestId = 0;
        }
        else {
          spawnRequest.requestId = requestId;
        }

        network.EnqueueEvent(spawnRequest, SPAWN_DELIVERY_METHOD);
      }
      if (isPlayerSpawnRequest) {
        network.Log("Sent spawn request for a player with network ID: " +
          requestingPlayerId);
      }
      else {
        network.Log("Allocated a network ID: " + idToAssign);
      }

      // We also want to subscribe to the underlying sync events for this
      // object so we can always store the latest sync event.
      network.RegisterEventListener<T>(idToAssign, this);
      _wereAnyEventsRegistered = true;
    }

    private void onDespawnRequestEvent<T>(
      DespawnRequestEvent<T> despawnRequestEvent
    )
      where T : struct, ILeapNetSpawnable
    {
      if (network.networkMode == NetworkMode.Server) {
        var despawnObjectId = despawnRequestEvent.GetNetworkId();
        var idRequestingDespawn = despawnRequestEvent.requestingPlayerId;

        if (idRequestingDespawn == LeapNetManager.NO_NETWORK_ID) {
          network.Log("Got despawn request for ID " + despawnObjectId +
            " in server mode (likely due to heartbeat); despawning.");
          
          // Server should enqueue a despawn request event with the despawn ID
          // to send to all players. It should also immediately forget about
          // the object.
          //
          // It's possible the server will then receive a sync event for this
          // very object from the authority player immediately afterwards,
          // because the player thinks it still exists. In this case the server
          // should ignore the sync event and send that player back a direct
          // despawn request (just in case). See server_onSyncEvent.
          // 
          // The general pattern: If the server gets data for an object that
          // it thinks should exist because it hasn't allocated a network ID
          // for it, then the server should request that object despawn from
          // the client.
          var despawnRequest = createDespawnRequestEvent<T>(
            despawnObjectId);
          network.EnqueueEvent<DespawnRequestEvent<T>>(despawnRequest,
            SPAWN_DELIVERY_METHOD);

          // Forget about the object.
          _spawnIdsToSpawnableTypesMap.Remove(despawnObjectId);
          _server_spawnIDs.Remove(despawnObjectId);
          _server_spawnIdsToHeartbeatTimers.Remove(despawnObjectId);
          _server_spawnIdsToLatestStates.Remove(despawnObjectId);
          _objectDb.Remove<LeapNetObjectAuthorityData>(despawnObjectId);
        }
        else {
          int authorityId;
          LeapNetObjectAuthorityData authorityData;
          if (!_objectDb.TryGet(despawnObjectId, out authorityData)) {
            network.LogCritical("Got despawn request for unknown object ID: " +
              despawnObjectId + " (No authority data found for that ID.)");
          }
          else {
            authorityId = authorityData.playerWithAuthority;
            if (idRequestingDespawn == authorityId) {
              network.Log("Got despawn request for ID " + despawnObjectId +
                "from authority ID " + authorityId + "; despawning.");

              var despawnRequest = createDespawnRequestEvent<T>(
                despawnObjectId);
              network.EnqueueEvent<DespawnRequestEvent<T>>(despawnRequest,
                SPAWN_DELIVERY_METHOD);

              // Forget about the object.
              _spawnIdsToSpawnableTypesMap.Remove(despawnObjectId);
              _server_spawnIDs.Remove(despawnObjectId);
              _server_spawnIdsToHeartbeatTimers.Remove(despawnObjectId);
              _server_spawnIdsToLatestStates.Remove(despawnObjectId);
              _objectDb.Remove<LeapNetObjectAuthorityData>(despawnObjectId);
            }
            else {
              network.LogWarning("ID " + idRequestingDespawn + " requested " +
                "to despawn object ID " + despawnObjectId + " but that ID does " +
                "not have authority over that object. (Ignoring despawn request.)");
            }
          }
        }
      }
      else { // NetworkMode.Client
        var despawnObjectId = despawnRequestEvent.GetNetworkId();

        LeapNetObject objectToDespawn;
        if (_client_spawnIdsToObjectsMap.TryGetValue(despawnObjectId,
            out objectToDespawn)) {
          MethodInfo despawnHandler = GetDespawnHandlerForType(typeof(T));
          if (despawnHandler != null) {
            network.Log("Despawning object: " + objectToDespawn.name +
              "; My local player ID is " + network.localPlayerId);
            object[] despawnHandlerArgs = { objectToDespawn };
            despawnHandler.Invoke(null, despawnHandlerArgs);
            network.UnregisterEventListener<DespawnRequestEvent<T>>(
              despawnObjectId, this);
          }
          else {
            network.LogCritical("No despawn handler for type " + typeof(T));
          }
          
          // Finally, this client should forget about the object.
          _spawnIdsToSpawnableTypesMap.Remove(despawnObjectId);
          _client_spawnIdsToObjectsMap.Remove(despawnObjectId);
        }
        else {
          network.Log("Ignoring despawn request for unknown object ID " +
            objectToDespawn);
        }
      }
    }

    private void server_onSyncEvent<T>(T syncEvent)
      where T: struct, ILeapNetSpawnable
    {
      var spawnId = syncEvent.GetNetworkId();

      if (!_server_spawnIDs.Contains(spawnId)) {
        // This object shouldn't exist, either because it wasn't approved by the
        // server via a spawn request, or potentially because it has since been
        // despawned, either by the server itself or by the client with
        // authority over the object.
        //
        // When this happens, the server sends out a despawn request event (to
        // all players, in case others have bad state as well), in the interest
        // of keeping all network session state in sync.
        //
        // (Any players who didn't know about the object in the first place will
        // be able to safely ignore the despawn request.)
        var despawnRequest = createDespawnRequestEvent<T>(spawnId);
        network.EnqueueEvent(despawnRequest, SPAWN_DELIVERY_METHOD);
      }
      else {
        // Remember the latest state for this object so we can inform any
        // newly-joining players of its existence.
        ensureLatestStateExists(spawnId);
        var latestState = _server_spawnIdsToLatestStates[spawnId];
        latestState.CopyFrom(syncEvent);
        _server_spawnIdsToLatestStates[spawnId] = latestState;

        // Also refresh the heartbeat timer for this object, since we got a sync
        // for it.
        _server_spawnIdsToHeartbeatTimers[spawnId] = 0f;
      }
    }

    #endregion

    #region Public API

    /// <summary>
    /// This method can only be called when the spawn manager is in client mode.
    /// 
    /// Returns the spawned object associated with the network ID, if it is
    /// tracked by this spawn manager. If no such object is found, returns null.
    /// </summary>
    public LeapNetObject GetObjectFromId(int networkId) {
      if (network.networkMode == NetworkMode.Server) {
        network.LogWarning("The spawn manager can't call GetObjectFromId " +
          "in Server mode because only Client-side spawn managers track " +
          "actual spawned-object instances.");
        return null;
      }
      else { // NetworkMode.Client
        LeapNetObject foundObject = null;
        _client_spawnIdsToObjectsMap.TryGetValue(networkId, out foundObject);
        return foundObject;
      }
    }

    /// <summary>
    /// Returns the type associated with the network ID, if it is
    /// tracked by this spawn manager. If no such type is found, returns null.
    /// </summary>
    public Type GetTypeFromId(int networkId) {
      Type foundObject = null;
      _spawnIdsToSpawnableTypesMap.TryGetValue(networkId, out foundObject);
      return foundObject;
    }

    /// <summary>
    /// Requests a network ID from the server and spawns an object using the
    /// spawn handler associated with the argument object state event.
    /// Spawn handlers are static methods with a SpawnHandler attribute.
    /// You must also define a despawn handler with a DespawnHandler attribute
    /// that matches the object state event type provided to the spawn handler.
    ///
    /// Optionally, you can pass onSpawned and onDespawned callbacks.
    /// These aren't always necessary to use, since HandleSpawn and
    /// HandleDespawn for any given spawnable object is also handed by user
    /// code, but they are offered here as a convenience.
    ///
    /// Additionally, RequestSpawn returns a unique requestId used to identify
    /// this request. This requestId is passed to the HandleSpawn call on the
    /// local machine that initiated the spawn, if it exists. Note that in some
    /// cases HandleSpawn has no corresponding RequestSpawn, and thus no valid
    /// requestId.
    /// </summary>
    public int RequestSpawn<T>(T objectStateEvent,
      Action<int> onIdSpawned = null, bool isPlayerSpawn = false,
      bool isSingleOwnership = false)
      where T : struct, ILeapNetSpawnable
    {
      if (!network.hasLocalPlayerId) {
        Debug.LogError("Can't spawn objects if network has no local player ID.");
        return -1;
      }
      else {
        if (objectStateEvent.GetNetworkId() == LeapNetManager.NO_NETWORK_ID) {
          var spawnRequestEvent = createSpawnRequestEvent(
            targetId: LeapNetManager.NO_NETWORK_ID,
            requestId: _maxRequestId++,
            syncEvent: objectStateEvent,
            isPlayerSpawn: isPlayerSpawn,
            isSingleOwnership: isSingleOwnership
          );
          // Debug.Log("Adding pending request hash code: " +
          //   spawnRequestEvent.GetHashCode());
          _pendingRequests[spawnRequestEvent.GetHashCode()] = onIdSpawned;
          network.EnqueueEvent(spawnRequestEvent, SPAWN_DELIVERY_METHOD);
          return spawnRequestEvent.requestId;
          // Debug.Log("requestId: " + spawnRequestEvent.requestId + ", requestingClientId " + 
          //   spawnRequestEvent.requestingClientPlayerId + ".");
        }
        else {
          Debug.LogError("Object spawn IDs must be received from the server: " +
            "Pass " + LeapNetManager.NO_NETWORK_ID + " as the state network " +
            "ID; it will then be modified to the ID the server provides.");
          return -1;
        }
      }
    }

    /// <summary>
    /// Requests that the server despawn the object ID, whose actual type should
    /// be associated with a spawn handler for the type argument.
    /// Will throw an KeyNotFoundException if the argument ID is not tracked by
    /// this spawn manager, or an Exception if the argument ID does not have a
    /// despawn handler associated with the despawn object's state event type.
    /// </summary>
    public void RequestDespawn<T>(int objectNetworkId,
      LeapNetEvents.TypeHint<T> typeHint = null)
      where T : struct, ILeapNetSpawnable
    {
      if (network.networkMode == NetworkMode.Server) {
        // If we're the server, we want to go straight to receiving the event,
        // because the server gets ultimate authority over spawns (there's no
        // need to go to the network thread and back).
        var despawnRequest = createDespawnRequestEvent<T>(objectNetworkId);
        onDespawnRequestEvent<T>(despawnRequest);
      }
      else { // NetworkMode.Client
        if (!network.hasLocalPlayerId) {
          network.LogWarning("Can't despawn anything without a local player ID.");
        }

        // For clients, we do a quick validation that there's a despawn handler
        // for the object before enqueueing the despawn.
        // TODO: Is this necessary anymore? All spawn handlers are already
        // required and checked to have corresponding despawn handlers during
        // application initialization.
        var despawnHandler = GetDespawnHandlerForType(typeof(T));
        if (despawnHandler == null) {
          throw new System.Exception("No despawn handler was found for type " +
            typeof(T) + "; unable to request a despawn for object ID " + 
            objectNetworkId + ".");
        }

        var objectToDespawn = (LeapNetObject)null;
        _client_spawnIdsToObjectsMap.TryGetValue(objectNetworkId,
          out objectToDespawn);
        if (objectToDespawn == null) {
          network.LogWarning("Got RequestDespawn for ID " + objectNetworkId + 
            "but there is no such object known by this spawn manager.");
        }
        else {
          var despawnRequest = createDespawnRequestEvent<T>(objectNetworkId);
          network.EnqueueEvent(despawnRequest);
        }
      }
    }

    #endregion

  }

}
