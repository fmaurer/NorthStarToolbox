using System;
using System.Collections.Generic;

namespace Leap.Unity.Networking {

  public interface ILeapNetObjectDatabase {

    /// <summary>
    /// Note: 
    void Set<T>(int objectId, T data) where T : LeapNetObjectData;
    void Remove<T>(int objectId) where T : LeapNetObjectData;
    bool TryGet<T>(int objectId, out T data) where T : LeapNetObjectData;
  }

  /// <summary>
  /// Marker interface declaring structs that store data keyed by LeapNetObject
  /// network ID.
  ///
  /// For example implementations, see SpawnSystem's LeapNetObjectSpawnData and
  /// AuthoritySystem's LeapNetObjectAuthorityData.
  /// </summary>
  public interface LeapNetObjectData { }

  /// <summary>
  /// LeapNetManager Server mode subsystem that handles LeapNetObject data
  /// storage and retrieval.
  /// </summary>
  public class DatabaseSystem : ILeapNetObjectDatabase {

    private Dictionary<Type, object> _tables = new Dictionary<Type, object>();
    private class Table<T> {
      public struct Entry {
        public bool exists; public T value;
        public Entry(T value) { exists = true; this.value = value; }
      }
      public Entry[] data;
      public Table(int capacity) { data = new Entry[capacity]; }
    }

    public LeapNetManager network;

    public DatabaseSystem(LeapNetManager network) {
      this.network = network;
    }

    public void Set<T>(int objectId, T data) where T : LeapNetObjectData {
      requireUnityThread();
      var table = ensureTableExists<T>();

      table.data[objectId] = new Table<T>.Entry(data);
    }

    public void Remove<T>(int objectId) where T : LeapNetObjectData {
      requireUnityThread();
      var table = ensureTableExists<T>();
      
      table.data[objectId].exists = false;
    }

    public bool TryGet<T>(int objectId, out T data) where T : LeapNetObjectData {
      requireUnityThread();
      var table = ensureTableExists<T>();

      Table<T>.Entry entry = table.data[objectId];
      if (entry.exists) { data = entry.value; return true; }
      else { data = default(T); return false; }
    }

    private void requireUnityThread() {
      if (System.Threading.Thread.CurrentThread != LeapNetManager.unityThread) {
        throw new System.InvalidOperationException("Must call Set from the " +
          "Unity thread.");
      }
    }

    private Table<T> ensureTableExists<T>() {
      var dataType = typeof(T);
      object typelessTable;
      if (!_tables.TryGetValue(dataType, out typelessTable)) {
        var newTable = new Table<T>(LeapNetManager.MAX_NETWORK_ID + 1);
        _tables[dataType] = newTable;
        return newTable;
      }
      else {
        return typelessTable as Table<T>;
      }
    }
    
  }

}