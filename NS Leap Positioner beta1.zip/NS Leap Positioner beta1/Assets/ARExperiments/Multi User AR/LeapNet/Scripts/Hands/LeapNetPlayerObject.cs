using Leap.Unity.Encoding;
using Leap.Unity.Networking.Events;
using Leap.Unity.Query;
using Leap.Unity.Attributes;
using System.Runtime.InteropServices;
using UnityEngine;
using System.Collections;

namespace Leap.Unity.Networking {

  public class LeapNetPlayerObject : LeapNetObject  {

    [StructLayout(LayoutKind.Sequential)]
    public struct LeapPlayerEvent : ILeapNetSpawnable {
      public int networkId;
      public int GetNetworkId() { return networkId; }
      public void SetNetworkId(int networkId) { this.networkId = networkId; }
      public float updateInterval;
      public Pose headPose;

      public bool hasLeftHand;
      [MarshalAs(UnmanagedType.ByValArray, SizeConst = VectorHand.NUM_BYTES)]
      public byte[] leftVectorHandBytes;

      public bool hasRightHand;
      [MarshalAs(UnmanagedType.ByValArray, SizeConst = VectorHand.NUM_BYTES)]
      public byte[] rightVectorHandBytes;
    }

    ///<summary>A static reference to the GameObject to instantiate</summary>
    public static LeapNetPlayerObject s_RemotePlayerPrefab;
    ///<summary>A static reference to the local player object</summary>
    public static LeapNetPlayerObject s_LocalPlayerObject;

    [Tooltip("The interval (in seconds) in which hand updates are sent out.")]
    public float updateInterval = 0.008333334f;
    [Tooltip("The transform which the head pose will be read from and written to")]
    public Transform headTransform;

    [Header("Local Player Only")]
    [DisableIfNotEqual("remoteStreamProvider", To: null)]
    [Tooltip("The manager associated with spawning this player.")]
    public LeapNetManager spawningNetworkManager;
    [DisableIfNotEqual("remoteStreamProvider", To: null)]
    [Tooltip("Only used if the NetworkPlayer is the local player.")]
    public LeapProvider localHandProvider;
    [Tooltip("The remote player prefab to spawn upon joining; " +
             "NOTE: This is only set on the local player object.")]
    [DisableIfEqual("localHandProvider", To: null)]
    public LeapNetPlayerObject remotePlayerPrefab;

    [Header("Remote Players Only")]
    [DisableIfNotEqual("localHandProvider", To: null)]
    [Tooltip("Only used if the NetworkPlayer is a remote player.")]
    public VectorHandStreamProvider remoteStreamProvider;
    [Tooltip("If set, uses this transform as any remote player's effective " +
      "origin. This is useful for locally testing two clients on a single " +
      "machine.")]
    public Transform remoteOrigin;
    /// <summary> This matrix, computed from and together with remoteOrigin,
    /// allows remote rig head and hand poses to be rendered on local machines
    /// with a different effective origin. This is useful for locally testing
    /// two clients on a single machines. </summary> 
    private Matrix4x4 _remoteOriginMatrix {
      get {
        if (remoteOrigin == null) { return Matrix4x4.identity; }
        else {
          return remoteOrigin.localToWorldMatrix;
        }
      }
    }

    private VectorHand _backingCurLeftVectorHand;
    private VectorHand _curLeftVectorHand {
      get {
        if (_backingCurLeftVectorHand == null) {
          _backingCurLeftVectorHand = new VectorHand();
        }
        return _backingCurLeftVectorHand;
      }
    }
    private VectorHand _backingCurRightVectorHand;
    private VectorHand _curRightVectorHand {
      get {
        if (_backingCurRightVectorHand == null) {
          _backingCurRightVectorHand = new VectorHand();
        }
        return _backingCurRightVectorHand;
      }
    }

    LeapNetInterpolator<Pose> headInterpolator = new LeapNetInterpolator<Pose>();

    [SpawnHandler(typeof(LeapPlayerEvent))]
    public static LeapNetObject HandleSpawn(LeapNetManager network,
      int spawnedNetworkId, bool hasLocalAuthority, LeapPlayerEvent spawnState,
      int spawnRequestId)
    {
      LeapNetPlayerObject playerObj = s_LocalPlayerObject;
      if (!hasLocalAuthority) {
        //Need to have a LeapPrefabInstantiator component in your scene
        LeapNetPlayerObject prefab = s_RemotePlayerPrefab;
        if (prefab != null) {
          GameObject instance = Instantiate(prefab.gameObject, Vector3.zero, Quaternion.identity);
          instance.SetActive(true);
          playerObj = instance.GetComponent<LeapNetPlayerObject>();
          if (playerObj == null) Debug.LogError("LeapNetPlayerObject is null; " +
                                                "this should never happen!!!", instance);
        } else { Debug.LogError("PLAYER PREFAB NOT SET; " +
                                "ASSIGN IT ON YOUR LOCAL LEAPNETPLAYEROBJECT"); }
      }
      if (playerObj != null) {
        playerObj.headTransform.SetPose(playerObj._remoteOriginMatrix.GetPose() *
          spawnState.headPose);
        playerObj.NotifyNetworkSpawned(network, spawnedNetworkId, hasLocalAuthority);
        Debug.Log("LeapNetPlayerObject spawned with ID: " + spawnedNetworkId + 
                  ", hasLocalAuthority: " + hasLocalAuthority);
      } else {
        Debug.LogError("LOCAL PLAYER RIG DOES NOT EXIST; ADD ONE TO YOUR SCENE");
      }
      return playerObj;
    }

    [DespawnHandler(typeof(LeapPlayerEvent))]
    public static bool HandleDespawn(LeapNetObject objectToDespawn) {
      bool remote = objectToDespawn.netState == LeapNetState.Remote;
      objectToDespawn.NotifyNetworkDespawned();
      if (remote) Destroy(objectToDespawn.gameObject);
      return true;
    }

    private void Reset() {
      if (remoteStreamProvider == null) {
        remoteStreamProvider =
          GetComponentInChildren<VectorHandStreamProvider>();
      }
      if (remoteStreamProvider == null && localHandProvider == null) {
        localHandProvider = GetComponentInChildren<LeapProvider>();
      }
    }

    private void OnEnable() {
      OnNetworkSpawned -= onNetworkSpawned;
      OnNetworkSpawned += onNetworkSpawned;
      OnNetworkDespawned -= onNetworkDespawned;
      OnNetworkDespawned += onNetworkDespawned;

      if (localHandProvider != null) {
        localHandProvider.OnUpdateFrame -= onLocalPlayerUpdateFrame;
        localHandProvider.OnUpdateFrame += onLocalPlayerUpdateFrame;
        if (s_LocalPlayerObject == null) s_LocalPlayerObject = this;
        if (remotePlayerPrefab != null && s_RemotePlayerPrefab == null) {
          s_RemotePlayerPrefab = remotePlayerPrefab;
        }

        StartCoroutine(spawnCoroutine());
      }
    }
    private IEnumerator spawnCoroutine() {
      while (!spawningNetworkManager.hasLocalPlayerId) { yield return null; }
      spawningNetworkManager.RequestSpawn(new LeapPlayerEvent(), null, true);
    }

    private void OnDisable() {
      OnNetworkSpawned -= onNetworkSpawned;
      OnNetworkDespawned -= onNetworkDespawned;

      if (localHandProvider != null) {
        localHandProvider.OnUpdateFrame -= onLocalPlayerUpdateFrame;
        if (s_LocalPlayerObject != null) s_LocalPlayerObject = null;
        if (s_RemotePlayerPrefab != null) s_RemotePlayerPrefab = null;
        if (spawningNetworkManager != null && netState == LeapNetState.LocalAuthority) network.RequestDespawn(networkId);
      }
    }

    private void onNetworkSpawned() {
      if (netState == LeapNetState.Remote) RegisterEventListener<LeapPlayerEvent>(this);
    }

    private void onNetworkDespawned() {
      // netState is about to become LeapNetState.Inactive, right _after_
      // this callback is called. We can check which state we were in during
      // this callback.
      if (netState == LeapNetState.Remote) UnregisterEventListener<LeapPlayerEvent>(this);
    }

    private void Update() {
      if (netState == LeapNetState.Remote) {
        LeapPlayerEvent playerEvent;
        while (TryDequeueEvent(this, out playerEvent)) {
          processRemotePlayerHandsEvent(playerEvent);
          headInterpolator.enqueueUpdate(_remoteOriginMatrix.GetPose() *
            playerEvent.headPose, updateInterval);
          // Debug.Log("Enqueued head interpolator update. Origin pose was " +
          //   _remoteOriginMatrix.GetPose());
        }

        Pose headPose = Pose.identity;
        if (headInterpolator.interpolateSample(ref headPose, Time.unscaledDeltaTime)) {
          headTransform.SetPose(headPose);
        }
      }
    }

    private void processRemotePlayerHandsEvent(LeapPlayerEvent playerEvent) {
      // If we receive a hands event, it should be because we're on a remote
      // instance of a player and need to update with the latest data from the
      // server.
      // Null indicates no hand is tracked.
      var effLeftVectorHand = (VectorHand)null;
      if (playerEvent.hasLeftHand) {
        effLeftVectorHand = _curLeftVectorHand;
        effLeftVectorHand.ReadBytes(playerEvent.leftVectorHandBytes);
      }
      var effRightVectorHand = (VectorHand)null;
      if (playerEvent.hasRightHand) {
        effRightVectorHand = _curRightVectorHand;
        effRightVectorHand.ReadBytes(playerEvent.rightVectorHandBytes);
      }
      // Debug.Log("Sent Hands event has left: " + vectorHandsEvent.hasLeftHand);
      // Debug.Log("Sent Hands event has right: " + vectorHandsEvent.hasRightHand);

      if (remoteStreamProvider != null) {
        remoteStreamProvider.effectiveOrigin = this.remoteOrigin;
        remoteStreamProvider.NotifyLatestHands(
            effLeftVectorHand,
            effRightVectorHand,
            playerEvent.updateInterval);
      }
    }

    private Hand _localLeftHandCached = new Hand();
    private Hand _localLeftHand = null;
    private Hand _localRightHandCached = new Hand();
    private Hand _localRightHand = null;
    private byte[] _leftVectorHandByteCache = new byte[VectorHand.NUM_BYTES];
    private byte[] _rightVectorHandByteCache = new byte[VectorHand.NUM_BYTES];
    private float _skipTimer = 0;

    private void onLocalPlayerUpdateFrame(Frame frame) {
      //Return if it has been less than updateInterval since the last update
      if ((_skipTimer += Time.unscaledDeltaTime) > updateInterval) {
        _skipTimer -= updateInterval;
      } else { return; }

      // Generate hand events and send them to the server if we have local
      // authority over the attached player.
      if (netState == LeapNetState.LocalAuthority &&
          localHandProvider != null) {
        var playerId = networkId;

        var leftHand = frame.Hands.Query().FirstOrDefault(h => h.IsLeft);
        var rightHand = frame.Hands.Query().FirstOrDefault(h => !h.IsLeft);

        // TODO: Temporarily removed inverse Leap transform.
        // var providerInverseMatrix =
        //   localHandProvider.transform.worldToLocalMatrix;
        // var translation = providerInverseMatrix.GetPosition().ToVector();
        // var rotation = providerInverseMatrix.GetRotation().ToLeapQuaternion();

        if (leftHand != null) {
          _localLeftHand = _localLeftHandCached;
          _localLeftHand.CopyFrom(leftHand);
          // TODO: Temporarily removed inverse Leap transform.
          // _localLeftHand.Transform(
          //   new LeapTransform(translation, rotation)
          // );
          VectorHand.StaticFillBytes(_leftVectorHandByteCache, 0,
            fromHand: _localLeftHand);
        }
        if (rightHand != null) {
          _localRightHand = _localRightHandCached;
          _localRightHand.CopyFrom(rightHand);
          // TODO: Temporarily removed inverse Leap transform.
          // _localRightHand.Transform(
          //   new LeapTransform(translation, rotation)
          // );
          VectorHand.StaticFillBytes(_rightVectorHandByteCache, 0,
            fromHand: _localRightHand);
        }

        var playerHandsEvent = new LeapPlayerEvent() {
          networkId = playerId,
          updateInterval = updateInterval,
          hasLeftHand = leftHand != null,
          leftVectorHandBytes = _leftVectorHandByteCache,
          hasRightHand = rightHand != null,
          rightVectorHandBytes = _rightVectorHandByteCache,
          headPose = headTransform.ToPose()
        };
        //Debug.Log("SCREAMING INTO THE VOID");
        network.EnqueueEvent(playerHandsEvent);
      }
    }

  }

}
