using System;
using System.Collections.Generic;
using Leap.Unity.Encoding;
using UnityEngine;

namespace Leap.Unity.Networking {

  public class VectorHandStreamProvider : LeapProvider  {

    [Range(0f, 0.3f)]
    public float prediction = 0f;
    public bool useSmoothingSpline = false;

    [NonSerialized]
    public Transform effectiveOrigin = null;
    private Matrix4x4 _effectiveOriginMatrix {
      get {
        if (effectiveOrigin == null) { return Matrix4x4.identity; }
        else {
          return effectiveOrigin.localToWorldMatrix;
        }
      }
    }

    private Frame _backingCurrentFrame = null;
    private Frame _currentFrame {
      get {
        if (_backingCurrentFrame == null) {
          _backingCurrentFrame = new Frame();
          _backingCurrentFrame.Id = 100;
          _backingCurrentFrame.CurrentFramesPerSecond = 110f;
          _backingCurrentFrame.Timestamp = (long)(Time.time * 1e6);
          _backingCurrentFrame.Hands = new List<Hand>();
        }
        return _backingCurrentFrame;
      }
    }

    private LeapNetInterpolator<VectorHands> _handInterpolator =
      new LeapNetInterpolator<VectorHands>();

    private struct VectorHands : IInterpolable<VectorHands> {
      public VectorHand left, right;
      public bool hasLeft, hasRight;

      public VectorHands(bool something = true) {
        left = new VectorHand(); right = new VectorHand();
        hasLeft = false; hasRight = false;
      }

      /// <summary> Copies a VectorHands from another VectorHands </summary>
      public VectorHands CopyFrom(VectorHands h) {
        if (left == null) left = new VectorHand();
        left.CopyFrom(h.left);
        if (right == null) right = new VectorHand();
        right.CopyFrom(h.right);
        hasLeft = h.hasLeft; hasRight = h.hasRight;
        return this;
      }
      public bool FillLerped(VectorHands a, VectorHands b, float t) {
        if (left == null) left = new VectorHand();
        hasLeft  = a.hasLeft  && b.hasLeft  && left .FillLerped(a.left,  b.left, t);
        if (right == null) right = new VectorHand();
        hasRight = a.hasRight && b.hasRight && right.FillLerped(a.right, b.right, t);
        return hasLeft && hasRight;
      }
      public bool FillSplined(VectorHands a, VectorHands b, VectorHands c,
        VectorHands d, float t)
      {
        if (left == null) left = new VectorHand();
        hasLeft = a.hasLeft && b.hasLeft && c.hasLeft && d.hasLeft &&
          a.left != null && b.left != null && c.left != null && d.left != null &&
          left.FillSplined(a.left, b.left, c.left, d.left, t);
        if (right == null) right = new VectorHand();
        hasRight = a.hasRight && b.hasRight && c.hasRight && d.hasRight &&
          a.right != null && b.right != null && c.right != null && d.right != null &&
          right.FillSplined(a.right, b.right, c.right, d.right, t);
        return hasLeft && hasRight;
      }
    }

    private VectorHands hands;

    /// <summary>
    /// Called when new hand data is available for the stream from the data
    /// source, e.g., newly parsed network packets.
    /// </summary>
    public void NotifyLatestHands(VectorHand left, VectorHand right, float updateInterval) {
      if (left != null) left = new VectorHand().CopyFrom(left);
      if (right != null) right = new VectorHand().CopyFrom(right);

      VectorHands newHands = new VectorHands() {
        left = left, right = right, hasLeft = (left!=null), hasRight = (right != null)
      };

      _handInterpolator.enqueueUpdate(newHands, updateInterval);
    }

    private void Update() {
      _handInterpolator.interpolateSample(ref hands, Time.unscaledDeltaTime);

      // Interpolate to get the state at the current playhead time.
      var handCount = 0;
      if (hands.left != null && hands.hasLeft) { handCount++; }
      if (hands.right != null && hands.hasRight) { handCount++; }
      _currentFrame.ResizeHandList(handCount);

      int addedCount = 0;
      var originPose = _effectiveOriginMatrix.GetPose();
      if (hands.hasLeft) {
        var leftHand = _currentFrame.Hands[addedCount++];
        hands.left.Decode(leftHand);
        leftHand.Transform(originPose.position, originPose.rotation);
      }
      if (hands.hasRight) {
        var rightHand = _currentFrame.Hands[addedCount++];
        hands.right.Decode(rightHand);
        rightHand.Transform(originPose.position, originPose.rotation);
      }

      DispatchUpdateFrameEvent(_currentFrame);
    }

    public override Frame CurrentFrame {
      get {
        return _currentFrame;
      }
    }

    public override Frame CurrentFixedFrame {
      get {
        return _currentFrame;
      }
    }
  }

}
