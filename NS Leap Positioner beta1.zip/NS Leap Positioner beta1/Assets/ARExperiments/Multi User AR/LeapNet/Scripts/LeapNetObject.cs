using System;
using Leap.Unity.Attributes;
using Leap.Unity.Networking.Events;
using UnityEngine;

namespace Leap.Unity.Networking {

  /// <summary>
  /// LeapNetPlayers are Inactive by default. When a LeapNetManager gets
  /// connected player information from a connected server, it spawns and
  /// activates LeapNetPlayers to represent either the Local player or Remote
  /// player instances.
  /// </summary>
  public enum LeapNetState {
    /// <summary> Indicates the object is not visible on the network. </summary>
    Inactive,

    /// <summary>
    /// Indicates the object is active on the network and that the local
    /// client has authority (write priveleges) on its state.
    /// </summary>
    LocalAuthority,

    /// <summary>
    /// Indicates the object is active on the network, and that the local
    /// client is not allowed to change its state (as far as the server is
    /// concerned).
    /// </summary>
    Remote
  }

  /// <summary>
  /// LeapNetObjects allow object spawning and despawning to be automatically
  /// handled over a network session.
  ///
  /// To define a new type of object that can be spawned and despawned and whose
  /// data can be synchronized over the network, define static methods marked
  /// with a SpawnHandlerAttribute and DespawnHandlerAttribute, and define the
  /// data struct for the object sync event, implementing
  /// ILeapNetObjectSyncEvent.
  ///
  /// The spawn and despawn handler methods will be detected and cached on
  /// startup, and will be invoked with local authority information
  /// automatically. Finally, implement data synchronization for your new object
  /// by enqueueing sync events at any time and regularly dequeueing data from
  /// a standard event listener registered for the sync event, which is a normal
  /// ILeapNetEvent.
  /// </summary>
  public class LeapNetObject : MonoBehaviour, IInternalAuthorityNotifiable {

    [SerializeField, Disable]
    [Tooltip("Reference only. This set when the LeapNet object is spawned by " +
      "its spawn handler, indicating it is now visible over the network.")]
    private LeapNetManager _network;
    public LeapNetManager network {
      get { return _network; }
    }

    [SerializeField, Disable]
    [Tooltip("Reference only. When activated by the LeapNetManager, the " +
      "netState is set to Local or Remote depending on whether the local " +
      "client has authority over this instance, or if it is a remote instance. " +
      "The LeapNetManager can change the authority state of a LeapNetObject at " +
      "any time!")]
    private LeapNetState _netState = LeapNetState.Inactive;
    public LeapNetState netState { get { return _netState; } }

    [SerializeField, Disable]
    [Tooltip("Reference only. When activated by the LeapNetManager, the "
      + "player ID of this NetworkPlayer is set to the ID of the player it "
      + "represents in the game session. Valid IDs are 1 or greater.")]
    private int _networkId = -1;
    public int networkId { get { return _networkId; } }
    public bool hasNetworkId { get { return _networkId != -1; } }

    /// <summary>
    /// Invoked when the object is spawned, becoming active in the network
    /// session.
    /// </summary>
    public event Action OnNetworkSpawned = () => { };

    /// <summary>
    /// Invoked when the object disconnects from the network session. This
    /// event fires just before the LeapNetState is set to inactive, so you
    /// can check it during the callback to detect whether the object had
    /// local authority or was a remote instance.
    /// </summary>
    public event Action OnNetworkDespawned = () => { };

    /// <summary>
    /// Invoked when this local client gains or loses authority of this object.
    /// </summary>
    public event Action OnAuthorityChanged = () => { };

    /// <summary>
    /// Should generally only be called by the spawn handler for this object.
    /// </summary>
    public void NotifyNetworkSpawned(LeapNetManager network, int networkId,
                                     bool hasLocalAuthority) {
      _network = network;
      _netState = hasLocalAuthority ? LeapNetState.LocalAuthority :
        LeapNetState.Remote;
      _networkId = networkId;

      OnNetworkSpawned.Invoke();
    }

    /// <summary>
    /// Should generally only be called by the despawn handler for this object.
    /// </summary>
    public void NotifyNetworkDespawned() {
      OnNetworkDespawned.Invoke();

      _netState = LeapNetState.Inactive;
      _networkId = -1;
      _network = null;
    }

    /// <summary>
    /// Registers an event listener with the network manager whose network ID
    /// matches this object's.
    /// Use this to register network listeners for an object's networked-synced
    /// subsystems.
    /// </summary>
    public void RegisterEventListener<T>(object listener)
                                         where T : struct, ILeapNetEvent {
      if (netState != LeapNetState.Inactive) {
        network.RegisterEventListener<T>(networkId, listener);
      }
    }

    /// <summary>
    /// Unregisters an event listener with the network manager whose network ID
    /// matches this object's.
    /// Use this to unregister network listeners for an object's
    /// networked-synced subsystems.
    /// </summary>
    public void UnregisterEventListener<T>(object listener)
                                           where T : struct, ILeapNetEvent {
      if (netState != LeapNetState.Inactive) {
        network.UnregisterEventListener<T>(networkId, listener);
      }
    }

    /// <summary>
    /// Tries to dequeue a pending event of the argument type from the buffer
    /// associated with the listener. (Usually, the "listener" is just the
    /// object calling this method.)
    /// </summary>
    public bool TryDequeueEvent<T>(object listener, out T netEvent)
                                   where T : struct, ILeapNetEvent {
      if (netState == LeapNetState.Inactive) {
        if (Application.isEditor || Debug.isDebugBuild) {
          Debug.LogError("Tried to dequeue an event, but the network was " +
            "inactive. (This message only appears in the editor or debug builds.)",
            this);
        }
        netEvent = default(T);
        return false;
      }
      return network.TryDequeueEvent<T>(this.networkId, listener, out netEvent);
    }

    public void RequestAuthority<T>(Action<T> onSuccess,
      Action<T, AuthorityRequestFailure> onFailure)
      where T: LeapNetObject
    {
      if (netState == LeapNetState.Inactive) {
        if (Application.isEditor || Debug.isDebugBuild) {
          Debug.LogError("Tried to dequeue an event, but the network was " +
            "inactive. (This message only appears in the editor or debug builds.)",
            this);
        }
        onFailure(this as T, AuthorityRequestFailure.NetworkInactive);
      }
      
      try {
        network.RequestAuthority(network.localPlayerId, this.networkId,
          onSuccess: () => { 
            onSuccess(this as T);
          },
          onFailure: (authorityRequestError) => {
            onFailure(this as T, authorityRequestError);
          });
      }
      catch (System.Exception e) {
        network.LogCritical(e.ToString());
        onFailure(this as T, AuthorityRequestFailure.RequestRaisedException);
      }
    }

    
    void IInternalAuthorityNotifiable.NotifyAuthorityGiven() {
      // Debug.Log("Authority system said this object now has local authority. " +
      //   "Local player ID is " + network.localPlayerId + ".");
      _netState = LeapNetState.LocalAuthority;
      OnAuthorityChanged.Invoke();
    }

    void IInternalAuthorityNotifiable.NotifyAuthorityLost() {
      // Debug.Log("Authority system said this object no longer has local " +
      //   "authority. Local player ID is " + network.localPlayerId + ".");
      _netState = LeapNetState.Remote;
      OnAuthorityChanged.Invoke();
    }

  }

}
