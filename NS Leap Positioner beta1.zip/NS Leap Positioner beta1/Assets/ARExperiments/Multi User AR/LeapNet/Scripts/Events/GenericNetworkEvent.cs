using System;

namespace Leap.Unity.Networking.Events {

  /// <summary>
  /// Sometimes, it's useful to disregard an event's type or any particulars
  /// about its data. This struct contains the bytes and type information for
  /// an event; its bytes can trivially be copied into an EventsPacket in place
  /// of an actual instance of a network event struct.
  ///
  /// A server can use this to forward event byte data from one client to
  /// another. The events pipeline also uses this struct to read data packets
  /// before type information is restored and handlers are invoked.
  /// </summary>
  public struct GenericNetworkEvent : IEquatable<GenericNetworkEvent> {
    public byte[] bytes;
    public int offset;
    public int length;
    public Type eventType;
    private bool _isValid;
    public bool isValid { get { return _isValid; } }

    public static GenericNetworkEvent CreateSingleGenericContainer() {
      return new GenericNetworkEvent() {
        bytes = new byte[LeapNetEvents.GetLargestEventSize()],
        offset = 0,
        length = 0,
        eventType = null,
        _isValid = false
      };
    }
    /// <summary>
    /// Fills this GenericNetworkEvent with byte data from the argument
    /// network event.
    /// </summary>
    public void CopyFrom<T>(T networkEvent, int offset = 0)
                            where T : struct, ILeapNetEvent {
      LeapNetEvents.FillBytes(networkEvent, this.bytes, offset);
      this.offset = offset;
      this.eventType = typeof(T);
      this.length = LeapNetEvents.GetEventSizeForType(typeof(T));
      this._isValid = true;
    }

    /// <summary>
    /// Creates a GenericNetworkEvent from the argument event code, bytes,
    /// and offset. Bytes are not copied; the byte array's reference is stored.
    /// </summary>
    public GenericNetworkEvent(int eventCode, byte[] bytes, int offset) {
      var eventType = LeapNetEvents.GetEventTypeForCode(eventCode);
      var eventSize = LeapNetEvents.GetEventSizeForType(eventType);
      this.bytes = bytes;
      this.offset = offset;
      this.length = eventSize;
      this.eventType = eventType;
      this._isValid = true;
    }

    /// <summary>
    /// Creates a GenericNetworkEvent from the argument event code, bytes,
    /// and offset. Bytes are not copied; the byte array's reference is stored.
    /// The passed offset reference is incremented by the size of the event
    /// whose code was specified.
    /// </summary>
    public GenericNetworkEvent(int eventCode, byte[] bytes, ref int offset) {
      var eventType = LeapNetEvents.GetEventTypeForCode(eventCode);
      var eventSize = LeapNetEvents.GetEventSizeForType(eventType);
      this.bytes = bytes;
      this.offset = offset;
      this.length = eventSize;
      this.eventType = eventType;
      this._isValid = true;

      offset += eventSize;
    }

    /// <summary>
    /// Returns an event of the type argument type from the event bytes
    /// referenced by this generic network event.
    /// Throws an exception if the event type this generic network event
    /// contains does not match the type argument. Otherwise, this operation
    /// simply wraps `LeapNetEvents.ReadBytes`.
    /// </summary>
    public T ToEvent<T>(LeapNetEvents.TypeHint<T> typeHint = null)
                        where T : struct, ILeapNetEvent {
      if (typeof(T) != this.eventType) {
        throw new System.Exception("Cannot convert GenericNetworkEvent " +
          "containing event of type " + this.eventType + " to event of type " +
          typeof(T));
      }
      return LeapNetEvents.ReadBytes<T>(this.bytes, this.offset);
    }

    public bool Equals(GenericNetworkEvent other) {
      return this.bytes.Equals(other.bytes) && this.offset == other.offset &&
        this.eventType.Equals(other.eventType) && this.length == other.length &&
        this._isValid == other._isValid;
    }
  }

}
