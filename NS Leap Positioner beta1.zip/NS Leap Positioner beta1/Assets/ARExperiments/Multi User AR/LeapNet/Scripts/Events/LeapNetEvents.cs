using System;
using System.Collections.Generic;
using System.Reflection;
using System.Reflection.Emit;
using System.Runtime.InteropServices;
using UnityEngine;

namespace Leap.Unity.Networking.Events {

  /// <summary>
  /// Marks structs that are safe to pass into LeapNetEvents.FillBytes.
  /// Any custom structs should be fine as long as they don't contain object
  /// references.
  ///
  /// GetNetworkId() should return a network ID (player or object) that
  /// corresponds to the data being synchronized.
  ///
  /// Usually, events are generated with the intent to send data from or sync
  /// data to a specific object identified on the network. Such an object will
  /// have a network ID, which should be encoded in the struct and returned by
  /// GetNetworkId().
  ///
  /// If the event is intended for the server only, GetNetworkId() can return 0.
  /// </summary>
  public interface ILeapNetEvent {
    int GetNetworkId();
  }

  public static class LeapNetEvents {

    public const int EVENT_CODE_SIZE = sizeof(int);
    public const int NULL_EVENT_CODE = 0;

    /// <summary> For reading EventsPackets. </summary>
    private static Dictionary<int, Type> _codesToTypesMap =
      new Dictionary<int, Type>();

    /// <summary> For writing EventsPackets. </summary>
    private static Dictionary<Type, int> _typesToCodesMap =
      new Dictionary<Type, int>();
    private static Dictionary<Type, int> _typesToSizesMap =
      new Dictionary<Type, int>();
    private static int _largestTypeSize = 0;
    //private static int _largestGenericTypeSize = 0;
    private static Type _largestType = null;
    private static int _numEventTypes = 0;

    /// <summary>
    /// Here be black magics. We cache and store some objects that have known
    /// associated network event types _at runtime_, so we can access them
    /// to dynamically resolve generic type arguments at runtime as well.
    /// </summary>
    private static Dictionary<Type, object> _typesToTypeHintsMap =
      new Dictionary<Type, object>();
    public class TypeHint<T> {
      public static TypeHint<T> hint;
      static TypeHint() {
        hint = new TypeHint<T>();
      }
    }
    private static TypeHint<T> getCachedTypeHint<T>() {
      return TypeHint<T>.hint;
    }
    private static MethodInfo genericGetCacheTypeHintMethod = null;
    private static bool tryGetAndCacheTypeHint(Type type, out object typeHint) {
      if (genericGetCacheTypeHintMethod == null) {
        genericGetCacheTypeHintMethod =
          typeof(LeapNetEvents).GetType().GetMethod("getCachedTypeHint",
            BindingFlags.NonPublic | BindingFlags.Static);

        var memberInfos = typeof(LeapNetEvents).GetMember("getCachedTypeHint*",
            BindingFlags.InvokeMethod | BindingFlags.NonPublic |
            BindingFlags.Static);
        foreach (var memberInfo in memberInfos) {
          var methodInfo = memberInfo as MethodInfo;
          if (methodInfo == null) continue;
          genericGetCacheTypeHintMethod = methodInfo;
          break;
        }
        if (genericGetCacheTypeHintMethod == null) {
          Debug.LogError("Failed to generate cached type hint for LeapNetEvents.");
        }
      }
      if (type.ContainsGenericParameters) {
        Debug.Log("Unable to cache type hint for " + type + "; because its " +
          "types are not fully specified. The subsystem that declared it will " +
          "need to call CacheTypeHintForType for any fully-type-qualified events " +
          "it seeks to be able to send and receive.");
        typeHint = new object();
        return false;
      }
      else {
        var genericMethod = genericGetCacheTypeHintMethod.MakeGenericMethod(type);
        typeHint = genericMethod.Invoke(null, null);
        _typesToTypeHintsMap[type] = typeHint;
        return true;
      }
    }
    public static object GetTypeHint(Type eventType) {
      return _typesToTypeHintsMap[eventType];
    }
    /// <summary>
    /// You only need to manually call this on a struct that implements
    /// ILeapNetEvent if that struct is generic over another type.
    /// In that case, you'll need to call this for every fully-qualified type
    /// of that struct will be using.
    /// </summary>
    public static bool RegisterNetEventType(Type eventType) {
      // Sometimes, we may find ILeapNetEvents that can't get type hints
      // because they are themselves generic. In this case, the subsystem
      // that declares ILeapNetEvents that are generic is responsible for
      // providing concrete type hints by calling 
      // `CacheTypeHintForType()` with the fully concrete type.
      // Example: LeapNetSpawnManager, which declares events for spawning
      // and despawning that are generic over certain ILeapNetEvents. 
      object typeHint;
      if (tryGetAndCacheTypeHint(eventType, out typeHint)) {
        //Debug.Log("We're OK for type " + eventType);
        _typesToTypeHintsMap[eventType] = typeHint;
      }
      else {
        //Debug.Log("Not OK for type " + eventType);
        throw new System.Exception();
      }
      
      // Assign each found type a code that can be used to identify events
      // of that type in a packet.
      var assignedTypeCode = _numEventTypes + 1; // 0 is NULL_EVENT_CODE.
      _numEventTypes += 1;
      _codesToTypesMap[assignedTypeCode] = eventType;
      _typesToCodesMap[eventType] = assignedTypeCode;
      var eventSize = Marshal.SizeOf(eventType);
      if (eventSize > _largestTypeSize) {
        _largestTypeSize = eventSize;
        _largestType = eventType;
      }
      _typesToSizesMap[eventType] = eventSize;

      // TODO: DELETEME
       if (eventType ==
         typeof(AR.Experiments.NetworkedPhysicsObject.PhysicsSyncEvent))
       {
         Debug.Log("Registered PhysicsSyncEvent type. Size is " + eventSize +
           " bytes.");

         var bytes = new byte[100];
         var physicsSync = new AR.Experiments.NetworkedPhysicsObject.PhysicsSyncEvent() {
           prefabID = 129,
           pose = new Pose(new Vector3(1f, 2f, 3f),
             new Quaternion(4f, 5f, 6f, 7f)),
           localScale = new Vector3(8f, 9f, 1f),
           authoritySoftLocked = false,
           deltaTime = 2345f,
           useGravity = true,
           isKinematic = false
         };

         FillBytes(physicsSync, bytes, 0);
         var r = ReadBytes<AR.Experiments.NetworkedPhysicsObject.PhysicsSyncEvent>(bytes, 0);
      
         Debug.Log(
           "prefab ID: " + r.prefabID +
           "; pose: position: " + r.pose.position.ToString("R") +
             ", rotation: " + r.pose.rotation.ToString("R") +
           "; localScale: " + r.localScale.ToString("R") +
           "; authoritySoftLocked: " + r.authoritySoftLocked +
           "; deltaTime: " + r.deltaTime +
           "; useGravity: " + r.useGravity +
           "; isKinematic: " + r.isKinematic
         );
       }

      return true;
    }

    static LeapNetEvents() {
      // Scan the assembly for all structs that implement ILeapNetEvent.
      var assembly = Assembly.GetExecutingAssembly();
      var types = assembly.GetTypes();
      Array.Sort(types, (a, b) => a.FullName.CompareTo(b.FullName));
      foreach (var type in types) {
        if (type.ImplementsInterface(typeof(ILeapNetEvent))) {
          if (type.IsValueType) {
            if (!type.ContainsGenericParameters) {
              RegisterNetEventType(type);
            }
            else {
              // Debug.Log("Unable to cache type hint for " + type + "; because its " +
              //   "types are not fully specified. The subsystem that declared it will " +
              //   "need to call CacheTypeHintForType for any fully-type-qualified events " +
              //   "it seeks to be able to send and receive.");
            }
          }
        }
      }

      Debug.Log("Largest event type is " + _largestType + " at " +
        _largestTypeSize + " bytes.");
    }

    /// <summary>
    /// Copies the bytes of the passed Network Event struct into the bytes array.
    /// Returns the number of bytes filled from the event.
    /// </summary>
    public static int FillBytes<T>(T networkEvent, byte[] bytes, int offset = 0)
                                   where T : struct, ILeapNetEvent {
      return FillBytes(networkEvent, bytes, ref offset);
    }

    /// <summary>
    /// Copies the bytes of the passed Network Event struct into the bytes array
    /// at the argument offset. Returns the number of bytes filled from the
    /// event.
    /// </summary>
    public static int FillBytes<T>(T networkEvent, byte[] bytes,
                                   ref int offset)
                                   where T : struct, ILeapNetEvent {
      var numEventBytes = Marshal.SizeOf<T>();
      //Debug.Log("FillBytes: for " + typeof(T) + " size is " + numEventBytes);
      
      if (offset + numEventBytes > bytes.Length) {
        throw new System.Exception("Can't FillBytes with type " +
          typeof(T).ToString() + ". It's " + numEventBytes + " long. Byte array " +
          "is length " + bytes.Length + " and starting offset is " + offset);
      }

      // MarshalCache method.
      // !DANGER! This method causes memory corruption!!
      // Kept here because it _did_ avoid allocating compared to PtrToStructure.
      // Arguably the best method is just to byte the bullet and serialize
      // classes like everybody else, but potentially this method can be
      // salvaged with some more research.
      // MarshalCache<T>.instance.value[0] = networkEvent;
      // GCHandle src = GCHandle.Alloc(MarshalCache<T>.instance.value,
      //   GCHandleType.Pinned);
      // try {
      //   Marshal.Copy(src.AddrOfPinnedObject(), bytes, offset, numEventBytes);
      // }
      // finally {
      //   src.Free();
      // }

      // StructureToPtr method.
      IntPtr handle = Marshal.AllocHGlobal(numEventBytes);
      try {
        Marshal.StructureToPtr(networkEvent, handle, true);
        Marshal.Copy(handle, bytes, offset, numEventBytes);
      }
      finally {
        Marshal.FreeHGlobal(handle);
      }

      offset += numEventBytes;
      return numEventBytes;
    }

    /// <summary>
    /// Reads the bytes of the data into a Network Event struct from the input
    /// array starting at the offset argument.
    ///
    /// Won't work very well (or at all!) if you don't pass it bytes gotten
    /// directly from a FillBytes call.
    /// </summary>
    public static T ReadBytes<T>(byte[] bytes) where T: struct {
      return ReadBytes<T>(bytes, 0);
    }

    /// <summary>
    /// Reads the bytes of the data into a Network Event struct from the input
    /// array starting at the offset argument.
    ///
    /// Won't work very well (or at all!) if you don't pass it bytes gotten
    /// directly from a FillBytes call.
    /// </summary>
    public static T ReadBytes<T>(byte[] bytes, int offset) where T: struct {
      return ReadBytes<T>(bytes, ref offset);
    }

    // TODO: DELETEME -- old MarshalCache method, caused BAD corruption
    // private class MarshalCache<T> where T: struct {
    //   [NonSerialized, ThreadStatic] private static MarshalCache<T>
    //     _backingInstance;
    //   public static MarshalCache<T> instance {
    //     get {
    //       if (_backingInstance == null) {
    //         _backingInstance = new MarshalCache<T>() {
    //           value = new T[] { default(T) },
    //         };
    //       }
    //       return _backingInstance;
    //     }
    //   } 

    //   public T[] value;
    // }
    
    /// <summary>
    /// Reads the bytes of the data into a Network Event struct from the input
    /// array starting at the offset argument.
    ///
    /// Won't work very well (or at all!) if you don't pass it bytes gotten
    /// directly from a FillBytes call.
    /// </summary>
    public static T ReadBytes<T>(byte[] bytes, ref int offset)
      where T: struct
    {
      var numEventBytes = Marshal.SizeOf<T>();
      //Debug.Log("ReadBytes: for " + typeof(T) + " size is " + numEventBytes);

      if (offset + numEventBytes > bytes.Length) {
        throw new System.Exception("Can't ReadBytes to type " +
          typeof(T).ToString() + ". It's " + numEventBytes + " long. Byte array " +
          "is length " + bytes.Length + " and starting offset is " + offset);
      }

      // MarshalCache method.
      // !DANGER! This method causes memory corruption!!
      // Kept here because it _did_ avoid allocating compared to PtrToStructure.
      // Arguably the best method is just to byte the bullet and serialize
      // classes like everybody else, but potentially this method can be
      // salvaged with some more research.
      // var result = MarshalCache<T>.instance.value;
      // var handle = GCHandle.Alloc(result, GCHandleType.Pinned);
      // try {
      //   Marshal.Copy(bytes, offset, handle.AddrOfPinnedObject(), numEventBytes);
      // }
      // finally {
      //   handle.Free();
      // }
      //offset += numEventBytes;
      // return result[0];

      // PtrToStructure method.
      var result = default(T);
      IntPtr handle = Marshal.AllocHGlobal(numEventBytes);
      try {
        Marshal.Copy(bytes, offset, handle, numEventBytes);
        result = Marshal.PtrToStructure<T>(handle);
      }
      finally {
        Marshal.FreeHGlobal(handle);
      }
      offset += numEventBytes;
      return result;
    }

    /// <summary>
    /// Gets the event code associated with the argument network event type.
    /// Throws a KeyNotFoundException if the type is not found.
    /// Network event codes are auto-filled if the struct is marked
    /// INetworkEvent.
    /// </summary>
    public static int GetEventCodeForType(Type networkEventType) {
      return _typesToCodesMap[networkEventType];
    }

    /// <summary>
    /// Gets the event type associated with the argument network event code.
    /// Throws a KeyNotFoundException if the code is not found.
    /// Network event codes are auto-filled if the struct is marked
    /// INetworkEvent.
    /// </summary>
    public static Type GetEventTypeForCode(int eventCode) {
      return _codesToTypesMap[eventCode];
    }

    /// <summary>
    /// Gets the number of bytes required for the argument network event type.
    /// Throws a KeyNotFoundException if the type is not found.
    /// </summary>
    public static int GetEventSizeForType(Type networkEventType) {
      return _typesToSizesMap[networkEventType];
    }

    public static int GetLargestEventSize() {
      return LeapNetEvents.EVENT_CODE_SIZE + _largestTypeSize;
      // + _largestGenericTypeSize;
    }

    /// <summary>
    /// Writes the event code (an integer) for the given network event type to
    /// the byte array at the argument offset.
    /// </summary>
    public static void WriteEventCodeInt(Type networkEventType, byte[] bytes,
                                          int offset = 0) {
      WriteEventCodeInt(networkEventType, bytes, ref offset);
    }

    /// <summary>
    /// Writes the event code (an integer) for the given network event type to
    /// the byte array at the argument offset and increments the offset by the
    /// number of bytes written (4).
    /// </summary>
    public static void WriteEventCodeInt(Type networkEventType, byte[] bytes,
                                          ref int offset) {
      int eventCode;
      if (_typesToCodesMap.TryGetValue(networkEventType, out eventCode)) {
        BitConverterNonAlloc.GetBytes(_typesToCodesMap[networkEventType],
          bytes, offset);
        offset += 4;
      }
      else {
        Debug.LogError("No event code allocated for type: " + networkEventType);
        throw new System.Exception();
      }
    }

  }

}
