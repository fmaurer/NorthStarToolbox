using System;
using UnityEngine;

namespace Leap.Unity.Networking.Events {

  public class EventsPacket {

    public const int MTU_SAFE_SIZE = 400;
    public const int MULTI_TRANSMISSION_SIZE = MTU_SAFE_SIZE * 4;

    private byte[] _data;
    private int _writeOffset;
    private int _eventsCount;

    public int currentSize { get { return _writeOffset; } }
    public int eventsCount { get { return _eventsCount; } }
    public int currentCapacity { get { return _data.Length; } }
    public bool isEmpty { get { return _eventsCount == 0; } }

    public EventsPacket(byte[] dataBuffer) {
      this._data = dataBuffer;
      _writeOffset = 0;
      _eventsCount = 0;
    }

    public EventsPacket(int packetCapacity) {
      _data = new byte[packetCapacity];
      _writeOffset = 0;
      _eventsCount = 0;
    }

    public bool TryWriteEvent<T>(T networkEvent)
                                 where T : struct, ILeapNetEvent {
      try {
        LeapNetEvents.WriteEventCodeInt(typeof(T), _data, ref _writeOffset);
        LeapNetEvents.FillBytes(networkEvent, _data, ref _writeOffset);
        _eventsCount += 1;
        return true;
      }
      catch (System.Exception e) {
        Debug.LogError(e.ToString());
        return false;
      }
    }

    public bool TryWriteEvent(Type eventType, byte[] eventBytes) {
      try {
        WriteEvent(eventType, eventBytes);
        return true;
      }
      catch (System.Exception e) {
        Debug.LogError(e.ToString());
        return false;
      }
    }

    /// <summary>
    /// Throws an exception if the write fails. Returns the number of bytes
    /// written.
    /// </summary>
    public int WriteEvent(Type eventType, byte[] eventBytes,
                           int readOffset = 0) {
      var eventSize = LeapNetEvents.GetEventSizeForType(eventType);
      LeapNetEvents.WriteEventCodeInt(eventType, _data, ref _writeOffset);
      for (int i = 0; i < eventSize; i++) {
        _data[_writeOffset + i] = eventBytes[readOffset + i];
      }
      _writeOffset += eventSize;
      _eventsCount += 1;
      return eventSize;
    }

    public bool TryWriteEvent(GenericNetworkEvent genericEvent) {
      try {
        LeapNetEvents.WriteEventCodeInt(genericEvent.eventType, _data,
          ref _writeOffset);
          
        for (int i = 0; i < genericEvent.length; i++) {
          _data[i + _writeOffset] = genericEvent.bytes[i + genericEvent.offset];
        }
        _writeOffset += genericEvent.length;

        _eventsCount += 1;
        return true;
      }
      catch (System.Exception e) {
        Debug.LogError(e.ToString());
        Debug.LogError("Error in TryWriteEvent -- most likely ran out of space " +
          "in the packet.");
        return false;
      }
    }

    public void Clear() {
      for (int i = 0 ; i < _data.Length; i++) {
        _data[i] = 0;
      }
      _writeOffset = 0;
      _eventsCount = 0;
    }

    public byte[] GetBytes() {
      return _data;
    }

    public bool HasRemainingSpace(Type eventType) {
      var additionalBytes = LeapNetEvents.EVENT_CODE_SIZE +
        LeapNetEvents.GetEventSizeForType(eventType);
      return _writeOffset + additionalBytes < _data.Length;
    }

    public EventsPacket.Reader GetEnumerator() {
      return new EventsPacket.Reader(this);
    }
    public struct Reader {
      private byte[] _bytes;
      private int _readOffset;
      private GenericNetworkEvent _curGenericEvent;

      public Reader(EventsPacket eventsPacket) {
        _bytes = eventsPacket._data;
        _readOffset = 0;
        _curGenericEvent = default(GenericNetworkEvent);
      }
      public Reader(byte[] eventsPacketBytes) {
        _bytes = eventsPacketBytes;
        _readOffset = 0;
        _curGenericEvent = default(GenericNetworkEvent);
      }

      public Reader GetEnumerator() { return this; }
      public void Reset() {
        _readOffset = 0;
        _curGenericEvent = default(GenericNetworkEvent);
      }
      public bool MoveNext() {
        // Early return if there aren't enough bytes to consume the next code.
        if (_readOffset + LeapNetEvents.EVENT_CODE_SIZE >= _bytes.Length) {
          return false;
        }

        // Read the next integer as an event code.
        var code = BitConverterNonAlloc.ToInt32(_bytes, _readOffset);
        _readOffset += LeapNetEvents.EVENT_CODE_SIZE;

        // EventsPackets are null-terminated.
        if (code == LeapNetEvents.NULL_EVENT_CODE) {
          return false;
        }
        else {
          _curGenericEvent = new GenericNetworkEvent(code, _bytes,
            ref _readOffset);
          return true;
        }
      }
      public GenericNetworkEvent Current { get { return _curGenericEvent; } }
    }
  }

  public class EventsPacketPool {

  } 

}
