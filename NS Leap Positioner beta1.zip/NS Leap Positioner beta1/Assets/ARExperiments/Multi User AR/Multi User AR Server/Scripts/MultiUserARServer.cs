﻿// using System.Collections;
// using System.Collections.Generic;
// using System.Net;
// using System.Net.Sockets;
// using Leap.Unity.Attributes;
// using LiteNetLib;
// using UnityEngine;

// namespace Leap.Unity.Apps.MultiUserAR {

//   public class MultiUserARServer : MultiUserARNode {

//     private Dictionary<NetPeer, int> _peersToIdsMap =
//       new Dictionary<NetPeer, int>();
//     private Dictionary<int, NetPeer> _idsToPeersMap =
//       new Dictionary<int, NetPeer>();

//     private int _server_maxPlayerId = 1;
//     private Dictionary<int, EventsPacket> _server_playerEventsPackets =
//       new Dictionary<int, EventsPacket>();

//     private void OnEnable() {
//       Log("");
//       Log("====================");
//       Log("Multi User AR Server");
//       Log("====================");
//       Log("");

//       Log("Launching NetManager on port " + port + ".");
//       if (netManager == null) netManager = new NetManager(this);
//       netManager.Start(port);
//       netManager.DiscoveryEnabled = true;
//       Log("Application connection key is: " + applicationConnectionKey);
//       Log("");
//     }

//     private void OnDisable() {
//       Log("Server shutting down.");

//       if (netManager != null) {
//         netManager.Stop();
//       }
//     }

//     /// <summary>
//     /// Schedules an event to be sent to a specific player.
//     /// </summary>
//     public void ScheduleEvent<T>(int playerId, T networkEvent)
//                                  where T : struct, INetworkEvent {
//       // Get packet data so far for the given player ID.
//       EventsPacket eventsPacket;
//       if (!_playerEventsPackets.TryGetValue(playerId, out eventsPacket)) {
//         eventsPacket = new EventsPacket(EventsPacket.DEFAULT_PACKET_CAPACITY);
//         _playerEventsPackets[playerId] = eventsPacket;
//         Log("Created new events packet for player ID " + playerId);
//       }
//       Log("Writing event for player ID: " + playerId + " and event type " +
//         typeof(T).Name);
//       eventsPacket.TryWriteEvent(networkEvent);
//       Log("After attempt to write, events packet contains " +
//         eventsPacket.currentSize + " bytes and event count is " +
//         eventsPacket.eventsCount);
//     }

//     public void ScheduleEvent(int playerId, GenericNetworkEvent genericEvent) {
//       // Get packet data so far for the given player ID.
//       EventsPacket eventsPacket;
//       if (!_playerEventsPackets.TryGetValue(playerId, out eventsPacket)) {
//         eventsPacket = new EventsPacket(EventsPacket.DEFAULT_PACKET_CAPACITY);
//         _playerEventsPackets[playerId] = eventsPacket;
//         Log("Created new events packet for player ID " + playerId);
//       }
//       Log("Writing event for player ID: " + playerId + " and event type " +
//         genericEvent.eventType.Name);
//       eventsPacket.TryWriteEvent(genericEvent);
//       Log("After attempt to write, events packet contains " +
//         eventsPacket.currentSize + " bytes and event count is " +
//         eventsPacket.eventsCount);
//     }

//     /// <summary>
//     /// Schedules an event to be sent to all players. Optionally include a
//     /// player ID to exclude.
//     /// </summary>
//     public void ScheduleEvent<T>(T networkEvent, int? excludePlayerId = null)
//                                  where T : struct, INetworkEvent {
//       foreach (var idPeerPair in _connectedPlayers) {
//         var playerId = idPeerPair.Key;
//         if (!excludePlayerId.HasValue || excludePlayerId.Value != playerId) {
//           ScheduleEvent<T>(playerId, networkEvent);
//         }
//       }
//     }

//     public void ScheduleEvent(GenericNetworkEvent genericEvent,
//                               int? excludePlayerId = null) {
//       foreach (var idPeerPair in _connectedPlayers) {
//         var playerId = idPeerPair.Key;
//         if (!excludePlayerId.HasValue || excludePlayerId.Value != playerId) {
//           ScheduleEvent(playerId, genericEvent);
//         }
//       }
//     }

//     private void Update() {
//       netManager.PollEvents();
//     }

//     private void LateUpdate() {
//       // The server accumulates events packets per-player. Non-empty packets
//       // (from calls to ScheduleEvent) are flushed every LateUpdate.
//       foreach (var idEventsPair in _playerEventsPackets) {
//         var playerId = idEventsPair.Key;
//         var eventsPacket = idEventsPair.Value;

//         if (!eventsPacket.isEmpty) {
//           var peer = _connectedPlayers[playerId];
//           peer.Send(eventsPacket.GetBytes(), DeliveryMethod.Unreliable);
//           eventsPacket.Clear();
//           Log("Sent events packet to player ID " + playerId + ".");
//         }
//       }
//     }

//     public override void OnNetworkReceive(NetPeer peer, NetPacketReader reader,
//                                           DeliveryMethod deliveryMethod) {
//       // Do normal routing for event handlers.
//       base.OnNetworkReceive(peer, reader, deliveryMethod);

//       // Special routing: Per event, forward the event to the other connected
//       // players.
//       // TODO: It's likely that we should specify whether events are intended
//       // just for the server or to be forward or etc. via different interfaces
//       // on data structs.
//       // e.g. instead of INetworkEvent, it can be INetworkDataEvent or
//       // INetworkSyncEvent -- contrasted with something like
//       // INetworkLogisticsEvent for messaging intended for the server only.
//       var playerId = _peersToIdsMap[peer];
//       Log("Mirroring event(s) to all players except player " + playerId + ".");
//       reader.GetBytes(_eventsBuffer, 0, reader.AvailableBytes);
      
//       foreach (var idPeerPair in _connectedPlayers) {
//         var otherPlayerId = idPeerPair.Key;
//         var otherPeer = idPeerPair.Value;
//         if (otherPlayerId != playerId) {
//           otherPeer.Send(_eventsBuffer, DeliveryMethod.Unreliable);
//         }
//       }
//       // foreach (var genericEvent in new EventsPacket.Reader(_eventsBuffer)) {
//       //   ScheduleEvent(genericEvent, excludePlayerId: playerId);
//       // }
//     }

//     public override void OnConnectionRequest(ConnectionRequest request) {
//       request.AcceptIfKey(applicationConnectionKey);
//     }

//     public override void OnPeerConnected(NetPeer peer) {
//       Log("Peer connected: " + peer + ". This peer will receive player ID " +
//         _maxPlayerId + ".");

//       var newPlayerId = _maxPlayerId;
//       _maxPlayerId += 1;
        
//       _connectedPlayers[newPlayerId] = peer;
//       _peersToIdsMap[peer] = newPlayerId;

//       var assignPlayerIdEvent = new ServerAssignPlayerIdEvent() {
//         playerId = newPlayerId
//       };
//       ScheduleEvent(newPlayerId, assignPlayerIdEvent);

//       // Since a new peer joined, announce all connected players.
//       scheduleAnnouncePlayersEvent();
//     }

//     private int[] _announcePlayerIdsCache = null;
//     /// <summary>
//     /// Schedules a broadcast to all players with the latest set of player IDs.
//     /// This drives spawning and despawning players on clients.
//     /// </summary>
//     private void scheduleAnnouncePlayersEvent() {
//       if (_announcePlayerIdsCache == null) {
//         _announcePlayerIdsCache = new int[MAX_PLAYER_COUNT];
//       }
//       var announcePlayersEvent =
//         new ServerAnnouncePlayersEvent(_connectedPlayers.Count,
//           _announcePlayerIdsCache);
//       var idIndex = 0;
//       foreach (var idPeerPair in _connectedPlayers) {
//         announcePlayersEvent.playerIds[idIndex++] = idPeerPair.Key;
//       }
//       ScheduleEvent<ServerAnnouncePlayersEvent>(announcePlayersEvent);
//     }

//     public override void OnPeerDisconnected(NetPeer peer,
//                                             DisconnectInfo disconnectInfo) {
//       Log("Peer disconnected: " + peer.EndPoint +
//         "\n Disconnect reason: " + disconnectInfo.Reason);
      
//       var playerId = _peersToIdsMap[peer];
//       _connectedPlayers.Remove(playerId);
//       _peersToIdsMap.Remove(peer);
//       _playerEventsPackets.Remove(playerId);

//       // Since a peer disconnected, announce all connected players.
//       // Spawn managers will receive despawn calls for any missing players.
//       scheduleAnnouncePlayersEvent();
//     }

//     public override void OnNetworkError(IPEndPoint endPoint,
//                                         SocketError socketError) {
//       LogError("Network error at endpoint: " + endPoint +
//         "\nSocket error: " + socketError);
//     }

//     public override void OnNetworkReceiveUnconnected(
//                            IPEndPoint remoteEndPoint,
//                            NetPacketReader reader,
//                            UnconnectedMessageType messageType) {
//       if (messageType == UnconnectedMessageType.DiscoveryRequest) {
//         netManager.SendDiscoveryResponse(new byte[] {1}, remoteEndPoint);
//       }
//     }

//     public override void OnNetworkLatencyUpdate(NetPeer peer, int latency) {
//       // Debug.Log("Got a latency update for peer: " + peer + 
//       //   "\nNew latency: " + latency);
//     }
    
//   }

// }
