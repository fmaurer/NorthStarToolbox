﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
using System.IO;
using Leap.Unity.Attributes;
using UnityEngine.UI;

using SimpleJSON;

namespace Leap.Unity.AR
{
    using Pose = Leap.Unity.Pose;

    public class LeapPositionManager : MonoBehaviour
    {

        [Tooltip("This is a folder in StreamingAssets where calibrations are kept.")]
        public StreamingFolder calibrationsFolder;

        public InputField calibrtaionFileName;

        public OpticalCalibrationManager calibrationManager;

        // Use this for initialization
        void Start()
        {
            calibrtaionFileName.text = calibrationManager.inputCalibrationFile;
            LoadCalibration();

        }

        // Update is called once per frame
        void Update()
        {

        }

        
        /// <summary>
        /// The name of the calibration file to load if LoadCalibration() is called.
        /// (Read only.)
        /// </summary>
        public string inputCalibrationFile
        {
            get
            {
                return calibrtaionFileName.text;
            }
        }

        /// <summary>
        /// The path of the calibration file to load if LoadCalibration() is called.
        /// (Read only.)
        /// </summary>
        public string inputFilePath
        {
            get
            {
                return Path.Combine(calibrationsFolder.Path, inputCalibrationFile);
            }
        }

        /// <summary>
        /// The destination file path of the calibration file if SaveCurrentCalibration() is
        /// called. (Read only.)
        /// </summary>
        public string outputFilePath
        {
            get
            {
                int randomNumber = UnityEngine.Random.Range(0, 10000);

                return Path.Combine(calibrationsFolder.Path, randomNumber+"_"+inputCalibrationFile);
            }
        }

        public Transform leapPosition;
        public Transform headsetTransform;

        SimpleJSON.JSONObject rawConfigFile;
        bool hasLoaded = false;

        public void UpdateCalibrationManually(Vector3 pos, Quaternion rot, bool updateUI = true)
        {
            //if (hasLoaded)
            //{
                headsetTransform.parent = leapPosition.parent;

                leapPosition.localPosition = pos;
                leapPosition.localRotation = rot;

                headsetTransform.parent = leapPosition;

                if (updateUI)
                {

                    GetComponent<LeapPoseManagerUIController>().UpdateUIElements(pos, rot); //needed because don't know if updated sliders or updated input fields, keeps things synced
                }
            //}
            /*else
            {
                Debug.Log("haven't loaded a valid calibration file yet");
            }
            */
            
        }

        public void SaveCalibration()
        {

            Vector3 lastPos = new Vector3(rawConfigFile["leapTracker"]["localPose"]["position"]["x"], rawConfigFile["leapTracker"]["localPose"]["position"]["y"], rawConfigFile["leapTracker"]["localPose"]["position"]["z"]);
            Quaternion lastRot = new Quaternion(rawConfigFile["leapTracker"]["localPose"]["rotation"]["x"], rawConfigFile["leapTracker"]["localPose"]["rotation"]["y"], rawConfigFile["leapTracker"]["localPose"]["rotation"]["z"], rawConfigFile["leapTracker"]["localPose"]["rotation"]["w"]);
            //calibrationManager.MovePositionsFromLast(lastPos);
            //calibrationManager.MoveRotationsFromLast(lastRot);
            calibrationManager.UpdateCalibrationFromObjects();
            calibrationManager.SaveCurrentCalibration();

        }


        public void SaveCalibation_DEPRECATED()
        {

            //problem is everything is defined relative to Leap position so this doesn't work

            rawConfigFile["leapTracker"]["localPose"]["position"]["x"] = leapPosition.localPosition.x;
            rawConfigFile["leapTracker"]["localPose"]["position"]["y"] = leapPosition.localPosition.y;
            rawConfigFile["leapTracker"]["localPose"]["position"]["z"] = leapPosition.localPosition.z;            

            rawConfigFile["leapTracker"]["localPose"]["rotation"]["x"] = leapPosition.localRotation.x;
            rawConfigFile["leapTracker"]["localPose"]["rotation"]["y"] = leapPosition.localRotation.y;
            rawConfigFile["leapTracker"]["localPose"]["rotation"]["z"] = leapPosition.localRotation.z;
            rawConfigFile["leapTracker"]["localPose"]["rotation"]["w"] = leapPosition.localRotation.w;


            var outputPath = outputFilePath;
            using (FileStream fs = new FileStream(outputPath, FileMode.Create))
            {
                using (StreamWriter writer = new StreamWriter(fs))
                {
                    writer.Write(rawConfigFile.ToString(4));

                    Debug.Log("Saved current calibration to: " + outputPath);
                }
            }
        }

        /// <summary>
        /// Loads the calibration file specified by the inputCalibrationFile field, which
        /// </summary>
        /// 
        public void LoadCalibration()
        {
            bool disableEllipsoids = true;
            bool ignoreConfig = false;

            if (!Application.isPlaying)
            {
                Debug.LogError("For safety, calibrations cannot be loaded at edit-time. "
                             + "Enter play mode to load a calibration.", this);
                return;
            }

            if (string.IsNullOrEmpty(inputCalibrationFile))
            {
                Debug.LogError("inputCalibrationFile field is null or empty; cannot load "
                             + "a calibration file.", this);
            }

            var pathToLoad = inputFilePath;

            /*
            // Check command line args for an override.
            // Scan command line environments for a headset calibration file
            // and set that as the input file if found.
            var commandLineArgs = System.Environment.GetCommandLineArgs();
            var useCalibrationRegEx =
              new System.Text.RegularExpressions.Regex(CALIBRATION_ARG_REGEX);
            var calibrationOverrideFile = "";
            bool foundMatch = false;
            bool wasValidMatch = false;
            foreach (var arg in commandLineArgs)
            {
                var match = useCalibrationRegEx.Match(arg);
                if (match.Groups.Count > 1 && match.Groups[1].Captures.Count > 0)
                {
                    calibrationOverrideFile = match.Groups[1].Captures[0].Value;
                    Debug.Log("Loading use_calibration arg: " + calibrationOverrideFile);
                    foundMatch = true;

                    wasValidMatch = TryLoadCalibrationFromPath(calibrationOverrideFile);
                }
            }
            if (foundMatch)
            {
                if (!wasValidMatch)
                {
                    Debug.LogError("Failed to load " + calibrationOverrideFile);
                }
                else
                {
                    pathToLoad = calibrationOverrideFile;
                }
            }

            // Check the config.json file for ANOTHER override. We can probably remove
            // the command flag override now.
            if (!ignoreConfig)
            {
                if (Config.TryRead<string>("northStarCalibration",
                                           ref inputCalibrationFile))
                {
                    Path.ChangeExtension(inputCalibrationFile, ".json");
                    pathToLoad = inputFilePath; // Reload the file path.
                    Debug.Log("Set input calibration to " + inputCalibrationFile +
                      " from config.json.");
                }
            }*/

            TryLoadCalibrationFromPath(pathToLoad, disableEllipsoids);
        }


        public bool TryLoadCalibrationFromPath(string inputFilePath,
                                               bool disableEllipsoids = true)
        {
            var inputFile = inputFilePath;

            if (File.Exists(inputFile))
            {
                Debug.Log("loading: " + inputFilePath);
                //read file into String, parseJSON
                StreamReader reader = new StreamReader(inputFile);

                rawConfigFile = (SimpleJSON.JSONObject) JSON.Parse(reader.ReadToEnd());

                //Debug.Log(reader.ReadToEnd());
                reader.Close();

                Debug.Log(rawConfigFile.GetType());

                //update UI elements: -inputfields, sliders, gameobject

                float localX = rawConfigFile["leapTracker"]["localPose"]["position"]["x"];
                float localY = rawConfigFile["leapTracker"]["localPose"]["position"]["y"];
                float localZ = rawConfigFile["leapTracker"]["localPose"]["position"]["z"];

                Vector3 loadedPosition = new Vector3(localX, localY, localZ);
                Debug.Log(loadedPosition);
                float rx = rawConfigFile["leapTracker"]["localPose"]["rotation"]["x"];
                float ry = rawConfigFile["leapTracker"]["localPose"]["rotation"]["y"];
                float rz = rawConfigFile["leapTracker"]["localPose"]["rotation"]["z"];
                float rw = rawConfigFile["leapTracker"]["localPose"]["rotation"]["w"];

                Quaternion loadedRotation = new Quaternion(rx,ry,rz,rw);
                Debug.Log(loadedRotation);

                UpdateCalibrationManually(loadedPosition, loadedRotation, true);

                hasLoaded = true;

                /*=====================

        string calibrationData = File.ReadAllText(inputFile);
        currentCalibration = JsonUtility.FromJson<HeadsetCalibration>(calibrationData);
        provider.deviceOrigin.localPosition = currentCalibration.leapTracker.localPose.position;
        provider.deviceOrigin.localRotation = currentCalibration.leapTracker.localPose.rotation;

        provider.deviceOrigin.SetLocalPose(currentCalibration.leapTracker.localPose);
        if (leftEye != null)
        {
            leftEye.eyePerspective.transform.localPosition = currentCalibration.leftEye.eyePosition;
            leftEyeProjectionParams = currentCalibration.leftEye.cameraProjection;
            if (leftEye.ellipse != null)
            {
                if (disableEllipsoids) leftEye.ellipse.enabled = false;
                leftEye.ellipse.MinorAxis = currentCalibration.leftEye.ellipseMinorAxis;
                leftEye.ellipse.MajorAxis = currentCalibration.leftEye.ellipseMajorAxis;
                leftEye.ellipse.sphereToWorldSpace = currentCalibration.leftEye.sphereToWorldSpace;
                leftEye.ellipse.worldToSphereSpace = currentCalibration.leftEye.sphereToWorldSpace.inverse;
            }
            if (leftEye.Screen != null)
            {
                Matrix4x4 screenTransform = currentCalibration.leftEye.worldToScreenSpace.inverse;
                leftEye.Screen.position = provider.transform.parent.TransformPoint(screenTransform.GetVector3());
                leftEye.Screen.rotation = provider.transform.parent.rotation * screenTransform.GetQuaternion();
                leftEye.Screen.localScale = screenTransform.lossyScale;
            }
        }
        if (rightEye != null)
        {
            rightEye.eyePerspective.transform.localPosition = currentCalibration.rightEye.eyePosition;
            rightEyeProjectionParams = currentCalibration.rightEye.cameraProjection;
            if (rightEye.ellipse != null)
            {
                if (disableEllipsoids) rightEye.ellipse.enabled = false;
                rightEye.ellipse.MinorAxis = currentCalibration.rightEye.ellipseMinorAxis;
                rightEye.ellipse.MajorAxis = currentCalibration.rightEye.ellipseMajorAxis;
                rightEye.ellipse.sphereToWorldSpace = currentCalibration.rightEye.sphereToWorldSpace;
                rightEye.ellipse.worldToSphereSpace = currentCalibration.rightEye.sphereToWorldSpace.inverse;
            }
            if (rightEye.Screen != null)
            {
                Matrix4x4 screenTransform = currentCalibration.rightEye.worldToScreenSpace.inverse;
                rightEye.Screen.position = provider.transform.parent.TransformPoint(screenTransform.GetVector3());
                rightEye.Screen.rotation = provider.transform.parent.rotation * screenTransform.GetQuaternion();
                rightEye.Screen.localScale = screenTransform.lossyScale;
            }
        }

        ARRaytracer[] raytracers = GetComponentsInChildren<ARRaytracer>();
        foreach (ARRaytracer raytracer in raytracers)
        {
            raytracer.ScheduleCreateDistortionMesh();
        }

        Debug.Log("Headset calibration successfully loaded from " + inputCalibrationFile);

        return true;
        }
        else
        {
        currentCalibration.leapTracker = new PhysicalComponent(provider.deviceOrigin.ToWorldPose(), provider.gameObject.name);
        if (leftEye != null && leftEye.ellipse != null &&
            leftEye.Screen != null)
        {
            currentCalibration.leftEye = constructLeftEyeOptics();
        }
        if (rightEye != null && rightEye.ellipse != null &&
            rightEye.Screen != null)
        {
            currentCalibration.rightEye = constructRightEyeOptics();
        }
        Debug.LogWarning("No calibration exists for: " + inputFile +
          "; no calibration was loaded.");

        return false;
        }

        ============*/
            }
            return false;
        }
    }
}