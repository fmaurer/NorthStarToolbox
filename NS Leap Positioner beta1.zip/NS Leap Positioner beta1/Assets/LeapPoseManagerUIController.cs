﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class LeapPoseManagerUIController : MonoBehaviour {

    public InputField xPosition;
    public InputField yPosition;
    public InputField zPosition;
    public InputField xRotation;
    public InputField yRotation;
    public InputField zRotation;

    public Slider xPositionSlider;
    public Slider yPositionSlider;
    public Slider zPositionSlider;
    public Slider xRotationSlider;
    public Slider yRotationSlider;
    public Slider zRotationSlider;

    bool needsUpdate = false;
    Vector3 pos = Vector3.zero;
    Quaternion rot = Quaternion.identity;

    // Use this for initialization
    void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
        if(needsUpdate){
            GetComponent<Leap.Unity.AR.LeapPositionManager>().UpdateCalibrationManually(pos, rot, true);
            needsUpdate = false;
        }
    }

    public void UpdateUIElements(Vector3 pos, Quaternion rot)
    {
        xPosition.text = pos.x.ToString();
        yPosition.text = pos.y.ToString();
        zPosition.text = pos.z.ToString();
        xPositionSlider.value = pos.x;
        yPositionSlider.value = pos.y;
        zPositionSlider.value = pos.z;

        xRotation.text = rot.eulerAngles.x.ToString();
        yRotation.text = rot.eulerAngles.y.ToString();
        zRotation.text = rot.eulerAngles.z.ToString();
        xRotationSlider.value = rot.eulerAngles.x;
        yRotationSlider.value = rot.eulerAngles.y;
        zRotationSlider.value = rot.eulerAngles.z;

        Canvas.ForceUpdateCanvases();
    }

    void ToggleOnChangeEvent(bool isenabled)
    {
    }

    public void UpdateCalibrationFromSliders()
    {
        pos = new Vector3(xPositionSlider.value, yPositionSlider.value, zPositionSlider.value);
        rot = Quaternion.Euler(xRotationSlider.value, yRotationSlider.value, zRotationSlider.value);

        //Debug.Log(rot);
        //Debug.Log(pos);
        needsUpdate = true;

    }

    public void UpdateCalibrationFromInputFields()
    {

        float number1,number2,number3;
        bool result1 = float.TryParse(xPosition.text, out number1);
        bool result2 = float.TryParse(yPosition.text, out number2);
        bool result3 = float.TryParse(zPosition.text, out number3);

        if(result1 && result2 && result3)
        {
            pos = new Vector3(float.Parse(xPosition.text), float.Parse(yPosition.text), float.Parse(zPosition.text));
            needsUpdate = true;
        }

        result1 = float.TryParse(xRotation.text, out number1);
        result2 = float.TryParse(yRotation.text, out number2);
        result3 = float.TryParse(zRotation.text, out number3);

        if (result1 && result2 && result3)
        {
            rot = Quaternion.Euler(float.Parse(xRotation.text), float.Parse(yRotation.text), float.Parse(zRotation.text));
            needsUpdate = true;
        }

    }

}
