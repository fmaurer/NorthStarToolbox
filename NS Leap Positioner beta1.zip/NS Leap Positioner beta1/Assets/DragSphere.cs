﻿using UnityEngine;
public class DragSphere : MonoBehaviour
{
    public Transform toFollow;
    private Transform lookAt;
    Quaternion lockedTo;
    private float rotationLerpSpeed = 1;
    public float confusionDiameter = 0.008f;
    private float positionLerpSpeed = 1;

    private bool extrapolatePos = true;
    private float extrapolationFactor = 1;

    private Vector3 lastPosition = Vector3.zero;
    private Quaternion lastRotation = Quaternion.identity;
    private float RotateSmoothTime = 0.1f;
    private bool extrapolateRot = true;
    AverageValues avgX, avgY, avgZ, avgRX, avgRY, avgRZ;

    private Vector3 newRotValues;
    private Vector3 oldRotValues;
    public float confusionRotAngles = 0.2f;

    private void Start()
    {
        lockedTo = Quaternion.identity;

        avgX = new AverageValues();
        avgY = new AverageValues();
        avgZ = new AverageValues();

        avgRX = new AverageValues();
        avgRY = new AverageValues();
        avgRZ = new AverageValues();


        oldRotValues = toFollow.transform.rotation.eulerAngles;

    }

    void OnDrawGizmos()
    {
        if (Application.isPlaying)
        {
           /* Gizmos.color = Color.cyan;
            Vector3 projectPlanePt = Vector3.ProjectOnPlane(transform.position, Vector3.up);
            Gizmos.DrawSphere(projectPlanePt, 0.02f);
            Vector3 projectPlanePt2 = Vector3.ProjectOnPlane(transform.position, Vector3.right);
            Gizmos.DrawSphere(projectPlanePt2, 0.02f);
            Gizmos.color = Color.green;
            Vector3 hatProjectionPos = new Vector3(projectPlanePt.x, projectPlanePt2.y, projectPlanePt.z);
            Gizmos.DrawSphere(hatProjectionPos, 0.02f);
            */
        }
    }

    void Update()
    {

        /*
        avgX.NewValue = toFollow.position.x;
        avgY.NewValue = toFollow.position.y;
        avgZ.NewValue = toFollow.position.z;

        avgRX.NewValue = toFollow.rotation.eulerAngles.x;
        avgRY.NewValue = toFollow.rotation.eulerAngles.y;
        avgRZ.NewValue = toFollow.rotation.eulerAngles.z;
        

        if (Input.GetKeyUp(KeyCode.E))
        {
            extrapolatePos = !extrapolatePos;
            extrapolateRot = !extrapolateRot;
        }
        */
        //confusionDiameter = 0.08f;
        float distance = Vector3.Distance(toFollow.position, transform.localPosition);
        if (distance > confusionDiameter / 2f)
        {
            Vector3 newPos = transform.localPosition + ((toFollow.position - transform.localPosition).normalized * (distance - confusionDiameter / 2));
            //if(avgX.isValid)
            //{
            //lastPosition = new Vector3(avgX.movingAverage, avgY.movingAverage, avgZ.movingAverage);

            //}
            transform.localPosition = newPos;
            /*
            =========================

            Vector3 lastVel = (newPos - lastPosition) / Time.deltaTime;
            //Vector3 lastVel = (newPos - new Vector3(avgX.movingAverage, avgY.movingAverage, avgZ.movingAverage)) / Time.deltaTime ;
            Vector3 extrapolatedPos = newPos + ((lastVel) * Time.deltaTime *extrapolationFactor);
            //Debug.Log(lastVel.magnitude);
            if(lastVel.sqrMagnitude > 0 && extrapolatePos) {
                //extrapolated position:
                //transform.localPosition = Vector3.Lerp(transform.localPosition, extrapolatedPos, positionLerpSpeed*Time.smoothDeltaTime);

                transform.localPosition = Vector3.SmoothDamp(transform.localPosition, newPos, ref lastVel,Time.smoothDeltaTime);
            } else
            {
            //Smoothed position:
                transform.localPosition = Vector3.Lerp(transform.localPosition, newPos, positionLerpSpeed*Time.smoothDeltaTime);
            }
            lastPosition = newPos;
            //===============================

            */

            //Non smoothed (raw) value:
            //transform.position += (toFollow.position - transform.position).normalized * (distance - confusionDiameter/2);
        }
        else
        {
            //transform.position += (toFollow.position - transform.position) * 0.0002f;
        }

        //transform.rotation = Constraints.ConstrainRotationToConeWithTwist(toFollow.rotation, toFollow.rotation*Vector3.right, toFollow.rotation*Vector3.forward, 10, 20f);

        //transform.localRotation = Quaternion.Euler(RoundAngleToNearestFifth(toFollow.rotation.eulerAngles.x), RoundAngleToNearestFifth(toFollow.rotation.eulerAngles.y), RoundAngleToNearestFifth(toFollow.rotation.eulerAngles.z));

        //transform.localRotation = toFollow.rotation;


        /* ---- rotation from camera
         * if (Approximately(lockedTo, toFollow.rotation, .0000005f))
        {
            transform.rotation = Quaternion.Lerp(transform.rotation,toFollow.rotation,Time.deltaTime*rotationLerpSpeed); 
        }
        else
        {
            transform.rotation = toFollow.rotation;
            lockedTo = transform.rotation;
        }*/

        //rotation from other object
        if(lookAt)
        {
           // transform.rotation = Quaternion.LookRotation((lookAt.position - transform.position), Vector3.up);
            //Quaternion newQuat = Quaternion.Inverse(Quaternion.LookRotation(Vector3.zero - transform.position));
            //transform.rotation = newQuat;
        }

    //     public Transform Target;
    //float RotateSmoothTime = 0.1f;
        float AngularVelocity = 0.0f;

        //https://answers.unity.com/questions/390291/is-there-a-way-to-smoothdamp-a-lookat.html

        //replace with last rotation + current
        //var target_rot = Quaternion.LookRotation(Target.position - transform.position);

        /*

        Quaternion target_rot = toFollow.rotation;
        if (avgRX.isValid)
        {
            Debug.Log("fine");
            lastRotation = Quaternion.Euler(avgRX.movingAverage, avgRY.movingAverage, avgRZ.movingAverage);
        }
        var delta = Quaternion.Angle(transform.rotation, lastRotation);

        if (delta > 0f && extrapolateRot)
        {

            Quaternion lastAngularStep = target_rot * Quaternion.Inverse(lastRotation);
            lastRotation = target_rot * lastAngularStep * lastAngularStep * lastAngularStep * lastAngularStep * lastAngularStep; //storing and using for next time, this is the extrapolated rotation
            var t = Mathf.SmoothDampAngle(delta, 0.0f, ref AngularVelocity, RotateSmoothTime);
            t = 1.0f - t / delta;
            transform.localRotation = Quaternion.Slerp(transform.localRotation, lastRotation, t* rotationLerpSpeed);
            //transform.localRotation = Quaternion.Slerp(transform.localRotation, lastRotation, Time.smoothDeltaTime * rotationLerpSpeed);

        }
        else
        {
            transform.localRotation = target_rot;
        }
        lastRotation = target_rot;


    */

        //transform.localRotation = Quaternion.

        //transform.localRotation = toFollow.rotation;
        //transform.rotation = Quaternion.Lerp(transform.rotation, toFollow.rotation, Time.deltaTime * rotationLerpSpeed);

        //Instead, drag sphere equivalent for rotation:
        newRotValues = toFollow.eulerAngles;
        oldRotValues = DragSphereEulerAngles(newRotValues, oldRotValues, confusionRotAngles);
        transform.localRotation = Quaternion.Euler(oldRotValues);
        //transform.localRotation = Quaternion.Slerp(Quaternion.Euler(newRotValues), Quaternion.Euler(oldRotValues),Time.smoothDeltaTime);
        //oldRotValues = newRotValues;
    }

    private Vector3 DragSphereEulerAngles(Vector3 newAngles, Vector3 oldAngles, float confusionValue)
    {
        float dragged_x = OneDimensionalDragFilter(newAngles[0], oldAngles[0], confusionValue);
        float dragged_y = OneDimensionalDragFilter(newAngles[1], oldAngles[1], confusionValue);
        float dragged_z = OneDimensionalDragFilter(newAngles[2], oldAngles[2], confusionValue);

        return new Vector3(dragged_x, dragged_y, dragged_z);
    }

    private float OneDimensionalDragFilter(float newValue, float oldValue, float confusionValue)
    {
        //calc distance to new point
        //check if distance greater than confusion diameter
        //if true, update position by distance - confusionDiameter/2
        float distance = newValue - oldValue;
        //float distance = Mathf.MoveTowardsAngle(oldValue, newValue, 180);
        if (Mathf.Abs(distance) > confusionValue / 2)
        {
            if (distance > 0)
            {
                return oldValue + (distance - confusionValue / 2);
            }
            else
            {
                return oldValue + (distance + confusionValue / 2);

            }

        }

        return oldValue;
    }

    public static bool Approximately(Quaternion val, Quaternion about, float range)
    {
        return Quaternion.Dot(val, about) > 1 - range;
    }

    private float RoundAngleToNearestFifth(float angle)
    {

        float tempF = (Mathf.Floor((angle * 100) / 8) * 8) / 100;

        //return tempF;
        return angle;
    }



}

public class AverageValues : MonoBehaviour
{
    public float NewValue = 0; //this is an example for the value to be averaged
    public int MovingAverageLength = 3; //made public in case you want to change it in the Inspector, if not, could be declared Constant

    private int count;
    public float movingAverage;
    public bool isValid;

    private void Start()
    {
        isValid = false;
    }

    // Update is called once per frame
    void Update()
    {
        count++;

        //This will calculate the MovingAverage AFTER the very first value of the MovingAverage
        if (count > MovingAverageLength)
        {
            movingAverage = movingAverage + (NewValue - movingAverage) / (MovingAverageLength + 1);

            //Debug.Log("Moving Average: " + movingAverage); //for testing purposes

        }
        else
        {
            //NOTE: The MovingAverage will not have a value until at least "MovingAverageLength" values are known (10 values per your requirement)
            movingAverage += NewValue;

            //This will calculate ONLY the very first value of the MovingAverage,
            if (count == MovingAverageLength)
            {
                isValid = true;
                movingAverage += movingAverage / count;
                //Debug.Log("Moving Average: " + movingAverage); //for testing purposes
            }
        }

    }
}