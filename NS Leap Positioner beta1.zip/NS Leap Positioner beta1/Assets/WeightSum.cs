﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WeightSum : MonoBehaviour {

    public Transform movingAvg;
    public Transform extrPos;

    public float weightRotation = 0.5f;

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void LateUpdate () {
        transform.position = (movingAvg.position + extrPos.position) / 2;
        transform.rotation = Quaternion.Slerp(movingAvg.rotation, extrPos.rotation, weightRotation); 
    }
}
