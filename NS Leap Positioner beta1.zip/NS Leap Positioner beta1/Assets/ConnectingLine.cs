﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[ExecuteInEditMode]
public class ConnectingLine : MonoBehaviour {

    public LineRenderer line;
    public Transform from;
    public Transform to;
    public TextMesh text;

    public LineRenderer line2;

	// Use this for initialization
	void Start () {
        //line = GetComponent<LineRenderer>();
	}
	
	// Update is called once per frame
	void Update () {
		
        if(line != null && from != null && to != null && text != null)
        {
            line.SetPosition(0, from.position);
            line.SetPosition(1, to.position);

            text.text = Mathf.Round((to.position - from.position).magnitude * 100).ToString()+"cm";

        }

        if(line2 != null)
        {
            line2.SetPosition(0, text.transform.position);
            line2.SetPosition(1, to.position + (from.position - to.position)/2);

            //text.transform.root.position = to.position + ((from.position - to.position) / 2) + Vector3.up;
        }

    }
}
