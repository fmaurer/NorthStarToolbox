﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CenterAdjustments : MonoBehaviour {

    public float stepSize;
    public float angleStepSize;
    public Transform trackingCameraCenter;
	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
        if(Input.GetKey(KeyCode.Alpha6))
        {
            transform.localPosition += trackingCameraCenter.up * stepSize;
        }
        if (Input.GetKey(KeyCode.Alpha7))
        {
            transform.localPosition -= trackingCameraCenter.up * stepSize;
        }

        if (Input.GetKey(KeyCode.Alpha8))
        {
            transform.localPosition += trackingCameraCenter.right * stepSize;
        }
        if (Input.GetKey(KeyCode.Alpha9))
        {
            transform.localPosition -= trackingCameraCenter.right * stepSize;
        }

        if (Input.GetKey(KeyCode.Minus))
        {
            transform.localPosition += trackingCameraCenter.forward * stepSize;
        }
        if (Input.GetKey(KeyCode.Equals))
        {
            transform.localPosition -= trackingCameraCenter.forward * stepSize;
        }

        //--------------

        if (Input.GetKey(KeyCode.T))
        {
            transform.RotateAround(trackingCameraCenter.position,trackingCameraCenter.right, angleStepSize);
        }
        if (Input.GetKey(KeyCode.G))
        {
            transform.RotateAround(trackingCameraCenter.position, trackingCameraCenter.right, -angleStepSize);
        }

        if (Input.GetKey(KeyCode.Y))
        {
            transform.RotateAround(trackingCameraCenter.position, trackingCameraCenter.up, angleStepSize);
        }
        if (Input.GetKey(KeyCode.H))
        {
            transform.RotateAround(trackingCameraCenter.position, trackingCameraCenter.up, -angleStepSize);
        }

        if (Input.GetKey(KeyCode.U))
        {
            transform.RotateAround(trackingCameraCenter.position, trackingCameraCenter.forward, angleStepSize);
        }
        if (Input.GetKey(KeyCode.J))
        {
            transform.RotateAround(trackingCameraCenter.position, trackingCameraCenter.forward, -angleStepSize);
        }

    }

    public Vector3 RotatePointAroundPivot(Vector3 point, Vector3 pivot, Vector3 angles)
{
    return Quaternion.Euler(angles) * (point - pivot) + pivot;
}
}
