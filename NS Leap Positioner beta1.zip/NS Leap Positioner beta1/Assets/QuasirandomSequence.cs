﻿using System.Collections.Generic;
using UnityEngine;

public class QuasirandomSequence : MonoBehaviour
{

    public Transform clipBounds; //ignore points not inside this stretched sphere
    public int seed = 0;

    int numPoints = 1024;

    public List<GameObject> sampleDistributions;
    private void Start()
    {
        sampleDistributions = new List<GameObject>();

        for (int i = 0; i < numPoints; i++)
        {
            Vector3 curPoint = Vector3.zero; float[] pointArr = Quasirandom.value(3);
            for (int j = 0; j < 3; j++)
            {
                curPoint[j] = pointArr[j] / 2;
            }
            if (isInsideBounds(curPoint))
            {
                sampleDistributions.Add(Instantiate(new GameObject(), transform.TransformPoint(curPoint), Quaternion.Euler(0,0,((float)i%5/5)*90), transform));
            }

        }

    }

    public void OnDrawGizmos()
    {
        Quasirandom.currentSeed = seed;
        //numPoints = Application.isPlaying ? Time.frameCount : 1024;

        if (!Application.isPlaying)
        {
            //generate inside editor to visualize:
            for (int i = 0; i < numPoints; i++)
            {
                Vector3 curPoint = Vector3.zero; float[] pointArr = Quasirandom.value(3);
                for (int j = 0; j < 3; j++)
                {
                    curPoint[j] = pointArr[j] / 2;
                }
                if (isInsideBounds(curPoint))
                {
                    Gizmos.DrawSphere(transform.TransformPoint(curPoint), 0.004f);
                }

            }
        } else
        {
            //use instantiated array:
            for (int i = 0; i < sampleDistributions.Count; i++)
            {
                
                    Gizmos.DrawSphere(sampleDistributions[i].transform.position, 0.004f);
                

            }
        }
    }

    bool isInsideBounds(Vector3 point)
    {

        // coordinates of centre 
        //float cx = clipBounds.position.x, cy = clipBounds.position.y, cz = clipBounds.position.z;
        float cx = 0, cy = 0, cz = 0;

        float r = 1/2f; // radius of the sphere in local space, always unit circle

        // coordinates of point
        Vector3 boundsSpacePoint = clipBounds.InverseTransformPoint(transform.TransformPoint(point));
        float x = boundsSpacePoint.x, y = boundsSpacePoint.y, z = boundsSpacePoint.z;

        float ans = check(cx, cy, cz,
                        x, y, z);

        // distance btw centre 
        // and point is less  
        // than radius 
        if (ans < (r * r))
            return true;
        //Debug.Log("Point is inside the sphere");

        // distance btw centre 
        // and point is  
        // equal to radius 
        else if (ans == (r * r))
            return true;
        //Debug.Log("Point lies on the sphere");

        // distance btw center  
        // and point is greater 
        // than radius 
        else
            return false;
            //Debug.Log("Point is outside the sphere");

        
    }

    static float check(float cx, float cy,
                            float cz, float x,
                            float y, float z)
    {
        float x1 = (float)Mathf.Pow((x - cx), 2);
        float y1 = (float)Mathf.Pow((y - cy), 2);
        float z1 = (float)Mathf.Pow((z - cz), 2);

        // distance between the 
        // centre and given point 
        return (x1 + y1 + z1);
    }
}

//Generic Quasirandom Number Generating Class
//http://extremelearning.com.au/unreasonable-effectiveness-of-quasirandom-sequences/
public static class Quasirandom
{
    public static long currentSeed;
    static Dictionary<int, float[]> alphas = new Dictionary<int, float[]>();

    static float phi(int dimension)
    {
        float x = 1f;
        for (int i = 0; i < 20; i++)
            x = x - (Mathf.Pow(x, dimension + 1) - x - 1) / ((dimension + 1) * Mathf.Pow(x, dimension) - 1);
        return x;
    }

    static float[] bakeAlphas(int dimensions)
    {
        float gamma = phi(dimensions);
        float[] newAlphas = new float[dimensions];
        for (int i = 0; i < dimensions; i++) newAlphas[i] = Mathf.Pow(1f / gamma, i + 1) % 1f;
        alphas.Add(dimensions, newAlphas);
        return newAlphas;
    }

    public static float[] value(int dimensions = 3, long seed = 0)
    {
        float[] currentAlphas;
        if (!alphas.TryGetValue(dimensions, out currentAlphas)) currentAlphas = bakeAlphas(dimensions);
        if (seed != 0) currentSeed = seed;
        return value(currentAlphas, dimensions);
    }

    public static float[] value(float[] currentAlphas, int dimensions = 3)
    {
        float[] value = new float[dimensions];
        for (int i = 0; i < dimensions; i++) value[i] = (currentSeed * currentAlphas[i]) % 1f;
        currentSeed++;
        return value;
    }
}