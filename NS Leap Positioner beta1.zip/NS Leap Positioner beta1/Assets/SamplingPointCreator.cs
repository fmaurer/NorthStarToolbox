﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
//using Leap.Unity.Internal;

namespace Leap.Unity
{

    public class SamplingPointCreator : MonoBehaviour
    {
        public KeyCode createNewSamplePoseKey = KeyCode.N;
        public LeapXRServiceProvider provider;

        public Transform originalSample;
        Quaternion startRotation;
        // Use this for initialization
        void Start()
        {
            startRotation = originalSample.rotation;
        }

        // Update is called once per frame
        void Update()
        {
            if (Input.GetKeyUp(createNewSamplePoseKey))
            {
                List<Hand> frameHands = provider.CurrentFrame.Hands;

                for(int i = 0; i < frameHands.Count; i++)
                {
                    if (frameHands[i].IsRight)
                    {
                        Instantiate(new GameObject(), frameHands[i].PalmPosition.ToVector3(), startRotation, transform);
                    }
                }

            }
        }
    }

}
