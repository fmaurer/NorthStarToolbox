﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RawIMUPosing : MonoBehaviour {

    float lastUpdate;
    Vector3 vel;

    public Transform absolutePosData;
    public float slerpFactor = 0.5f;


	// Use this for initialization
	void Start () {
        lastUpdate = 0;
        vel = Vector3.zero;
	}
	
	// Update is called once per frame
	void Update () {
		
	}

    public void UpdateRot(Quaternion newQ) {

        transform.rotation = newQ;

        }

    public void UpdateAccel(Vector3 accel)
    {
        /*
        float deltaT = Time.time - lastUpdate;

        vel = vel + (accel * deltaT / 2);

        Vector3 newPos = transform.position + (vel * deltaT / 2);
        transform.position = Vector3.Slerp(newPos, absolutePosData.position, slerpFactor*Time.smoothDeltaTime);

        lastUpdate = Time.time;
        */
    }
}
